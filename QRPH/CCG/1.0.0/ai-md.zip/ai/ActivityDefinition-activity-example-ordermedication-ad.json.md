# AD Order Meds - JSON Representation - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Order Meds**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ActivityDefinition-activity-example-ordermedication-ad.md) 
*  [XML](ActivityDefinition-activity-example-ordermedication-ad.xml.md) 
*  [JSON](#) 
*  [TTL](ActivityDefinition-activity-example-ordermedication-ad.ttl.md) 

## : AD Order Meds - JSON Representation

| |
| :--- |
| Active as of 2024-11-26 |

[Raw json](ActivityDefinition-activity-example-ordermedication-ad.json) | [Download](ActivityDefinition-activity-example-ordermedication-ad.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-ordermedication-ad.xml.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-ordermedication-ad.ttl.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

