# Activity Definition for the Administer Medication CARD - Examples - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Activity Definition for the Administer Medication CARD**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ccg-card-adminrx-ad.md) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-adminrx-ad-definitions.md) 
*  [Mappings](StructureDefinition-ccg-card-adminrx-ad-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-ccg-card-adminrx-ad.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-adminrx-ad.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-adminrx-ad.profile.ttl.md) 

## Resource Profile: CCG_Administer_Medication_Activity - Examples

| |
| :--- |
| Active as of 2025-10-02 |

Examples for the ccg-card-adminrx-ad Profile.

| |
| :--- |
| [AD Administer Meds](ActivityDefinition-activity-example-administermedication-ad.md) |

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-card-adminrx-ad-testing.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-adminrx-ad.profile.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

