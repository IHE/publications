# Data-in Encounter - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Data-in Encounter**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Encounter-Encounter-1234567.xml.md) 
*  [JSON](Encounter-Encounter-1234567.json.md) 
*  [TTL](Encounter-Encounter-1234567.ttl.md) 

## Example Encounter: Data-in Encounter

Profile: [CCG Data-In Bundle Encounter](StructureDefinition-ccg-di-encounter.md)

**identifier**: `http://example.org/ids`/Encounter-1234567

**status**: In Progress

**class**: [ActCode HH](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html#v3-ActCode-HH): home health

**type**: Outpatient procedure (procedure)

**priority**: Normal Priority

**subject**: [Iosefa Test-Fuimaono Male, DoB: 1950-07-04 ( https://example.org/ids#ZKT9319)](Patient-ZKT9319.md)

### Participants

| | | |
| :--- | :--- | :--- |
| - | **Type** | **Individual** |
| * | primary performer | [Practitioner Doctor Doctor](Practitioner-Practitioner-123.md) |

**period**: 2024-02-18 --> (ongoing)

### Locations

| | |
| :--- | :--- |
| - | **Location** |
| * | [Location Example Location](Location-Location-12.md) |

**serviceProvider**: [Organization Example Organization](Organization-Organization-14.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](CarePlan-CCG-careplan-example.ttl.md) | [top](#top) |  [next>](Encounter-Encounter-1234567.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

