# CCG CARD type - Provide Information - Definitions - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CCG CARD type - Provide Information**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ccg-card-provide.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-ccg-card-provide-mappings.md) 
*  [Examples](StructureDefinition-ccg-card-provide-examples.md) 
*  [XML](StructureDefinition-ccg-card-provide.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-provide.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-provide.profile.ttl.md) 

## Resource Profile: CCG_Provide_Information - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-02 |

Definitions for the ccg-card-provide resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-card-provide.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-provide-mappings.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

