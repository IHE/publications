# Code System for All CCG Card Types - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Code System for All CCG Card Types**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](CodeSystem-ccg-card-type-cs.xml.md) 
*  [JSON](CodeSystem-ccg-card-type-cs.json.md) 
*  [TTL](CodeSystem-ccg-card-type-cs.ttl.md) 

## CodeSystem: Code System for All CCG Card Types 

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/QRPH/CCG/CodeSystem/ccg-card-type-cs | *Version*:1.0.0 |
| Active as of 2025-10-02 | *Computable Name*:CCG_CARD_Type_CS |

 
This CodeSystem defines all known CardTypes for use in CARD PlanDefinitions 

 This Code system is referenced in the content logical definition of the following value sets: 

* [CCG_Card_Type](ValueSet-ccg-card-type.md)

This case-insensitive code system `https://profiles.ihe.net/QRPH/CCG/CodeSystem/ccg-card-type-cs` defines the following codes:

| | | |
| :--- | :--- | :--- |
|  [<prev](ValueSet-ccg-card-type.ttl.md) | [top](#top) |  [next>](CodeSystem-ccg-card-type-cs-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

