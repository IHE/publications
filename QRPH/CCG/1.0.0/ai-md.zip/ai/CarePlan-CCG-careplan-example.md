# Data-in Care Plan - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Data-in Care Plan**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](CarePlan-CCG-careplan-example.xml.md) 
*  [JSON](CarePlan-CCG-careplan-example.json.md) 
*  [TTL](CarePlan-CCG-careplan-example.ttl.md) 

## Example CarePlan: Data-in Care Plan

Profile: [CCG Data-In Bundle IPS CarePlan Specific Resource](StructureDefinition-ccg-data-in-ips-careplan.md)

**status**: Active

**intent**: Plan

**subject**: [Iosefa Test-Fuimaono Male, DoB: 1950-07-04 ( https://example.org/ids#ZKT9319)](Patient-ZKT9319.md)

> **activity**

### Details

| | | |
| :--- | :--- | :--- |
| - | **InstantiatesCanonical** | **Status** |
| * | `https://example.org/fhir/PlanDefinition/CCG-patient-plans-example` | In Progress |


| | | |
| :--- | :--- | :--- |
|  [<prev](PlanDefinition-ccg-folder-Hypertension.ttl.md) | [top](#top) |  [next>](CarePlan-CCG-careplan-example.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

