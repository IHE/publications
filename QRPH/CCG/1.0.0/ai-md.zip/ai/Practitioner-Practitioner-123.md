# Data-in Practitioner - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Data-in Practitioner**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Practitioner-Practitioner-123.xml.md) 
*  [JSON](Practitioner-Practitioner-123.json.md) 
*  [TTL](Practitioner-Practitioner-123.ttl.md) 

## Example Practitioner: Data-in Practitioner

Profile: [CCG Data-In Bundle Practitioner](StructureDefinition-ccg-di-practitioner.md)

**identifier**: `http://example.org/ids`/Practitioner-123

**name**: Doctor Doctor

**address**: 123 Anystreet, Yourtown, Ontario, Canada M0P4H1

| | | |
| :--- | :--- | :--- |
|  [<prev](PlanDefinition-CCG-patient-plans-example.ttl.md) | [top](#top) |  [next>](Practitioner-Practitioner-123.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

