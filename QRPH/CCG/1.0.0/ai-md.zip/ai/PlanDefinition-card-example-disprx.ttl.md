# CARD Dispense Medication - TTL Representation - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CARD Dispense Medication**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](PlanDefinition-card-example-disprx.md) 
*  [XML](PlanDefinition-card-example-disprx.xml.md) 
*  [JSON](PlanDefinition-card-example-disprx.json.md) 
*  [TTL](#) 

## : CARD Dispense Medication - TTL Representation

| |
| :--- |
| Active as of 2024-11-18 |

[Raw ttl](PlanDefinition-card-example-disprx.ttl) | [Download](PlanDefinition-card-example-disprx.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](PlanDefinition-card-example-disprx.json.md) | [top](#top) |  [next>](PlanDefinition-card-example-orderrx.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

