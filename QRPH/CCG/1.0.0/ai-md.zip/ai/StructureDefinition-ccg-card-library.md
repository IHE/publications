# CCG Library for CARDs - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CCG Library for CARDs**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-library-definitions.md) 
*  [Mappings](StructureDefinition-ccg-card-library-mappings.md) 
*  [XML](StructureDefinition-ccg-card-library.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-library.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-library.profile.ttl.md) 

## Resource Profile: CCG Library for CARDs 

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/QRPH/CCG/StructureDefinition/ccg-card-library | *Version*:1.0.0 |
| Active as of 2025-10-02 | *Computable Name*:CCG_CARD_Library |

 
Profile to serve as the basis for all CARD definitions referencing Library resources based on the CPG CQL Library 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ihe.qrph.ccg|current/StructureDefinition/ccg-card-library)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CQLLibrary](http://hl7.org/fhir/uv/cql/STU1/StructureDefinition-cql-library.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CQLLibrary](http://hl7.org/fhir/uv/cql/STU1/StructureDefinition-cql-library.html) 

**Summary**

Mandatory: 6 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [CQLLibrary](http://hl7.org/fhir/uv/cql/STU1/StructureDefinition-cql-library.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [CQLLibrary](http://hl7.org/fhir/uv/cql/STU1/StructureDefinition-cql-library.html) 

**Summary**

Mandatory: 6 elements

 

Other representations of profile: [CSV](StructureDefinition-ccg-card-library.csv), [Excel](StructureDefinition-ccg-card-library.xlsx), [Schematron](StructureDefinition-ccg-card-library.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-di-ips-bundle.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-library-definitions.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

