#  - Computable Care Guidelines v1.0.0

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ccg-card-adminrx.md) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-adminrx-definitions.md) 
*  [Mappings](StructureDefinition-ccg-card-adminrx-mappings.md) 
*  [Examples](StructureDefinition-ccg-card-adminrx-examples.md) 
*  [XML](StructureDefinition-ccg-card-adminrx.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-adminrx.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-adminrx.profile.ttl.md) 

## Resource Profile: CCG_Administer_Medication - Change History

| |
| :--- |
| Active as of 2025-10-02 |

Changes in the ccg-card-adminrx resource profile.

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

