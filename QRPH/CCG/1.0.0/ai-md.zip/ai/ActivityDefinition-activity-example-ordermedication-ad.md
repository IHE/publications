# AD Order Meds - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Order Meds**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ActivityDefinition-activity-example-ordermedication-ad.xml.md) 
*  [JSON](ActivityDefinition-activity-example-ordermedication-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-ordermedication-ad.ttl.md) 

## ActivityDefinition: AD Order Meds (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/uv/cpg/ActivityDefinition/activity-example-ordermedication-ad | *Version*:1.0.0 |
| Active as of 2024-11-26 | *Computable Name*:ActivityExampleOrderMedicationAD |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.48.11.10 | |

 
IHE CCG example for medication order ActivityDefinition Task (based on HL7 CPG example) 

* **Product:**: **Id:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: activity-example-ordermedication-ad
* **Product:**: **Version:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: 1.0.0
* **Product:**: ****
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: urn:oid:2.16.840.1.113883.4.642.40.48.11.10
* **Product:**: **Experimental:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: true
* **Product:**: **Date (date last changed):**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: 2024-11-26 16:34:39+0000
* **Product:**: **Publisher (steward):**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: IHE QRPH Technical Committee
* **Product:**: **Description:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: IHE CCG example for medication order ActivityDefinition Task (based on HL7 CPG example)
* **Product:**: **Jurisdiction:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: 001
* **Product:**: **Topic:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: orderrx
* **Product:**: **Kind:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: MedicationRequest
* **Product:**: **Profile:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-medicationrequest
* **Product:**: **Intent:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: proposal
* **Product:**: **Priority:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: routine
* **Product:**: **doNotPerform:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**376988009**display:**Levothyroxine sodium 75 microgram oral tablet: false

| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-dispensemedication-ad.ttl.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-ordermedication-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

