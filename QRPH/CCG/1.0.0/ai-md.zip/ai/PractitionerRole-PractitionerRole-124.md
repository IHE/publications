# Data-in PractitionerRole - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Data-in PractitionerRole**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](PractitionerRole-PractitionerRole-124.xml.md) 
*  [JSON](PractitionerRole-PractitionerRole-124.json.md) 
*  [TTL](PractitionerRole-PractitionerRole-124.ttl.md) 

## Example PractitionerRole: Data-in PractitionerRole

Profile: [CCG Data-In Bundle PractitionerRole](StructureDefinition-ccg-di-practitionerrole.md)

**identifier**: `http://example.org/ids`/PractitionerRole-124

**practitioner**: [Practitioner Doctor Doctor](Practitioner-Practitioner-123.md)

**organization**: [Organization Example Organization](Organization-Organization-14.md)

**specialty**: Family practice (qualifier value)

| | | |
| :--- | :--- | :--- |
|  [<prev](Practitioner-Practitioner-123.ttl.md) | [top](#top) |  [next>](PractitionerRole-PractitionerRole-124.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

