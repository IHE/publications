# Activity Definition for the Stop Activity (Medication Order) CARD - Mappings - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Activity Definition for the Stop Activity (Medication Order) CARD**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ccg-card-stoprx-ad.md) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-stoprx-ad-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-ccg-card-stoprx-ad-examples.md) 
*  [XML](StructureDefinition-ccg-card-stoprx-ad.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-stoprx-ad.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-stoprx-ad.profile.ttl.md) 

## Resource Profile: CCG_Stop_Activity_Medication_Order_Activity - Mappings

| |
| :--- |
| Active as of 2025-10-02 |

Mappings for the ccg-card-stoprx-ad resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-card-stoprx-ad-definitions.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-stoprx-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

