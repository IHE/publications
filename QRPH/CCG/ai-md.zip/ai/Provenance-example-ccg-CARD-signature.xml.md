# CARD Digital Signature example - XML Representation - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CARD Digital Signature example**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](Provenance-example-ccg-CARD-signature.md) 
*  [XML](#) 
*  [JSON](Provenance-example-ccg-CARD-signature.json.md) 
*  [TTL](Provenance-example-ccg-CARD-signature.ttl.md) 

## : CARD Digital Signature example - XML Representation

[Raw xml](Provenance-example-ccg-CARD-signature.xml) | [Download](Provenance-example-ccg-CARD-signature.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](Provenance-example-ccg-CARD-signature.md) | [top](#top) |  [next>](Provenance-example-ccg-CARD-signature.json.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

