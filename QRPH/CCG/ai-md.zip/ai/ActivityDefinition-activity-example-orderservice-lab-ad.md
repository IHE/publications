# AD Service Request (Lab Order) - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Service Request (Lab Order)**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ActivityDefinition-activity-example-orderservice-lab-ad.xml.md) 
*  [JSON](ActivityDefinition-activity-example-orderservice-lab-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-orderservice-lab-ad.ttl.md) 

## ActivityDefinition: AD Service Request (Lab Order) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/uv/cpg/ActivityDefinition/activity-example-orderservice-lab-ad | *Version*:1.0.0 |
| Active as of 2024-11-26 | *Computable Name*:ActivityExampleOrderServiceLabAD |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.48.11.11 | |

 
IHE CCG example for Lab Order ActivityDefinition (based on HL7 CPG example) 

* **Code:**: **Id:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: activity-example-orderservice-lab-ad
* **Code:**: **Version:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: 1.0.0
* **Code:**: ****
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: urn:oid:2.16.840.1.113883.4.642.40.48.11.11
* **Code:**: **Experimental:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: true
* **Code:**: **Date (date last changed):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: 2024-11-26 16:34:39+0000
* **Code:**: **Publisher (steward):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: IHE QRPH Technical Committee
* **Code:**: **Description:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: IHE CCG example for Lab Order ActivityDefinition (based on HL7 CPG example)
* **Code:**: **Jurisdiction:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: 001
* **Code:**: **Topic:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: reqlab
* **Code:**: **Kind:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: ServiceRequest
* **Code:**: **Profile:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-servicerequest
* **Code:**: **Intent:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: proposal
* **Code:**: **doNotPerform:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: false
* **Code:**: **Dynamic Values:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**order-service**display:**Order a service: * status: *('draft lab order')*



| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-recommendimmunization-ad.ttl.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-orderservice-lab-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

