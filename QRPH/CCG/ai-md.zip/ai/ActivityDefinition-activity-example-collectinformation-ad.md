# AD Collect info - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Collect info**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ActivityDefinition-activity-example-collectinformation-ad.xml.md) 
*  [JSON](ActivityDefinition-activity-example-collectinformation-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-collectinformation-ad.ttl.md) 

## ActivityDefinition: AD Collect info (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/uv/cpg/ActivityDefinition/activity-example-collectinformation-ad | *Version*:1.0.0 |
| Active as of 2024-11-26 | *Computable Name*:ActivityExampleCollectInformationAD |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.48.11.2 | |

 
IHE CCG Example Activity Definition for a recommendation to collect information (based on HL7 CPG example) 

* **Code:**: **Id:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: activity-example-collectinformation-ad
* **Code:**: **Version:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: 1.0.0
* **Code:**: ****
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: urn:oid:2.16.840.1.113883.4.642.40.48.11.2
* **Code:**: **Experimental:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: true
* **Code:**: **Date (date last changed):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: 2024-11-26 16:34:39+0000
* **Code:**: **Publisher (steward):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: IHE QRPH Technical Committee
* **Code:**: **Description:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: IHE CCG Example Activity Definition for a recommendation to collect information (based on HL7 CPG example)
* **Code:**: **Jurisdiction:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: 001
* **Code:**: **Topic:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: collect
* **Code:**: **Kind:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: Task
* **Code:**: **Profile:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-questionnairetask
* **Code:**: **Intent:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: proposal
* **Code:**: **doNotPerform:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: false
* **Code:**: **Dynamic Values:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**collect-information**display:**Collect information: * input.type: *(code)*

* input.value: *(extension('http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-collectWith').value)*



| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-administermedication-ad.ttl.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-collectinformation-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

