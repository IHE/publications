# AD Stop Task (Service Order) - XML Representation - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Stop Task (Service Order)**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ActivityDefinition-activity-example-stopservice-ad.md) 
*  [XML](#) 
*  [JSON](ActivityDefinition-activity-example-stopservice-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-stopservice-ad.ttl.md) 

## : AD Stop Task (Service Order) - XML Representation

| |
| :--- |
| Active as of 2024-11-26 |

[Raw xml](ActivityDefinition-activity-example-stopservice-ad.xml) | [Download](ActivityDefinition-activity-example-stopservice-ad.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-stopservice-ad-testing.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-stopservice-ad.json.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

