# CCG CARD type - Request a Service (Radiology Order) - TTL Representation - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CCG CARD type - Request a Service (Radiology Order)**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ccg-card-reqradserv.md) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-reqradserv-definitions.md) 
*  [Mappings](StructureDefinition-ccg-card-reqradserv-mappings.md) 
*  [Examples](StructureDefinition-ccg-card-reqradserv-examples.md) 
*  [XML](StructureDefinition-ccg-card-reqradserv.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-reqradserv.profile.json.md) 
*  [TTL](#) 

## Resource Profile: CCG_Request_Service_Radiology - TTL Profile

| |
| :--- |
| Active as of 2025-10-02 |

TTL representation of the ccg-card-reqradserv resource profile.

[Raw ttl](StructureDefinition-ccg-card-reqradserv.ttl) | [Download](StructureDefinition-ccg-card-reqradserv.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-card-reqradserv.profile.json.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-reqrefserv.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

