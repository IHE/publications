# Data-in Organization - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Data-in Organization**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](Organization-Organization-14.xml.md) 
*  [JSON](Organization-Organization-14.json.md) 
*  [TTL](Organization-Organization-14.ttl.md) 

## Example Organization: Data-in Organization

Profile: [CCG Data-In Bundle Organization](StructureDefinition-ccg-di-organization.md)

**identifier**: `http://example.org/ids`/Organization-14

**active**: true

**name**: Example Organization

### Contacts

| | | |
| :--- | :--- | :--- |
| - | **Telecom** | **Address** |
| * | [contact@example.org](mailto:contact@example.org) | 123 Anystreet, Yourtown, Ontario, Canada M0P4H1 |

| | | |
| :--- | :--- | :--- |
|  [<prev](Location-Location-12.ttl.md) | [top](#top) |  [next>](Organization-Organization-14.xml.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

