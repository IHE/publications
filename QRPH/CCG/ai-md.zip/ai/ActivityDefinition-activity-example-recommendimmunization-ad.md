# AD Recommend Immunization - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Recommend Immunization**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ActivityDefinition-activity-example-recommendimmunization-ad.xml.md) 
*  [JSON](ActivityDefinition-activity-example-recommendimmunization-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-recommendimmunization-ad.ttl.md) 

## ActivityDefinition: AD Recommend Immunization (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/fhir/uv/cpg/ActivityDefinition/activity-example-recommendimmunization-ad | *Version*:1.0.0 |
| Active as of 2024-11-26 | *Computable Name*:ActivityExampleRecommendImmunizationAD |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.48.11.13 | |

 
IHE CCG example for Recommend Immunization ActivityDefinition (based on HL7 CPG example) 

* **Product:**: **Id:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): activity-example-recommendimmunization-ad
* **Product:**: **Version:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): 1.0.0
* **Product:**: ****
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): urn:oid:2.16.840.1.113883.4.642.40.48.11.13
* **Product:**: **Experimental:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): true
* **Product:**: **Date (date last changed):**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): 2024-11-26 16:34:39+0000
* **Product:**: **Publisher (steward):**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): IHE QRPH Technical Committee
* **Product:**: **Description:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): IHE CCG example for Recommend Immunization ActivityDefinition (based on HL7 CPG example)
* **Product:**: **Jurisdiction:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): 001
* **Product:**: **Topic:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): reqvx
* **Product:**: **Kind:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): MedicationRequest
* **Product:**: **Profile:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-immunizationrequest
* **Product:**: **Intent:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): proposal
* **Product:**: **Priority:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): routine
* **Product:**: **doNotPerform:**
  * **system:**[http://snomed.info/sct](https://browser.ihtsdotools.org/)**code:**871751006**display:**Vaccine product containing only Hepatitis A virus antigen (medicinal product): false

| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-sendmessage-ad.ttl.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-recommendimmunization-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

