# CCG CARD Folder PlanDefinition - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CCG CARD Folder PlanDefinition**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ccg-card-folder-definitions.md) 
*  [Mappings](StructureDefinition-ccg-card-folder-mappings.md) 
*  [Examples](StructureDefinition-ccg-card-folder-examples.md) 
*  [XML](StructureDefinition-ccg-card-folder.profile.xml.md) 
*  [JSON](StructureDefinition-ccg-card-folder.profile.json.md) 
*  [TTL](StructureDefinition-ccg-card-folder.profile.ttl.md) 

## Resource Profile: CCG CARD Folder PlanDefinition 

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/QRPH/CCG/StructureDefinition/ccg-card-folder | *Version*:1.0.0 |
| Active as of 2025-10-02 | *Computable Name*:CCG_CARD_Folder |

 
Each unique CCG will be expressed as a PlanDefinition (a CCG Folder) that lists the CCG's defined CARDs 

**Usages:**

* Refer to this Profile: [CCG Patient Plans (patient-specific) PlanDefinition](StructureDefinition-ccg-patient-plans.md)
* Examples for this Profile: [ExampleCCGFolder1](PlanDefinition-ccg-folder-Diabetes.md) and [ExampleCCGFolder1](PlanDefinition-ccg-folder-Hypertension.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ihe.qrph.ccg|current/StructureDefinition/ccg-card-folder)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CPGComputablePlanDefinition](http://hl7.org/fhir/uv/cpg/STU2/StructureDefinition-cpg-computableplandefinition.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CPGComputablePlanDefinition](http://hl7.org/fhir/uv/cpg/STU2/StructureDefinition-cpg-computableplandefinition.html) 

**Summary**

Mandatory: 6 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [Base CARD PlanDefinition(https://profiles.ihe.net/QRPH/CCG/StructureDefinition/ccg-card-pd-base)](StructureDefinition-ccg-card-pd-base.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of PlanDefinition.action.definition[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [CPGComputablePlanDefinition](http://hl7.org/fhir/uv/cpg/STU2/StructureDefinition-cpg-computableplandefinition.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [CPGComputablePlanDefinition](http://hl7.org/fhir/uv/cpg/STU2/StructureDefinition-cpg-computableplandefinition.html) 

**Summary**

Mandatory: 6 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [Base CARD PlanDefinition(https://profiles.ihe.net/QRPH/CCG/StructureDefinition/ccg-card-pd-base)](StructureDefinition-ccg-card-pd-base.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of PlanDefinition.action.definition[x]

 

Other representations of profile: [CSV](StructureDefinition-ccg-card-folder.csv), [Excel](StructureDefinition-ccg-card-folder.xlsx), [Schematron](StructureDefinition-ccg-card-folder.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-ccg-signature.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-ccg-card-folder-definitions.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

