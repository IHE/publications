# AD Dispense Meds - Computable Care Guidelines v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AD Dispense Meds**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](#) 
*  [XML](ActivityDefinition-activity-example-dispensemedication-ad.xml.md) 
*  [JSON](ActivityDefinition-activity-example-dispensemedication-ad.json.md) 
*  [TTL](ActivityDefinition-activity-example-dispensemedication-ad.ttl.md) 

## ActivityDefinition: AD Dispense Meds (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/uv/cpg/ActivityDefinition/activity-example-dispensemedication-ad | *Version*:1.0.0 |
| Active as of 2024-11-26 | *Computable Name*:ActivityExampleDispenseMedicationAD |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.48.11.3 | |

 
IHE CCG Example Activity Definition for a recommendation to dispense medications (based on HL7 CPG example) 

* **Code:**: **Id:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: activity-example-dispensemedication-ad
* **Code:**: **Version:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: 1.0.0
* **Code:**: ****
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: urn:oid:2.16.840.1.113883.4.642.40.48.11.3
* **Code:**: **Experimental:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: true
* **Code:**: **Date (date last changed):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: 2024-11-26 16:34:39+0000
* **Code:**: **Publisher (steward):**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: IHE QRPH Technical Committee
* **Code:**: **Description:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: IHE CCG Example Activity Definition for a recommendation to dispense medications (based on HL7 CPG example)
* **Code:**: **Jurisdiction:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: 001
* **Code:**: **Topic:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: disprx
* **Code:**: **Kind:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: Task
* **Code:**: **Profile:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-dispensemedicationtask
* **Code:**: **Intent:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: proposal
* **Code:**: **doNotPerform:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: false
* **Code:**: **Dynamic Values:**
  * **system:**[http://hl7.org/fhir/uv/cpg/CodeSystem/cpg-activity-type-cs](http://hl7.org/fhir/uv/cpg/STU2/CodeSystem-cpg-activity-type-cs.html)**code:**dispense-medication**display:**Dispense a medication: * input.type: *(code)*

* input.value: *(Medication Proposal)*



| | | |
| :--- | :--- | :--- |
|  [<prev](ActivityDefinition-activity-example-collectinformation-ad.ttl.md) | [top](#top) |  [next>](ActivityDefinition-activity-example-dispensemedication-ad-testing.md) |

 IG © 2025+ [IHE QRPH Technical Committee](https://www.ihe.net/ihe_domains/quality_research_and_public_health/). Package ihe.qrph.ccg#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[New Issue](https://github.com/IHE/QRPH.CCG/issues/new/choose)|[Issues](https://github.com/IHE/QRPH.CCG/issues)[Version History](https://profiles.ihe.net/QRPH/CCG/history.html)|![](assets/images/cc-by.png)|[Propose a change![](external.png)](https://www.ihe.net/resources/public_comment/) 

