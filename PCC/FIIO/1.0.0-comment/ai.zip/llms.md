# ihe.pcc.fiio#1.0.0-comment: FHIR International Patient Summary

## Pages

* [(FIPS) Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Download and Analysis](download.md)
* [Significant Changes and Issues](issues.md)
* [Changes to Other IHE Specifications](other.md)
* [Test Plan](testplan.md)
* [1:XX](volume-1.md)
* [3:XX](volume-3.md)

## Resources

### Resource Profiles

* [IHE FHIR IPS Complete Option Bundle](StructureDefinition-IHE.FIPS.Complete.Option.Bundle.md)
* [FHIR International Patient Summary Implementation Options - Complete Option Composition](StructureDefinition-IHE.FIPS.IO.Complete.Option.Composition.md)
* [International Patient Summary Occupational Data For Health Implementation Option Composition](StructureDefinition-IHE.FIPS.IO.ODH.Option.Composition.md)
* [IHE FHIR IPS ODH Option Bundle](StructureDefinition-IHE.FIPS.ODH.Option.Bundle.md)

### CapabilityStatements

* [IPS Content Consumer](CapabilityStatement-IHE.IPS.Content-Consumer.md)
* [IPS Content Creator](CapabilityStatement-IHE.IPS.Content-Creator.md)

### ImplementationGuides

* [FHIR International Patient Summary](index.md)

### Examples

* [e0e8252a-4aab-4fab-ac8f-5734abbd1ec7 (Bundle)](Bundle-e0e8252a-4aab-4fab-ac8f-5734abbd1ec7.md)
* [ex-bundle-ips-frank-missingdata (Bundle)](Bundle-ex-bundle-ips-frank-missingdata.md)
* [ex-bundle-secondaryUse-pandemnicips-patricia-jordana (Bundle)](Bundle-ex-bundle-secondaryUse-pandemnicips-patricia-jordana.md)
* [Patient Summary of Genny Works (Composition)](Composition-2a7a5f03-9581-4677-ba18-fbd3b221f601.md)
* [International Patient Summary (Composition)](Composition-313df1ad-9094-4a93-a0cc-64ee25d3d327.md)
* [Patient Summary of Frank MissingData (Composition)](Composition-567f7a70-6f0d-49c5-a6ca-20eff88e7c8e.md)
