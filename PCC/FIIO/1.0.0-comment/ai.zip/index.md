# FHIR International Patient Summary (FIPS) Home - FHIR International Patient Summary v1.0.0-comment

* [**Table of Contents**](toc.md)
* **FHIR International Patient Summary (FIPS) Home**

## FHIR International Patient Summary (FIPS) Home

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/PCC/FIIO/ImplementationGuide/ihe.pcc.fiio | *Version*:1.0.0-comment |
| Active as of 2026-03-03 | *Computable Name*:IHE_PCC_FIIO |

**This IPS profile uses the Health Level 7's FHIR International Patient Summary (IPS) that realizes the CEN EN 17269 IPS dataset to profile additional implementation options that can be incorporated into the IPS document. This is a Content Module profile that defines these additional Implementation options.**

| |
| :--- |
| [Significant Changes, Open and Closed Issues](issues.md) |

### Organization of This Guide

This guide is organized into the following sections:

* Volume 1: 
* [Introduction](volume-1.md)
* [Actors, Transactions, and Content](volume-1.md#actors-and-transactions)
* [Actor Options](volume-1.md#actor-options)
* [Actor Required Groupings](volume-1.md#required-groupings)
* [Overview](volume-1.md#overview)
* [Security Considerations](volume-1.md#security-considerations)
* [Cross Profile Considerations](volume-1.md#other-grouping)
 
* Volume 3: Metadata and Content 
* [FHIR Content Modules](volume-3.md#fhir-contentModules)
 
* Other 
* [Changes to Other IHE Specifications](other.md)
* [Download and Analysis](download.md)
* [Test Plan](testplan.md)
 

Click on any of the links above, see the [Table of Contents](toc.md) and the index of [Artifacts](artifacts.md) defined as part of this implementation guide.

### Conformance Expectations

IHE uses the normative words: "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" according to [standards conventions](https://profiles.ihe.net/GeneralIntro/ch-E.html).

#### Must Support

The use of `mustSupport` in StructureDefinition profiles equivalent to the IHE use of **R2** as defined in [Appendix Z](https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#z.10-profiling-conventions-for-constraints-on-fhir).

mustSupport of true - only has a meaning on items that are minimal cardinality of zero (0), and applies only to the source actor populating the data. The source actor shall populate the elements marked with MustSupport, if the concept is supported by the actor, a value exists, and security and consent rules permit. The consuming actors should handle these elements being populated or being absent/empty. Note that sometimes mustSupport will appear on elements with a minimal cardinality greater than zero (0), this is due to inheritance from a less constrained profile.

