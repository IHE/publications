Query with source patient identifier of Mohr Alice in IHE RED Domain:
```
GET [base]/Patient/$ihe-pix?sourceIdentifier=urn:oid:1.3.6.1.4.1.21367.13.20.1000|IHERED-994
```