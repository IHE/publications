Query with source patient identifier of Mohr Alice in IHE Red Domain and requesting identifier in target domain IHE Blue
```
GET [base]/Patient/$ihe-pix?sourceIdentifier=urn:oid:1.3.6.1.4.1.21367.13.20.1000|IHERED-994&targetSystem=urn:oid:1.3.6.1.4.1.21367.13.20.3000
```