# Example document that says: Hello World - Mobile access to Health Documents (MHD) v5.0.0-comment

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example document that says: Hello World**

## Example Binary: Example document that says: Hello World

```

Hello World
```



## Resource Binary Content

text/plain:

```
[B@6a6a60f3
```
