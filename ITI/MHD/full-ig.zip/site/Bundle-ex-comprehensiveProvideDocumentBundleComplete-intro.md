Example of a complete comprehensive Provide Document Bundle for a publication.
- The bundle contains
  - SubmissionSet - identifies one documentReference
  - Folder - identifies one documentReference
  - DocumentReference - One DocumentReference
  - Binary - the document
  - the Patient is contained in the DocumentReference
  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.
  
Response [example](Bundle-ex-response-comprehensiveProvideDocumentBundleComplete.html)
  