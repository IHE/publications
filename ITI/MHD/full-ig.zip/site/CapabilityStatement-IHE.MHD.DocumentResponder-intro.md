This is the **Requirements** CapabilityStatement for a [Document Responder](1331_actors_and_transactions.html#133114-document-responder). The Document Responder may  declared the [XDS on FHIR](1332_actor_options.html#13322-xds-on-fhir-option) Option or the UnContained References [Options](1332_actor_options.html). This Actor Shall provide server implementing [Find Document List ITI-66](ITI-66.html), [Find Document References ITI-67](ITI-67.html), and [Retrieve Document ITI-68](ITI-68.html) transactions. 

<div>
{%include QueryActors.svg%}
</div>

<div style="clear: left"/>

**Figure: Query Actors Interactions**

