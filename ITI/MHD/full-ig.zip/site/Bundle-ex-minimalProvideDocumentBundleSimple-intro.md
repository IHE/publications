Example of a minimal Provide Document Bundle for a push to an email intended recipient.
- The bundle contains
  - SubmissionSet - identifies to whom this is going and one documentReference
  - DocumentReference - One DocumentReference
  - Binary - the document
  - the Patient, as this is a push to a recipient that does not share a patient directory
  
Response [example](Bundle-ex-response-comprehensiveProvideDocumentBundleSimple.html)
  