Example of a comprehensive Provide Document Bundle for a publication and added to an existing folder.
- The bundle contains
  - SubmissionSet - identifies one documentReference
  - Folder - existing Folder to be updated
  - DocumentReference - One DocumentReference
  - Binary - the document
  - the Patient is contained in the DocumentReference
  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.

no response example is provided
