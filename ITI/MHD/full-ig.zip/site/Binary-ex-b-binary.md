# Example document that says: Hello World - Mobile access to Health Documents (MHD) v4.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example document that says: Hello World**

## Example Binary: Example document that says: Hello World

```

Hello World
```



## Resource Binary Content

text/plain:

```
[B@7fa7f0c8
```
