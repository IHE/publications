# MHD Home - Mobile access to Health Documents (MHD) v4.2.5

* [**Table of Contents**](toc.md)
* **MHD Home**

## MHD Home

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd | *Version*:4.2.5 |
| Active as of 2026-10-18 | *Computable Name*:IHE_ITI_MHD |

Applications specific to resource-constrained and mobile devices are an emerging platform for healthcare-enhancing software. The MHD Profile is not limited to mobile devices, using the term “mobile” only as a grouping for mobile applications, mobile devices or any other systems that are resource and platform-constrained. These constraints may drive the implementer to use simpler network interface technology. There are numerous deployed implementations of [Document Sharing Health Information Exchange](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) that need a simpler network interface technology, for example those hosted by a Health Information Exchange (HIE), large health provider electronic health record (EHR), or personal health record (PHR).

The Mobile access to Health Documents (MHD) Profile defines one standardized interface to [health document sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) (a.k.a. an Application Programming Interface (API)) for use by mobile devices so that deployment of mobile applications is more consistent and reusable. In this context, mobile devices include tablets, smart-phones, and embedded devices including home-health devices. This profile is also applicable to more capable systems where needs are simple, such as pulling the latest summary for display. The critical aspects of the "mobile device" are that it is resource-constrained, has a simple programming environment (e.g., JSON, JavaScript), simple protocol stack (e.g., HTTP), and simple display functionality (e.g., HTML browser). The goal is, in part, to avoid burdening the client with additional libraries such as those that are necessary to process SOAP, WSSE, MIME-Multipart, MTOM/XOP, ebRIM, and multi-depth XML.

The Mobile access to Health Documents (MHD) Profile defines one pair of actors and a transaction to submit or push new “document entries” from the mobile device to a receiving system. Another set of actors and transactions is used to query a list of “document entries” having specific metadata, and to retrieve a document.

The transactions defined here leverage the [document content- and format-agnostic metadata concepts](https://profiles.ihe.net/ITI/TF/Volume3/index.html#4) that were initially developed for [XDS](https://profiles.ihe.net/ITI/TF/Volume1/ch-10.html) but simplify them for access in constrained environments including mobile devices.

The MHD Profile can be used as an [API to a Document Sharing exchange using XDS](1336_cross_profile_considerations.md#13361-mhd-actor-grouped-with-xds-infrastructure) or [XCA](1336_cross_profile_considerations.md#13362-mhd-actors-grouped-with-xca-infrastructure). The MHD Profile is used by the [MHDS Document Sharing](https://profiles.ihe.net/ITI/TF/Volume1/ch-50.html) solution. The MHD Profile can be used in [push solutions](1334_overview.md#133422-publication-of-new-documents-process-flow) alone or as an API to solutions like XDR or XDM. These are further elaborated in [Cross Profile Considerations](1336_cross_profile_considerations.md).

The [Mobile Cross-Enterprise Document Data Element Extraction (mXDE)](https://profiles.ihe.net/ITI/TF/Volume1/ch-45.html) Profile combines MHD with the PCC Query for Existing Data for Mobile (QEDm) Profile to provide element level access to the medical information available in a Document Sharing exchange. More details can be found in the white paper on [Document Sharing Health Information Exchange](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html).

MHD is part of [IHE](https://profiles.ihe.net) – [IT-Infrastructure](https://profiles.ihe.net/ITI) Domain and part of the [IHE Document Sharing Health Information Exchange](https://profiles.ihe.net/ITI/HIE-Whitepaper) solution.

 This IG is founded on HL7 FHIR Revision 4.0.1 found at [http://hl7.org/fhir/R4/](http://hl7.org/fhir/R4/)

| |
| :--- |
| [Significant Changes, Open and Closed Issues](a_issues.md) |

**[Search this IG](https://www.google.com/search?q=site%3Ahttps%3A%2F%2Fprofiles.ihe.net%2FITI%2FMHD&rlz=1C1GCEU_enUS815US815&sxsrf=ALeKk02egtK8A20vWkRrPApvkcoQjnIiDA%3A1620864970799&ei=ym-cYPmMMMq6tQa8vre4CA&oq=site%3Ahttps%3A%2F%2Fprofiles.ihe.net%2FITI%2FMHD&gs_lcp=Cgdnd3Mtd2l6EANQ7CZYmDBg9TdoAXAAeACAAWaIAcIDkgEDNS4xmAEAoAEBqgEHZ3dzLXdpesABAQ&sclient=gws-wiz&ved=0ahUKEwj5mcDGsMXwAhVKXc0KHTzfDYcQ4dUDCA4&uact=5)**

MHD is updated by [Internet User Authorization (IUA)](https://profiles.ihe.net/ITI/IUA/index.html#33-mhd-profile) to add specific scope values to be used when grouped with IUA.

#### Organization of This Guide

This guide is organized into the following sections:

* Volume 1: Use-Case analysis 
* [Actors and Transactions](1331_actors_and_transactions.md)
* [Actor Options](1332_actor_options.md)
* [Actor Required Groupings](1333_required_grouping.md)
* [Overview](1334_overview.md)
* [Security Considerations](1335_security_considerations.md)
* [Cross Profile Considerations](1336_cross_profile_considerations.md)
 
* Volume 2: Transaction Detail 
* [Provide Document Bundle [ITI-65]](ITI-65.md)
* [Find Document Lists [ITI-66]](ITI-66.md)
* [Find Document References [ITI-67]](ITI-67.md)
* [Retrieve Document [ITI-68]](ITI-68.md)
* [Simplified Publish [ITI-105]](ITI-105.md)
* [Generate Metadata [ITI-106]](ITI-106.md)
 
* Volume 3: Metadata 
* [XDS Error Codes](31_xds.md)
* [FHIR Representation](32_fhir_maps.md)
 
* Other 
* [Test Plan](testplan.md)
* [Download and Analysis](download.md)
 

Click on any of the links above, see the [Table of Contents](toc.md), or if you are looking for a specific artifact, see the index of [Artifacts](artifacts.md).

#### Must Support

MHD defines `Must Support` in StructureDefinition profiles as the element, when the minimal cardinality is zero, is **R2** `Required if Known`, as found in [Appendix Z](https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#z.10-profiling-conventions-for-constraints-on-fhir). `Must Support` when the element minimal cardinality is not zero means **R**.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "ihe.iti.mhd",
  "url" : "https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd",
  "version" : "4.2.5",
  "name" : "IHE_ITI_MHD",
  "title" : "Mobile access to Health Documents (MHD)",
  "status" : "active",
  "date" : "2026-10-18T17:32:41-05:00",
  "publisher" : "IHE IT Infrastructure Technical Committee",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ihe.net/ihe_domains/it_infrastructure/"
    }]
  },
  {
    "telecom" : [{
      "system" : "email",
      "value" : "iti@ihe.net"
    }]
  },
  {
    "name" : "IHE IT Infrastructure Technical Committee",
    "telecom" : [{
      "system" : "email",
      "value" : "iti@ihe.net"
    }]
  }],
  "description" : "ImplementationGuide for IHE IT Infrastructure Technical Framework Supplement Mobile access to Health Documents (MHD)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "packageId" : "ihe.iti.mhd",
  "license" : "CC-BY-4.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "iheitibasicaudit",
    "uri" : "https://profiles.ihe.net/ITI/BALP/ImplementationGuide/ihe.iti.balp",
    "packageId" : "ihe.iti.balp",
    "version" : "1.1.4"
  },
  {
    "id" : "iheformatcodefhir",
    "uri" : "https://profiles.ihe.net/fhir/ihe.formatcode.fhir/ImplementationGuide/ihe.formatcode.fhir",
    "packageId" : "ihe.formatcode.fhir",
    "version" : "1.6.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "trial-use"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "usage-stats-opt-out"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://profiles.ihe.net/ITI/MHD/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-AssociationTypeVsRelatesTo.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/AssociationTypeVsRelatesTo"
      },
      "name" : "AssociationType vs RelatesTo",
      "description" : "map between XDS Association Types and MHD FHIR DocumentReference relatesTo code.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentLists.Audit.Responder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentLists.Audit.Responder"
      },
      "name" : "Audit Event for Find Document Lists Transaction at Document Responder",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Find Document Lists Transaction happens, as recorded by the Document Responder.\n- Build off of the IHE BasicAudit PatientQuery event\n- add the ITI-67 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for query, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentLists.Audit.Consumer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentLists.Audit.Consumer"
      },
      "name" : "Audit Event for Find Document Lists Transaction by the Document Consumer",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Find Document Lists Transaction happens, as recorded by the Document Consumer.\n- Build off of the IHE BasicAudit PatientQuery event\n- add the ITI-67 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for query, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentReferences.Audit.Consumer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentReferences.Audit.Consumer"
      },
      "name" : "Audit Event for Find Document References Transaction at Document Consumer",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Find Document References Transaction happens, as recorded by the Document Consumer.\n- Build off of the IHE BasicAudit PatientQuery event\n- add the ITI-67 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for query, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentReferences.Audit.Responder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentReferences.Audit.Responder"
      },
      "name" : "Audit Event for Find Document References Transaction at Document Responder",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Find Document References Transaction happens, as recorded by the Document Responder.\n- Build off of the IHE BasicAudit PatientQuery event\n- add the ITI-67 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for query, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.GenerateMetadata.Audit.Recipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.GenerateMetadata.Audit.Recipient"
      },
      "name" : "Audit Event for Generate Metadata ITI-106 Transaction at Recipient",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Generate Metadata ITI-106 Transaction happens at the Recipient.\n- Build off of the IHE Basic Audit Patient Create event\n- add the ITI-106 as a subtype\n- client is the Document Source\n- Server is the Document Recipient\n- may have user, app, organization agent(s)\n- shall have a patient entity\n- shall have a documentReference identity entity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.GenerateMetadata.Audit.Source.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.GenerateMetadata.Audit.Source"
      },
      "name" : "Audit Event for Generate Metadata ITI-106 Transaction at Source",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Generate Metadata ITI-106 Transaction happens at the Soure.\n- Build off of the IHE Basic Audit Create event\n- add the ITI-106 as a subtype\n- client is the Document Source\n- Server is the Document Recipient\n- may have user, app, organization agent(s)\n- shall have a document uri\n- note the Document Source may add a patient if it knows it.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.ProvideBundle.Audit.Recipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.ProvideBundle.Audit.Recipient"
      },
      "name" : "Audit Event for Provide Bundle Transaction at Recipient",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Provide Bundle Transaction happens at the Recipient.\r\n- Import event\r\n- shall have source of itself\r\n- shall have a document source agent\r\n- shall have a document recipient agent\r\n- may have user, app, organization agent(s)\r\n- shall have a patient entity\r\n- shall have a submission set identity entity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.ProvideBundle.Audit.Source.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.ProvideBundle.Audit.Source"
      },
      "name" : "Audit Event for Provide Bundle Transaction at Source",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Provide Bundle Transaction happens at the Source.\r\n- Export event\r\n- shall have source of itself\r\n- shall have a document source agent\r\n- shall have a document recipient agent\r\n- may have user, app, organization agent(s)\r\n- shall have a patient entity\r\n- shall have a submission set identity entity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Consumer"
      },
      "name" : "Audit Event for Retrieve Document Transaction at Document Consumer",
      "description" : "Defines constraints on the Document Consumer AuditEvent Resource to record when a Retrieve Document Transaction happens, as recorded by the Document Consumer.\n- Build off of the IHE BasicAudit PatientRead event\n- add the ITI-68 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for data, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Responder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Responder"
      },
      "name" : "Audit Event for Retrieve Document Transaction at the Document Responder",
      "description" : "Defines constraints on the Document Responder AuditEvent Resource to record when a Retrieve Document Transaction happens, as recorded by the Document Responder.\n- Build off of the IHE BasicAudit PatientRead event\n- add the ITI-68 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for data, and patient are required\n- entity slice for transaction is available",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.SimplifiedPublish.Audit.Recipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.SimplifiedPublish.Audit.Recipient"
      },
      "name" : "Audit Event for Simplified Publish ITI-105 Transaction at Recipient",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Simplified Publish ITI-105 Transaction happens at the Recipient.\n- Build off of the IHE Basic Audit Patient Create event\n- add the ITI-105 as a subtype\n- client is the Document Source\n- Server is the Document Recipient\n- may have user, app, organization agent(s)\n- shall have a patient entity\n- shall have a documentReference identity entity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.SimplifiedPublish.Audit.Source.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.SimplifiedPublish.Audit.Source"
      },
      "name" : "Audit Event for Simplified Publish ITI-105 Transaction at Source",
      "description" : "Defines constraints on the AuditEvent Resource to record when a Simplified Publish ITI-105 Transaction happens at the Soure.\n- Build off of the IHE Basic Audit Patient Create event\n- add the ITI-105 as a subtype\n- client is the Document Source\n- Server is the Document Recipient\n- may have user, app, organization agent(s)\n- shall have a patient entity\n- shall have a documentReference identity entity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditSimplifiedPublish-recipient.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditSimplifiedPublish-recipient"
      },
      "name" : "Audit Example of ITI-105 at recipient",
      "description" : "Audit Example for a Simplified Publish Transaction as recorded at the recipient",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.SimplifiedPublish.Audit.Recipient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditSimplifiedPublish-source.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditSimplifiedPublish-source"
      },
      "name" : "Audit Example of ITI-105 at source",
      "description" : "Audit Example for a Simplified Publish Transaction from source perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.SimplifiedPublish.Audit.Source"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditGenerateMetadata-recipient.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditGenerateMetadata-recipient"
      },
      "name" : "Audit Example of ITI-106 at recipient",
      "description" : "Audit Example for a Generate Metadata Transaction as recorded at the recipient",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.GenerateMetadata.Audit.Recipient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditGenerateMetadata-source.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditGenerateMetadata-source"
      },
      "name" : "Audit Example of ITI-106 at source",
      "description" : "Audit Example for a Generate Metadata Transaction from source perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.GenerateMetadata.Audit.Source"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditProvideBundle-recipient.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditProvideBundle-recipient"
      },
      "name" : "Audit Example of ITI-65 at recipient",
      "description" : "Audit Example for a Provide Bundle Transaction as recorded at the recipient",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideBundle.Audit.Recipient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditProvideBundle-source.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditProvideBundle-source"
      },
      "name" : "Audit Example of ITI-65 at source",
      "description" : "Audit Example for a Provide Bundle Transaction from source perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideBundle.Audit.Source"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditFindDocumentLists-consumer.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditFindDocumentLists-consumer"
      },
      "name" : "Audit Example of ITI-66 at Consumer",
      "description" : "Audit Example for a Find Document Lists Transaction as recorded at the consumer",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentLists.Audit.Consumer"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditFindDocumentLists-responder.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditFindDocumentLists-responder"
      },
      "name" : "Audit Example of ITI-66 at responder",
      "description" : "Audit Example for a Find Document Lists Transaction from responder perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentLists.Audit.Responder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditFindDocumentReferences-consumer.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditFindDocumentReferences-consumer"
      },
      "name" : "Audit Example of ITI-67 at Consumer",
      "description" : "Audit Example for a Find Document References Transaction as recorded at the consumer",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferences.Audit.Consumer"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditFindDocumentReferences-responder.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditFindDocumentReferences-responder"
      },
      "name" : "Audit Example of ITI-67 at responder",
      "description" : "Audit Example for a Find Document References Transaction from responder perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferences.Audit.Responder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditFindDocumentReferences-post-responder.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditFindDocumentReferences-post-responder"
      },
      "name" : "Audit Example of ITI-67 using POST recorded at responder",
      "description" : "Audit Example for a Find Document References Transaction using POST search as recorded at the responder perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferences.Audit.Responder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditRetrieveDocument-consumer.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditRetrieveDocument-consumer"
      },
      "name" : "Audit Example of ITI-68 at consumer",
      "description" : "Audit Example for a Retrieve Document Transaction as recorded at the consumer",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Consumer"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-ex-auditRetrieveDocument-responder.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/ex-auditRetrieveDocument-responder"
      },
      "name" : "Audit Example of ITI-68 at responder",
      "description" : "Audit Example for a Retrieve Document Transaction from responder perspective",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Responder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-authorOrg.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-authorOrg"
      },
      "name" : "Author organization of the SubmissionSet",
      "description" : "When the author of the SubmissionSet is an Organization, this extension shall be used.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-designationType.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-designationType"
      },
      "name" : "Clinical code of the List",
      "description" : "Expresses contentType of submissionSet or the codeList of a Folder. Usually expressed in LOINC or SNOMED.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentConsumer.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentConsumer"
      },
      "name" : "Document Consumer (client)",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Consumer (client).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentConsumer.Target.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentConsumer.Target"
      },
      "name" : "Document Consumer (client) - Target Communities Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Consumer (client) - Target Communities Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentConsumer.FullTextSearch.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentConsumer.FullTextSearch"
      },
      "name" : "Document Consumer (client) with Full-Text Search Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Consumer (client) - with Full-Text Search Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient"
      },
      "name" : "Document Recipient",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with no declared Options or all declared Options.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.Comprehensive.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient.Comprehensive"
      },
      "name" : "Document Recipient implementing Comprehensive Metadata Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with Comprehensive declared Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.Generate.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient.Generate"
      },
      "name" : "Document Recipient implementing Generate Metadata Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with Generate Metadata declared Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.Fdoc.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient.Fdoc"
      },
      "name" : "Document Recipient implementing ITI-65 FHIR Documents Publish Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with ITI-65 FHIR Documents Publish declared Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.Simplified.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient.Simplified"
      },
      "name" : "Document Recipient implementing Simplified Publish Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with Simplified Publish declared Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentRecipient.UnContained.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentRecipient.UnContained"
      },
      "name" : "Document Recipient implementing UnContained References Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Recipient - with UnContained declared Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentResponder.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentResponder"
      },
      "name" : "Document Responder (server)",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Responder (server).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentResponder.Target.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentResponder.Target"
      },
      "name" : "Document Responder (server) - Target Communities Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Responder (server) - Target Communities Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentResponder.FullTextSearch.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentResponder.FullTextSearch"
      },
      "name" : "Document Responder (server) with Full-Text Search Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Responder (server) - with Full-Text Search Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource"
      },
      "name" : "Document Source (publisher)",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with no declared Options or all declared Options.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.Comprehensive.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource.Comprehensive"
      },
      "name" : "Document Source (publisher) implementing Comprehensive Metadata Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with Comprehensive Metadata Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.Fdoc.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource.Fdoc"
      },
      "name" : "Document Source (publisher) implementing ITI-65 FHIR Documents Publish Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with ITI-65 FHIR Documents Publish Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.Generate.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource.Generate"
      },
      "name" : "Document Source (publisher) implementing the Generate Metadata Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with the Generate Metadata declared Options and may also declare other Options.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.Simplified.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource.Simplified"
      },
      "name" : "Document Source (publisher) implementing the Simplified Publish Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with the Simplified Publication declared Options and may also declare other Options.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-IHE.MHD.DocumentSource.UnContained.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/IHE.MHD.DocumentSource.UnContained"
      },
      "name" : "Document Source (publisher) implementing UnContained References Option",
      "description" : "IHE ITI Mobile access to Health Documents (MHD) - Document Source (publisher) - with UnContained Option.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceComprehensive.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceComprehensive"
      },
      "name" : "DocumentReference for Comprehensive fully filled metadata",
      "description" : "Example of a Comprehensive DocumentReference resource. This is fully filled for all mandatory elements and all optional elements.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceComprehensiveDelayedAssembly.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceComprehensiveDelayedAssembly"
      },
      "name" : "DocumentReference for Comprehensive fully filled metadata for a Deferred Creation",
      "description" : "Example of a Comprehensive DocumentReference resource. \r\n- This is fully filled for all mandatory elements and all optional elements.\r\n- This specifies a Delayed Document Assembly Document.\r\n  - Thus the hash is the fixed value da39a3ee5e6b4b0d3255bfef95601890afd80709\r\n  - and the size is explicitly zero\r\n  - and when a Document Consumer retrieves the URL, then the document will be assembled and returned to it\r\n  - and the DocumentReference would be updated with the resulting hash and size thus becoming a static entry",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceComprehensiveWithBinary.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceComprehensiveWithBinary"
      },
      "name" : "DocumentReference for Comprehensive fully filled metadata for a document in a Binary",
      "description" : "Example of a Comprehensive DocumentReference resource. \r\n- This is fully filled for all mandatory elements.\r\n- This specifies a Document in a Binary.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceComprehensiveOnDemand.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceComprehensiveOnDemand"
      },
      "name" : "DocumentReference for Comprehensive fully filled metadata for a On-Demand document",
      "description" : "Example of a Comprehensive DocumentReference resource. \r\n- This is fully filled for all mandatory elements.\r\n- This specifies a On-Demand Document.\r\n  - Thus the hash is not provided\r\n  - and the size is not provided\r\n  - and when a Document Consumer retrieves the URL, then a new document will be created and returned to it\r\n  - and a linked snapshot DocumentReference would be created with the resulting hash and size thus becoming a static entry",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-ex-patchParameters.html"
      }],
      "reference" : {
        "reference" : "Parameters/ex-patchParameters"
      },
      "name" : "DocumentReference for Comprehensive metadata beeing replaced",
      "description" : "Example of a comprehensive DocumentReference resource beeing replaced",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Patch.Parameters"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceUnContainedFully.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceUnContainedFully"
      },
      "name" : "DocumentReference for Comprehensive minimally filled metadata",
      "description" : "Example of a UnContained References Option with Comprehensive DocumentReference resource. This is fully filled for all mandatory elements and optional elements.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.UnContained.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceUnContained.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceUnContained"
      },
      "name" : "DocumentReference for Comprehensive minimally metadata",
      "description" : "Example of a Comprehensive DocumentReference resource. This is minimally filled for all mandatory elements.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.UnContained.Comprehensive.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceMinimal.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceMinimal"
      },
      "name" : "DocumentReference for Minimal metadata",
      "description" : "Example of a minimal DocumentReference resource. This is very unlikely to be acceptable anywhere, but it is the minimum required.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceMinimalEncounter.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceMinimalEncounter"
      },
      "name" : "DocumentReference for Minimal metadata with an encounter",
      "description" : "Example of a minimal DocumentReference resource. This has minimal metadata plus an encounter and custodian.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-DocumentReferenceSimplifiedPublish.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-DocumentReferenceSimplifiedPublish"
      },
      "name" : "DocumentReference for Simplified Publish with an encounter",
      "description" : "Example of a Simplified Publish DocumentReference resource. This has minimal metadata plus an encounter and custodian.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.SimplifiedPublish.DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-ex-binary.html"
      }],
      "reference" : {
        "reference" : "Binary/ex-binary"
      },
      "name" : "Dummy Binary document that says: Hello World",
      "description" : "For Bundling Example binary that \n- holds \\\"Hello World\\\"\n- size 11\n- hash 0a4d55a8d778e5022fab701977c5d840bbc486d0\n- base64 of the hash Ck1VqNd45QIvq3AZd8XYQLvEhtA=",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-dummyBundleDocAndBinary.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-dummyBundleDocAndBinary"
      },
      "name" : "Dummy Bundle with DocumentReference + Binary",
      "description" : "Dummy Bundle with a DocumentReferenece and Binary\r\n- with 1 documentReference\r\n- with 1 document Binary",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-ex-device.html"
      }],
      "reference" : {
        "reference" : "Device/ex-device"
      },
      "name" : "Dummy Device example",
      "description" : "Dummy Device example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-documentreference2.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-documentreference2"
      },
      "name" : "Dummy DocumentReference 2 example",
      "description" : "Dummy DocumentReference 2 example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ex-documentreference.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ex-documentreference"
      },
      "name" : "Dummy DocumentReference example",
      "description" : "Dummy DocumentReference example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-ex-encounter.html"
      }],
      "reference" : {
        "reference" : "Encounter/ex-encounter"
      },
      "name" : "Dummy Encounter example",
      "description" : "Dummy Encounter example for completness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-list.html"
      }],
      "reference" : {
        "reference" : "List/ex-list"
      },
      "name" : "Dummy List example",
      "description" : "Dummy List example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-ex-organization.html"
      }],
      "reference" : {
        "reference" : "Organization/ex-organization"
      },
      "name" : "Dummy Organization example",
      "description" : "Dummy Organization example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-ex-patient.html"
      }],
      "reference" : {
        "reference" : "Patient/ex-patient"
      },
      "name" : "Dummy Patient example",
      "description" : "Dummy patient example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-ex-practitioner.html"
      }],
      "reference" : {
        "reference" : "Practitioner/ex-practitioner"
      },
      "name" : "Dummy Practitioner example",
      "description" : "Dummy Practitioner example for completeness sake. No actual use of this resource other than an example target",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.EntryUUID.Identifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.EntryUUID.Identifier"
      },
      "name" : "entryUUID Identifier",
      "description" : "entryUUID Identifier holding a UUID",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-ex-input-binary.html"
      }],
      "reference" : {
        "reference" : "Parameters/ex-input-binary"
      },
      "name" : "ex-input-binary",
      "description" : "example Parameters with a binary. Note that the Binary is not a CDA or FHIR document, but is provided for example purposes.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.GenerateMetadata.Parameters.In"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-ex-input-doc-bundle.html"
      }],
      "reference" : {
        "reference" : "Parameters/ex-input-doc-bundle"
      },
      "name" : "ex-input-doc-bundle",
      "description" : "example Parameters with a Document Bundle",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.GenerateMetadata.Parameters.In"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-compEmailPackage.html"
      }],
      "reference" : {
        "reference" : "List/ex-compEmailPackage"
      },
      "name" : "Example Comprehensive Email SubmissionSet",
      "description" : "SubmissionSet in List resource conforming Comprehensive metadata with an intendedRecipient",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.SubmissionSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-compFolder.html"
      }],
      "reference" : {
        "reference" : "List/ex-compFolder"
      },
      "name" : "Example Comprehensive Folder",
      "description" : "Folder in List resource conforming only to Comprehensive metadata",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.Folder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-compSubmissionSetFull.html"
      }],
      "reference" : {
        "reference" : "List/ex-compSubmissionSetFull"
      },
      "name" : "Example Comprehensive Full SubmissionSet",
      "description" : "SubmissionSet in List resource conforming fully to Comprehensive metadata. This has all elements fully populated.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.SubmissionSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-compSubmissionSetList.html"
      }],
      "reference" : {
        "reference" : "List/ex-compSubmissionSetList"
      },
      "name" : "Example Comprehensive SubmissionSet",
      "description" : "SubmissionSet in List resource conforming minimally to Comprehensive metadata",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.SubmissionSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-ex-b-binary.html"
      }],
      "reference" : {
        "reference" : "Binary/ex-b-binary"
      },
      "name" : "Example document that says: Hello World",
      "description" : "Example binary that holds just Hello World\r\n- size 11\r\n- hash 0a4d55a8d778e5022fab701977c5d840bbc486d0\r\n- base64 of the hash Ck1VqNd45QIvq3AZd8XYQLvEhtA=",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-minimalFolder.html"
      }],
      "reference" : {
        "reference" : "List/ex-minimalFolder"
      },
      "name" : "Example Minimal Folder",
      "description" : "Folder in List resource conforming only to Minimal metadata",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.Folder"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-fhir-document-bundle.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-fhir-document-bundle"
      },
      "name" : "Example of a FHIR-Document Bundle",
      "description" : "An example of a FHIR-Document Bundle",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-findDocumentListsResponse.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-findDocumentListsResponse"
      },
      "name" : "Example of a Find Document Lists Response Message with a folder",
      "description" : "Example of a Find Documents List Response Bundle witha folder",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentListsResponseMessage"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-findDocumentReferencesResponse.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-findDocumentReferencesResponse"
      },
      "name" : "Example of a Find Document References Response Message",
      "description" : "Example of a Find Document References Bundle Search Set with minimal DocumentReference, and one with a homeCommunityId value populated.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferencesResponseMessage"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-findDocumentReferencesResponseFullTextSearch.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-findDocumentReferencesResponseFullTextSearch"
      },
      "name" : "Example of a Find Document References Response Message with the Full-Text Search Option",
      "description" : "Example of a Find Document References Bundle search set containing a single DocumentReference and using the Full-Text Search Option",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferencesResponseMessageFullTextSearch"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-FindDocumentReferences.html"
      }],
      "reference" : {
        "reference" : "Bundle/FindDocumentReferences"
      },
      "name" : "Example of a FindDocumentReferences Response Bundle",
      "description" : "An example of a searchset Bundle with one DocumentReference as returned by a FindDocumentReferences query",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferencesComprehensiveResponseMessage"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-comprehensiveProvideDocumentBundleDocument.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-comprehensiveProvideDocumentBundleDocument"
      },
      "name" : "Example Provide Bundle with a FHIR-Document",
      "description" : "An example of a Comprehensive Provide Document Bundle containing a DocumentReference and a FHIR-Document Bundle. This is an example of using a FHIR-Document Bundle rather than a Binary resource to carry the document content.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-compSubmissionSetFullUnContained.html"
      }],
      "reference" : {
        "reference" : "List/ex-compSubmissionSetFullUnContained"
      },
      "name" : "Example UnContained Comprehensive Full SubmissionSet",
      "description" : "SubmissionSet in List resource conforming fully to UnContained References Option and Comprehensive Metadata Option. This has all elements fully populated.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.UnContained.Comprehensive.SubmissionSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FhirStatusVsStatusCode.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FhirStatusVsStatusCode"
      },
      "name" : "FHIR status vs ebRIM Status Type Code",
      "description" : "map between XDS ebRIM Status Type Codes and MHD FHIR DocumentReference.status code.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-full-text-search-match-snippet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-full-text-search-match-snippet"
      },
      "name" : "Full-Text Search Match Snippet",
      "description" : "This extension contains a text snippet describing the context of a full-text search match. It highlights relevant content that corresponds to the provided search terms and provides a concise preview of the search result.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-full-text-search-match-total-hits.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-full-text-search-match-total-hits"
      },
      "name" : "Full-Text Search Match Total Hits",
      "description" : "This extension contains the total number of full-text search matches found within a document (e.g. a PDF).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-generate-metadata.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/generate-metadata"
      },
      "name" : "Generate a DocumentReference from a document",
      "description" : "The $generate-metadata Operation definition. \n\nThis operation is needed as the $generate in FHIR R4 is not properly defined, and thus has incorrect parameters. \nThe MHD $generate-metadata should be replaced when MHD is upgraded to FHIR R5/R6\nThis MHD $generate-metadata is modeled after the expected changes in FHIR R5/R6, and follows the example given in FHIR R4:",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.GenerateMetadata.Parameters.In.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.GenerateMetadata.Parameters.In"
      },
      "name" : "IHE MHD GenerateMetadata Parameters In",
      "description" : "The Input Parameters for the $generate-metadata operation\r\n- Input: binary, bundle",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-IHE.MHD.MHDIdentifierType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/IHE.MHD.MHDIdentifierType"
      },
      "name" : "IHE MHD Identifier Types",
      "description" : "Code System for Identifier.type values defined in IHE MHD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-IHE.MHD.MHDIdentifierTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/IHE.MHD.MHDIdentifierTypeVS"
      },
      "name" : "IHE MHD Identifier Types ValueSet",
      "description" : "ValueSet for Identifier.type values defined in IHE MHD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-intendedRecipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-intendedRecipient"
      },
      "name" : "Intended recipient of the SubmissionSet",
      "description" : "holds the identity of the organization or person the SubmissionSet is intended. For XDR and eMail (e.g. Direct) this tends to be a Practitioner or Patient with a telecom holding an email, but this is not strictly required.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.List.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.List"
      },
      "name" : "MHD common List with designationType",
      "description" : "A profile on the List resource for MHD. Used with both Folder and SubmissionSet.\r\n- MHD adds a codeable Concept to List for use with Folder and SubmissionSet",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Comprehensive.ProvideBundle.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
      },
      "name" : "MHD Comprehensive Provide Document Bundle",
      "description" : "A profile on the Bundle transaction for ITI-65 Provide Document resources with Comprehensive Metadata for MHD.\r\n\r\n- [Comprehensive Metadata](StructureDefinition-IHE.MHD.Comprehensive.ProvideBundle.html): `https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle`\r\n  - this is otherwise known as XDS-on-FHIR\r\n  - shall be a Transaction Bundle\r\n  - all resources shall be compliant with comprehensive constraints, they may be marked comprehensive\r\n  - shall create a [SubmissionSet type List](StructureDefinition-IHE.MHD.Minimal.SubmissionSet.html) that is either minimal, comprehensive, or unContained\r\n  - may create one or more [DocumentReference](StructureDefinition-IHE.MHD.Minimal.DocumentReference.html) that is either minimal, comprehensive, or unContained\r\n    - with a document as a [Binary](http://hl7.org/fhir/R4/binary.html)\r\n    - or, when implementing the **ITI-65 FHIR Document Publish** option, a [FHIR Document Bundle](http://hl7.org/fhir/R4/bundle.html)\r\n  - may create/update one or more [Folder type List](StructureDefinition-IHE.MHD.Minimal.Folder.html) that is either minimal, comprehensive, or unContained\r\n  - may create/update/read one [Patient](http://hl7.org/fhir/R4/patient.html)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Comprehensive.DocumentReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"
      },
      "name" : "MHD DocumentReference Comprehensive",
      "description" : "A profile on the DocumentReference resource for MHD Comprehensive Option with Contained (not UnContained), compatible with XDS-on-FHIR and XCA use.\r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR DocumentReference implementation of the \r\n- ebRIM implementation at [3:4.2.3.2 Document Entry](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.2).\r\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.UnContained.Comprehensive.DocumentReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.UnContained.Comprehensive.DocumentReference"
      },
      "name" : "MHD DocumentReference Comprehensive UnContained References Option",
      "description" : "A profile on the DocumentReference resource for MHD with Comprehensive Metadata Option but without a requirement for contained author, authenticator, or sourcePatientInfo. \r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR DocumentReference implementation of the \r\n- ebRIM implementation at [3:4.2.3.2 Document Entry](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.2).\r\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.SimplifiedPublish.DocumentReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.SimplifiedPublish.DocumentReference"
      },
      "name" : "MHD DocumentReference for Simplified Publish",
      "description" : "A profile on the DocumentReference resource for MHD Simplified Publish constraints. \n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \n- the use defined here is FHIR DocumentReference implementation of the \n- ebRIM implementation at [3:4.2.3.2 Document Entry](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.2).\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)\n\nSimplified Publish\n- Similar to Minimal Metadata constraints\n  - must be status current\n  - must have a patient indicated\n- uses attachment.data to carry the document, rather than attachment.url\n  - so that the Simplified Publish is a simple POST of the DocumentReference\n  - Document Recipient is expected to extract the .data, use .url",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Minimal.DocumentReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Minimal.DocumentReference"
      },
      "name" : "MHD DocumentReference Minimal",
      "description" : "A profile on the DocumentReference resource for MHD with minimal metadata constraints. \r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR DocumentReference implementation of the \r\n- ebRIM implementation at [3:4.2.3.2 Document Entry](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.2).\r\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Patch.Parameters.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Patch.Parameters"
      },
      "name" : "MHD DocumentReference Patch Parameters",
      "description" : "A profile on the Parameters resource to update the superseded DocumentReference status.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DocumentReferenceStats.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DocumentReferenceStats"
      },
      "name" : "MHD DocumentReference status codes",
      "description" : "ValueSet that does not include entered-in-error as that does not map",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentListsResponseMessage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentListsResponseMessage"
      },
      "name" : "MHD Find Document Lists Response Message",
      "description" : "A profile on the Find Document Lists Response message for ITI-66",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentReferencesComprehensiveResponseMessage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentReferencesComprehensiveResponseMessage"
      },
      "name" : "MHD Find Document References Comprehensive Response message",
      "description" : "A profile on the Find Document References Comprehensive Response message for ITI-67",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentReferencesResponseMessage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentReferencesResponseMessage"
      },
      "name" : "MHD Find Document References Response message",
      "description" : "A profile on the Find Document References Response message for ITI-67",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.FindDocumentReferencesResponseMessageFullTextSearch.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.FindDocumentReferencesResponseMessageFullTextSearch"
      },
      "name" : "MHD Find Document References Response message with Full-Text Search Option",
      "description" : "A profile on the Find Document References Response message for ITI-67 with Full-Text Search Option",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Comprehensive.Folder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Comprehensive.Folder"
      },
      "name" : "MHD Folder Comprehensive",
      "description" : "A profile on the List resource for MHD Comprehensive Metadata Folder. Note UnContained has no impact on Folder.\r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR List for use as a Folder implementation of the \r\n- ebRIM implementation at [3:4.2.3.4 Folder Attributes](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.4).\r\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-MHDprovideFolderActions.html"
      }],
      "reference" : {
        "reference" : "ValueSet/MHDprovideFolderActions"
      },
      "name" : "MHD Folder List Types ValueSet",
      "description" : "A ValueSet of the allowed actions in a ITI-65 Provide Document Bundle for the Folder List type Resources. Where Folders are allowed to be Updated in addition to Created.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Minimal.Folder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Minimal.Folder"
      },
      "name" : "MHD Folder Minimal",
      "description" : "A profile on the List resource for MHD use as a Folder with minimal metadata constraints. \r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR List for use as a Folder implementation of the \r\n- ebRIM implementation at [3:4.2.3.4 Folder Attributes](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.4).\r\n- with use-cases and constraints found in [3:4.3 Additional Document Sharing Requirements](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-MHDlistTypes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/MHDlistTypes"
      },
      "name" : "MHD List Types",
      "description" : "To use the List resource for two different use-cases we define a code-system with the types of List needed in MHD",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-MHDlistTypesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/MHDlistTypesVS"
      },
      "name" : "MHD List Types ValueSet",
      "description" : "ValueSet of the MHD List Types allowed",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Minimal.ProvideBundle.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Minimal.ProvideBundle"
      },
      "name" : "MHD Minimal Provide Document Bundle",
      "description" : "A profile on the Bundle transaction for ITI-65 Provide Document resources with Minimal metadata for MHD.\r\n\r\n- [Minimal Metadata](StructureDefinition-IHE.MHD.Minimal.ProvideBundle.html): `https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.ProvideBundle`\r\n  - shall be a Transaction Bundle\r\n  - all resources shall be compliant with minimal constraints, they may be marked minimal, comprehensive, or unContained\r\n  - shall create a [SubmissionSet type List](StructureDefinition-IHE.MHD.Minimal.SubmissionSet.html) that is either minimal, comprehensive, or unContained\r\n  - may create one or more [DocumentReference](StructureDefinition-IHE.MHD.Minimal.DocumentReference.html) that is either minimal, comprehensive, or unContained\r\n    - with a document as a [Binary](http://hl7.org/fhir/R4/binary.html)\r\n    - or, when implementing the **ITI-65 FHIR Document Publish** option, a [FHIR Document Bundle](http://hl7.org/fhir/R4/bundle.html)\r\n  - when DocumentReference replace is used the UpdateDocumentRefs slice is used to indicate the superseded DocumentReference\r\n  - may create/update one or more [Folder type List](StructureDefinition-IHE.MHD.Minimal.Folder.html) that is either minimal, comprehensive, or unContained\r\n  - may create/update/read one [Patient](http://hl7.org/fhir/R4/patient.html)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-MHDprovidePatientActions.html"
      }],
      "reference" : {
        "reference" : "ValueSet/MHDprovidePatientActions"
      },
      "name" : "MHD Patient Types ValueSet",
      "description" : "A ValueSet of the allowed actions in a ITI-65 Provide Document Bundle for the Patient type Resource. Where Patient would typically be indicated as a GET (read), but might be created or updated depending on policy.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.ProvideDocumentBundleResponse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
      },
      "name" : "MHD Provide Document Bundle Response",
      "description" : "A profile on the Bundle transaction-response for ITI-65 Provide Document Bundle response.\n\n- shall be a transaction response\n- shall have at least 1 entry for each entry in the request, in the same order as received in the request\n  - entry response location must be indicated",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Comprehensive.SubmissionSet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Comprehensive.SubmissionSet"
      },
      "name" : "MHD SubmissionSet Comprehensive",
      "description" : "A profile on the List resource for MHD Comprehensive SubmissionSet.\r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR List for use as a SubmissionSet implementation of the \r\n- ebRIM implementation at [3:4.2.3.3 SubmissionSet Attributes](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.3).\r\n- with use-cases and constraints found in [3:4.3.1 Submission Metadata Attribute Optionality](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3.1) for \r\n  - MHD Comprehensive Option Document Source\r\n  - aka the XDS Document Source requirements\r\n  - aka the XDR Document Source requirements",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.UnContained.Comprehensive.SubmissionSet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.UnContained.Comprehensive.SubmissionSet"
      },
      "name" : "MHD SubmissionSet Comprehensive UnContained",
      "description" : "A profile on the List resource for MHD UnContained Comprehensive SubmissionSet.\r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR List for use as a SubmissionSet implementation of the \r\n- ebRIM implementation at [3:4.2.3.3 SubmissionSet Attributes](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.3).\r\n- with use-cases and constraints found in [3:4.3.1 Submission Metadata Attribute Optionality](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3.1) for \r\n  - MHD Document Source that has implemented both Comprehensive Metadata Option and UnContained References Option",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.Minimal.SubmissionSet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.Minimal.SubmissionSet"
      },
      "name" : "MHD SubmissionSet Minimal",
      "description" : "A profile on the List resource for MHD SubmissionSet.\r\n- MHD is based on the [IHE Document Sharing](https://profiles.ihe.net/ITI/HIE-Whitepaper/index.html) model, \r\n- the [3:4.1 Abstract Metadata Model](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.1.html#4.1), and \r\n- the use defined here is FHIR List for use as a SubmissionSet implementation of the \r\n- ebRIM implementation at [3:4.2.3.3 SubmissionSet Attributes](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.3).\r\n- with use-cases and constraints found in [3:4.3.1 Submission Metadata Attribute Optionality](https://profiles.ihe.net/ITI/TF/Volume3/ch-4.3.html#4.3.1) for \r\n  - Document Source implementing not implementing Comprehensive Metadata Option\r\n  - Document Source implementing UnContained Option but not Comprehensive Option\r\n  - equivalent to XDR Document Source implementing Metadata-Limited Option requirements\r\n  - aka the default MHD Document Source",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.UnContained.Comprehensive.ProvideBundle.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.UnContained.Comprehensive.ProvideBundle"
      },
      "name" : "MHD UnContained Comprehensive Provide Document Bundle",
      "description" : "A profile on the Bundle transaction for ITI-65 Provide Document resources with UnContained allowed but requiring Comprehensive Metadata for MHD.\r\n\r\n- [UnContained Comprehensive Metadata](StructureDefinition-IHE.MHD.UnContained.Comprehensive.ProvideBundle.html): `https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.UnContained.Comprehensive.ProvideBundle` \r\n  - note that Minimal Metadata does not require containment, so UnContained Minimal is the same as Minimal Metadata\r\n  - note that UnContained only applies to DocumentReference and SubmissionSet type Lists; so the following apply\r\n  - shall be a Transaction Bundle\r\n  - all resources shall be compliant with comprehensive unContained constraints, they may be marked comprehensive unContained\r\n  - shall create a [SubmissionSet type List](StructureDefinition-IHE.MHD.Minimal.SubmissionSet.html) that is either minimal, comprehensive, or unContained\r\n  - may create one or more [DocumentReference](StructureDefinition-IHE.MHD.Minimal.DocumentReference.html) that is either minimal, comprehensive, or unContained\r\n    - with a document as a [Binary](http://hl7.org/fhir/R4/binary.html)\r\n    - or, when implementing the **ITI-65 FHIR Document Publish** option, a [FHIR Document Bundle](http://hl7.org/fhir/R4/bundle.html)\r\n  - may create/update one or more [Folder type List](StructureDefinition-IHE.MHD.Minimal.Folder.html) that is either minimal, comprehensive, or unContained\r\n  - may create/update/read one [Patient](http://hl7.org/fhir/R4/patient.html)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-comprehensiveProvideDocumentBundleComplete.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-comprehensiveProvideDocumentBundleComplete"
      },
      "name" : "Provide Document Bundle with complete Comprehensive metadata of one document",
      "description" : "Example of a complete comprehensive Provide Document Bundle for a publication.\r\n- The bundle contains\r\n  - SubmissionSet - identifies one documentReference\r\n  - Folder - identifies one documentReference\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Patient is contained in the DocumentReference\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-unContainedComprehensiveProvideDocumentBundleComplete.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-unContainedComprehensiveProvideDocumentBundleComplete"
      },
      "name" : "Provide Document Bundle with complete UnContained Comprehensive metadata of one document",
      "description" : "Example of a complete uncontained comprehensive Provide Document Bundle for a publication.\r\n- The bundle contains\r\n  - SubmissionSet - identifies one documentReference\r\n  - Folder - identifies one documentReference\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Practitioner and Organization are references\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.UnContained.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-comprehensiveProvideDocumentBundleMultiple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-comprehensiveProvideDocumentBundleMultiple"
      },
      "name" : "Provide Document Bundle with Comprehensive metadata of multiple static document(s)",
      "description" : "Example of a comprehensive Provide Document Bundle for a publication.\r\n- The bundle contains\r\n  - SubmissionSet - identifies the documentReference(s)\r\n  - DocumentReference - First DocumentReference\r\n  - Binary - the first document\r\n  - DocumentReference - Second DocumentReference\r\n  - Binary - the second document\r\n  - the Patient is contained in the DocumentReference\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-comprehensiveProvideDocumentBundleSimple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-comprehensiveProvideDocumentBundleSimple"
      },
      "name" : "Provide Document Bundle with Comprehensive metadata of one document",
      "description" : "Example of a comprehensive Provide Document Bundle for a publication.\r\n- The bundle contains\r\n  - SubmissionSet - identifies one documentReference\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Patient is contained in the DocumentReference\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-comprehensiveProvideDocumentBundleReplace.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-comprehensiveProvideDocumentBundleReplace"
      },
      "name" : "Provide Document Bundle with Comprehensive metadata of one document which replaces another document",
      "description" : "Example of a comprehensive Provide Document Bundle for a publication which replaces another document.\r\n- The bundle contains\r\n  - SubmissionSet - identifies one documentReference\r\n  - DocumentReference - Two DocumentReferences, an update to the old DocumentReference and the new DocumentReferences relates to the old DocumentReference\r\n  - Binary - the document\r\n  - the Patient is contained in the DocumentReference\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-minimalProvideDocumentBundleSimple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-minimalProvideDocumentBundleSimple"
      },
      "name" : "Provide Document Bundle with Minimal metadata of one document",
      "description" : "Example of a minimal Provide Document Bundle for a push to an email intended recipient.\r\n- The bundle contains\r\n  - SubmissionSet - identifies to whom this is going and one documentReference\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Patient, as this is a push to a recipient that does not share a patient directory",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-minimalProvideDocumentBundleSimpleContained.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-minimalProvideDocumentBundleSimpleContained"
      },
      "name" : "Provide Document Bundle with Minimal metadata of one document with sourcePatientInfo",
      "description" : "Example of a minimal Provide Document Bundle for a push to an email intended recipient.\r\n- The bundle contains\r\n  - SubmissionSet - identifies to whom this is going and one documentReference\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Patient is contained in the DocumentReference. This would be more classic XDR/XDM model. Note there is no mention of the patient in the SubmissionSet in this case (hence minimal metadata), and if multiple documents were sent they would implicitly be the same patient, presumably with the same contained Patient; but given it is a contained Patinet there is no way to computably prove this beyond exact comparison of the contained object.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-ProvideDocumentBundle-addToFolder.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-ProvideDocumentBundle-addToFolder"
      },
      "name" : "Provide Document Bundle with one document to be added to an existing folder",
      "description" : "Example of a comprehensive Provide Document Bundle for a publication and added to an existing folder.\r\n- The bundle contains\r\n  - SubmissionSet - identifies one documentReference\r\n  - Folder - existing Folder to be updated\r\n  - DocumentReference - One DocumentReference\r\n  - Binary - the document\r\n  - the Patient is contained in the DocumentReference\r\n  - the Patient is also a reference to a PIXm/PDQm retrieved Resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-sourceId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-sourceId"
      },
      "name" : "Publisher organization identity of the SubmissionSet",
      "description" : "The globally unique, immutable, identifier of the entity that contributed the SubmissionSet. When a broker is involved in sending SubmissionSets from a collection of client systems, it shall use a different sourceId for submissions from each separate system to allow for tracking. The format of the identifier is an OID.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-comprehensiveProvideDocumentBundleComplete.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-comprehensiveProvideDocumentBundleComplete"
      },
      "name" : "Response to fully populated Provide Document Bundle with one document with sourcePatientInfo",
      "description" : "Response bundle example given ex-comprehensiveProvideDocumentBundleComplete\n- for every entry in order given\n  - successful create of SubmissionSet\n  - successful create of Folder\n  - successful create of DocumentReference - classic XDS static document\n  - successful create of Binary",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-unContainedComprehensiveProvideDocumentBundleCompt.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-unContainedComprehensiveProvideDocumentBundleCompt"
      },
      "name" : "Response to fully populated Provide Document Bundle with one document with sourcePatientInfo",
      "description" : "Response bundle example given ex-unContainedComprehensiveProvideDocumentBundleComplete\n- for every entry in order given\n  - successful create of SubmissionSet\n  - successful create of DocumentReference - classic XDS static document\n  - successful create of Binary",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-minimalProvideDocumentBundleSimple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-minimalProvideDocumentBundleSimple"
      },
      "name" : "Response to Provide Document Bundle with Minimal metadata of one document",
      "description" : "Response bundle example given ex-minimalProvideDocumentBundleSimple\r\n- for every entry in order given\r\n  - successful create of SubmissionSet\r\n  - successful create of DocumentReference\r\n  - successful create of Binary\r\n  - successful create of Patient\r\n\r\nNote that in the case of the Patient, it is likely this successful create is just a fake success, as it was more likely to have been matched to a patient that already existed and THAT id was returned. (Alternative could have been a 303)",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-minimalProvideDocumentBundleSimpleContained.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-minimalProvideDocumentBundleSimpleContained"
      },
      "name" : "Response to Provide Document Bundle with Minimal metadata of one document with sourcePatientInfo",
      "description" : "Response bundle example given ex-minimalProvideDocumentBundleSimpleContained\n- for every entry in order given\n  - successful create of SubmissionSet\n  - successful create of DocumentReference\n  - successful create of Binary",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-comprehensiveProvideDocumentBundleMultiple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-comprehensiveProvideDocumentBundleMultiple"
      },
      "name" : "Response to Provide Document Bundle with multiple documents with sourcePatientInfo",
      "description" : "Response bundle example given ex-comprehensiveProvideDocumentBundleMultiple\n- for every entry in order given\n  - successful create of SubmissionSet\n  - successful create of DocumentReference - classic XDS static document\n  - successful create of Binary",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-ex-response-comprehensiveProvideDocumentBundleSimple.html"
      }],
      "reference" : {
        "reference" : "Bundle/ex-response-comprehensiveProvideDocumentBundleSimple"
      },
      "name" : "Response to Provide Document Bundle with one document with sourcePatientInfo",
      "description" : "Response bundle example given ex-comprehensiveProvideDocumentBundleSimple\n- for every entry in order given\n  - successful create of SubmissionSet\n  - successful create of DocumentReference - classic XDS static document\n  - successful create of Binary",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-DocumentReference-Creation.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/DocumentReference-Creation"
      },
      "name" : "search on the DocumentReference.content.attachment.creation element",
      "description" : "Search Parameter extension enabling clients to search on the DocumentReference.content.attachment.creation element",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-List-DesignationType.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/List-DesignationType"
      },
      "name" : "search on the IHE defined extension for designationType",
      "description" : "This SearchParameter enables finding Lists by the designationType code in a submissionSet or folder.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-IHE-TargetCommunityIdList.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/IHE-TargetCommunityIdList"
      },
      "name" : "search on the IHE defined extension for homeCommunityId",
      "description" : "This SearchParameter enables finding by the homeCommunityId where DocumentReference, submissionSet, or folder exist.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-List-SourceId.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/List-SourceId"
      },
      "name" : "search on the IHE defined extension for SourceId",
      "description" : "This SearchParameter enables finding Lists by the SourceId of a submissionSet.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-DocumentReference-Full-Text-Search.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/DocumentReference-Full-Text-Search"
      },
      "name" : "search on the textual content of the represented document",
      "description" : "Searches the textual content of the represented document. The search is performed against the content available via DocumentReference.content.attachment.url.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "List-ex-minimalSubmissionSet.html"
      }],
      "reference" : {
        "reference" : "List/ex-minimalSubmissionSet"
      },
      "name" : "SubmissionSet for Minimal metadata",
      "description" : "Example of a minimal submissionSet in List resource.",
      "exampleCanonical" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.SubmissionSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ihe-HomeCommunityId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ihe-HomeCommunityId"
      },
      "name" : "The homeCommunityId where the artifact resides",
      "description" : "The globally unique, immutable, identifier of the homeCommunityId entity where this artifact resides. The format of the value is an OID.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.UniqueIdIdentifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.UniqueIdIdentifier"
      },
      "name" : "uniqueId Identifier",
      "description" : "uniqueId Identifier\r\n\r\n- see [Appendix Z](https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#z.9.1-identifier-type)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IHE.MHD.SubmissionSetUniqueIdIdentifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IHE.MHD.SubmissionSetUniqueIdIdentifier"
      },
      "name" : "uniqueId Identifier for SubmissionSet",
      "description" : "uniqueId Identifier holding a OID",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "MHD Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1331_actors_and_transactions.html"
        }],
        "nameUrl" : "1331_actors_and_transactions.html",
        "title" : "1:33.1 Actors and Transactions",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1332_actor_options.html"
        }],
        "nameUrl" : "1332_actor_options.html",
        "title" : "1:33.2 Actor Options",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1333_required_grouping.html"
        }],
        "nameUrl" : "1333_required_grouping.html",
        "title" : "1:33.3 Required Grouping",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1334_overview.html"
        }],
        "nameUrl" : "1334_overview.html",
        "title" : "1:33.4 Overview",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1335_security_considerations.html"
        }],
        "nameUrl" : "1335_security_considerations.html",
        "title" : "1:33.5 Security Considerations",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "1336_cross_profile_considerations.html"
        }],
        "nameUrl" : "1336_cross_profile_considerations.html",
        "title" : "1:33.6 Cross Profile Considerations",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-65.html"
        }],
        "nameUrl" : "ITI-65.html",
        "title" : "2:3.65 Provide Document Bundle [ITI-65]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-66.html"
        }],
        "nameUrl" : "ITI-66.html",
        "title" : "2:3.66 Find Document Lists [ITI-66]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-67.html"
        }],
        "nameUrl" : "ITI-67.html",
        "title" : "2:3.67 Find Document References [ITI-67]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-68.html"
        }],
        "nameUrl" : "ITI-68.html",
        "title" : "2:3.68 Retrieve Document [ITI-68]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-105.html"
        }],
        "nameUrl" : "ITI-105.html",
        "title" : "2:3.105 Simplified Publish [ITI-105]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "ITI-106.html"
        }],
        "nameUrl" : "ITI-106.html",
        "title" : "2:3.106 Generate Metadata [ITI-106]",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "31_xds.html"
        }],
        "nameUrl" : "31_xds.html",
        "title" : "3:4.2.4.1 Error Codes",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "32_fhir_maps.html"
        }],
        "nameUrl" : "32_fhir_maps.html",
        "title" : "3:4.5 FHIR Maps",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "testplan.html"
        }],
        "nameUrl" : "testplan.html",
        "title" : "Test Plan",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "a_issues.html"
        }],
        "nameUrl" : "a_issues.html",
        "title" : "Issues",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "download.html"
        }],
        "nameUrl" : "download.html",
        "title" : "Download and Analysis",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
