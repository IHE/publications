# Provide Document Bundle with Comprehensive metadata of one document which replaces another document - Mobile access to Health Documents (MHD) v4.2.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Provide Document Bundle with Comprehensive metadata of one document which replaces another document**

## Example Bundle: Provide Document Bundle with Comprehensive metadata of one document which replaces another document



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ex-comprehensiveProvideDocumentBundleReplace",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.ProvideBundle"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2020-02-02T23:50:50-05:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-eeee-e00333300001",
    "resource" : {
      "resourceType" : "List",
      "id" : "aaaaaaaa-bbbb-cccc-eeee-e00333300001",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.SubmissionSet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_aaaaaaaa-bbbb-cccc-eeee-e00333300001\"> </a>SubmissionSet with Patient</div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-designationType",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "225728007"
          }]
        }
      },
      {
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-sourceId",
        "valueIdentifier" : {
          "value" : "urn:oid:1.2.3.4"
        }
      }],
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46347"
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/MHDlistTypes",
          "code" : "submissionset"
        }]
      },
      "subject" : {
        "reference" : "Patient/ex-patient"
      },
      "date" : "2020-02-02T23:50:50-05:00",
      "entry" : [{
        "item" : {
          "reference" : "urn:uuid:aaaaaaaa-bbbb-cccc-eeee-e00333300002"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "List"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-ffff-e00333300002",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "aaaaaaaa-bbbb-cccc-ffff-e00333300002",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Patch.Parameters"]
      },
      "parameter" : [{
        "name" : "operation",
        "part" : [{
          "name" : "path",
          "valueString" : "DocumentReference.status"
        },
        {
          "name" : "type",
          "valueCode" : "replace"
        },
        {
          "name" : "value",
          "valueCode" : "superseded"
        }]
      }]
    },
    "request" : {
      "method" : "PATCH",
      "url" : "DocumentReference/ex-documentreference"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-eeee-e00333300002",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "aaaaaaaa-bbbb-cccc-eeee-e00333300002",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Comprehensive.DocumentReference"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_aaaaaaaa-bbbb-cccc-eeee-e00333300002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference aaaaaaaa-bbbb-cccc-eeee-e00333300002</b></p><a name=\"aaaaaaaa-bbbb-cccc-eeee-e00333300002\"> </a><a name=\"hcaaaaaaaa-bbbb-cccc-eeee-e00333300002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-IHE.MHD.Comprehensive.DocumentReference.html\">MHD DocumentReference Comprehensive</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>masterIdentifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 60591-5}\">Patient summary Document</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 11369-6}\">History of Immunization note</span></p><p><b>subject</b>: <a href=\"Patient-ex-patient.html\">John Schmidt  Other, DoB: 1923-07-25</a></p><p><b>date</b>: 2020-02-02 23:50:50-0500</p><h3>RelatesTos</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Target</b></td></tr><tr><td style=\"display: none\">*</td><td>Replaces</td><td><a href=\"DocumentReference-ex-documentreference.html\">DocumentReference: status = current</a></td></tr></table><p><b>securityLabel</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Confidentiality R}\">restricted</span></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Url</b></td><td><b>Size</b></td><td><b>Hash</b></td><td><b>Title</b></td><td><b>Creation</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td>English</td><td><a href=\"Bundle-ex-comprehensiveProvideDocumentBundleReplace.html#urn-uuid-aaaaaaaa-bbbb-cccc-eeee-e00333300003\">Binary: text/plain (32 bytes base64)</a></td><td>24</td><td><code>6OMXIUMAFYfLdQhEaqCS61GZWAk=</code></td><td>Thanks for all the fish</td><td>2020-02-02 23:50:50-0500</td></tr></table><p><b>format</b>: <a href=\"https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.6.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds-sd.58text.582008\">IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds-sd:text:2008</a> (ITI XDS-SD TEXT)</p></blockquote><h3>Contexts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>FacilityType</b></td><td><b>PracticeSetting</b></td><td><b>SourcePatientInfo</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 82242000}\">Children's hospital</span></td><td><span title=\"Codes:{http://snomed.info/sct 408467006}\">Adult mental illness - specialty</span></td><td><a href=\"#hcaaaaaaaa-bbbb-cccc-eeee-e00333300002/aaaaaaaa-bbbb-cccc-dddd-e00333300004\">Dee Schmidt  (no stated gender), DoB Unknown ( http://example.org/patients#mrn-1234)</a></td></tr></table><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Patient #aaaaaaaa-bbbb-cccc-dddd-e00333300004</b></p><a name=\"aaaaaaaa-bbbb-cccc-eeee-e00333300002/aaaaaaaa-bbbb-cccc-dddd-e00333300004\"> </a><a name=\"hcaaaaaaaa-bbbb-cccc-eeee-e00333300002/aaaaaaaa-bbbb-cccc-dddd-e00333300004\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Dee Schmidt  (no stated gender), DoB Unknown ( http://example.org/patients#mrn-1234)</p><hr/></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Patient",
        "id" : "aaaaaaaa-bbbb-cccc-dddd-e00333300004",
        "identifier" : [{
          "system" : "http://example.org/patients",
          "value" : "mrn-1234"
        }],
        "name" : [{
          "family" : "Schmidt",
          "given" : ["Dee"]
        }]
      }],
      "masterIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012"
      },
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "60591-5"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11369-6"
        }]
      }],
      "subject" : {
        "reference" : "Patient/ex-patient"
      },
      "date" : "2020-02-02T23:50:50-05:00",
      "relatesTo" : [{
        "code" : "replaces",
        "target" : {
          "reference" : "DocumentReference/ex-documentreference"
        }
      }],
      "securityLabel" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
          "code" : "R"
        }]
      }],
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "language" : "en",
          "url" : "urn:uuid:aaaaaaaa-bbbb-cccc-eeee-e00333300003",
          "size" : 24,
          "hash" : "6OMXIUMAFYfLdQhEaqCS61GZWAk=",
          "title" : "Thanks for all the fish",
          "creation" : "2020-02-02T23:50:50-05:00"
        },
        "format" : {
          "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
          "code" : "urn:ihe:iti:xds-sd:text:2008"
        }
      }],
      "context" : {
        "facilityType" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "82242000"
          }]
        },
        "practiceSetting" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "408467006"
          }]
        },
        "sourcePatientInfo" : {
          "reference" : "#aaaaaaaa-bbbb-cccc-dddd-e00333300004"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-eeee-e00333300003",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "aaaaaaaa-bbbb-cccc-eeee-e00333300003",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "contentType" : "text/plain",
      "data" : "VGhhbmtzIGZvciBhbGwgdGhlIGZpc2g="
    },
    "request" : {
      "method" : "POST",
      "url" : "Binary"
    }
  }]
}

```
