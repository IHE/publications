# Provide Document Bundle with Minimal metadata of one document - Mobile access to Health Documents (MHD) v4.2.5-comment

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Provide Document Bundle with Minimal metadata of one document**

## Example Bundle: Provide Document Bundle with Minimal metadata of one document

Example of a minimal Provide Document Bundle for a push to an email intended recipient.

* The bundle contains 
* SubmissionSet - identifies to whom this is going and one documentReference
* DocumentReference - One DocumentReference
* Binary - the document
* the Patient, as this is a push to a recipient that does not share a patient directory
 

Response [example](Bundle-ex-response-comprehensiveProvideDocumentBundleSimple.md)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ex-minimalProvideDocumentBundleSimple",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.ProvideBundle"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2004-10-25T23:50:50-05:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100001",
    "resource" : {
      "resourceType" : "List",
      "id" : "aaaaaaaa-bbbb-cccc-dddd-e00111100001",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.SubmissionSet"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_aaaaaaaa-bbbb-cccc-dddd-e00111100001\"> </a>SubmissionSet with Patient</div>"
      },
      "contained" : [{
        "resourceType" : "Practitioner",
        "id" : "in-practitioner2",
        "telecom" : [{
          "system" : "email",
          "value" : "JohnMoehrke@gmail.com"
        }]
      }],
      "extension" : [{
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-sourceId",
        "valueIdentifier" : {
          "value" : "urn:oid:1.2.3.4"
        }
      },
      {
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-intendedRecipient",
        "valueReference" : {
          "reference" : "#in-practitioner2"
        }
      }],
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46343"
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/MHDlistTypes",
          "code" : "submissionset"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100004"
      },
      "date" : "2004-10-25T23:50:50-05:00",
      "entry" : [{
        "item" : {
          "reference" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100002"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "List"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100002",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "aaaaaaaa-bbbb-cccc-dddd-e00111100002",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_aaaaaaaa-bbbb-cccc-dddd-e00111100002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference aaaaaaaa-bbbb-cccc-dddd-e00111100002</b></p><a name=\"aaaaaaaa-bbbb-cccc-dddd-e00111100002\"> </a><a name=\"hcaaaaaaaa-bbbb-cccc-dddd-e00111100002\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-IHE.MHD.Minimal.DocumentReference.html\">MHD DocumentReference Minimal</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>masterIdentifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012</p><p><b>status</b>: Current</p><p><b>subject</b>: <a href=\"Bundle-ex-minimalProvideDocumentBundleSimple.html#urn-uuid-aaaaaaaa-bbbb-cccc-dddd-e00111100004\">Dee Schmidt  (no stated gender), DoB Unknown</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Size</b></td><td><b>Hash</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td><a href=\"Bundle-ex-minimalProvideDocumentBundleSimple.html#urn-uuid-aaaaaaaa-bbbb-cccc-dddd-e00111100003\">Binary: text/plain (16 bytes base64)</a></td><td>11</td><td><code>Ck1VqNd45QIvq3AZd8XYQLvEhtA=</code></td></tr></table><p><b>format</b>: <a href=\"https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.5.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds-sd.58text.582008\">IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds-sd:text:2008</a> (ITI XDS-SD TEXT)</p></blockquote></div>"
      },
      "masterIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012"
      },
      "status" : "current",
      "subject" : {
        "reference" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100004"
      },
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "url" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100003",
          "size" : 11,
          "hash" : "Ck1VqNd45QIvq3AZd8XYQLvEhtA="
        },
        "format" : {
          "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
          "code" : "urn:ihe:iti:xds-sd:text:2008"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100003",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "aaaaaaaa-bbbb-cccc-dddd-e00111100003",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "contentType" : "text/plain",
      "data" : "SGVsbG8gV29ybGQ="
    },
    "request" : {
      "method" : "POST",
      "url" : "Binary"
    }
  },
  {
    "fullUrl" : "urn:uuid:aaaaaaaa-bbbb-cccc-dddd-e00111100004",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "aaaaaaaa-bbbb-cccc-dddd-e00111100004",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_aaaaaaaa-bbbb-cccc-dddd-e00111100004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient aaaaaaaa-bbbb-cccc-dddd-e00111100004</b></p><a name=\"aaaaaaaa-bbbb-cccc-dddd-e00111100004\"> </a><a name=\"hcaaaaaaaa-bbbb-cccc-dddd-e00111100004\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Dee Schmidt  (no stated gender), DoB Unknown</p><hr/></div>"
      },
      "name" : [{
        "family" : "Schmidt",
        "given" : ["Dee"]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  }]
}

```
