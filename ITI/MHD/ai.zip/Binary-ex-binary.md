# Dummy Binary document that says: Hello World - Mobile access to Health Documents (MHD) v4.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Dummy Binary document that says: Hello World**

## Example Binary: Dummy Binary document that says: Hello World

```

Hello World
```



## Resource Binary Content

text/plain:

```
[B@707f68e0
```
