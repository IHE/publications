# Example of a Find Document References Response Message - Mobile access to Health Documents (MHD) v4.2.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example of a Find Document References Response Message**

## Example Bundle: Example of a Find Document References Response Message



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ex-findDocumentReferencesResponse",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.FindDocumentReferencesResponseMessage"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST"
    }]
  },
  "type" : "searchset",
  "timestamp" : "2021-04-16T11:32:24Z",
  "total" : 2,
  "link" : [{
    "relation" : "self",
    "url" : "test.fhir.net/R4/fhir/DocumentReference?patient=9876&status=current"
  }],
  "entry" : [{
    "fullUrl" : "http://example.org/DocumentReference/in-DocumentReferenceMinimal",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "in-DocumentReferenceMinimal",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_in-DocumentReferenceMinimal\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference in-DocumentReferenceMinimal</b></p><a name=\"in-DocumentReferenceMinimal\"> </a><a name=\"hcin-DocumentReferenceMinimal\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-IHE.MHD.Minimal.DocumentReference.html\">MHD DocumentReference Minimal</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>masterIdentifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012</p><p><b>identifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012, Identifier type for XDS entryUUID/urn:uuid:7d5bb8ac-68ee-4926-85e7-b8aac8e1f09d</p><p><b>status</b>: Current</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td><a href=\"http://example.com/nowhere.txt\">http://example.com/nowhere.txt</a></td></tr></table></blockquote></div>"
      },
      "masterIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62012"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "entryUUID"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:7d5bb8ac-68ee-4926-85e7-b8aac8e1f09d"
      }],
      "status" : "current",
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "url" : "http://example.com/nowhere.txt"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/DocumentReference/in-DocumentReferenceMinimalCommunity",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "in-DocumentReferenceMinimalCommunity",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.Minimal.DocumentReference"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_in-DocumentReferenceMinimalCommunity\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference in-DocumentReferenceMinimalCommunity</b></p><a name=\"in-DocumentReferenceMinimalCommunity\"> </a><a name=\"hcin-DocumentReferenceMinimalCommunity\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-IHE.MHD.Minimal.DocumentReference.html\">MHD DocumentReference Minimal</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>The homeCommunityId where the artifact resides</b>: urn:oid:2.999.123.1740.205.55.20.13</p><p><b>masterIdentifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62013</p><p><b>identifier</b>: Identifier type for XDS UniqueId/urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62013, Identifier type for XDS entryUUID/urn:uuid:7d5bb8ac-68ee-4926-85e7-b8aac8e1f09e</p><p><b>status</b>: Current</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td><a href=\"http://example.com/nowhere2.txt\">http://example.com/nowhere2.txt</a></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-HomeCommunityId",
        "valueOid" : "urn:oid:2.999.123.1740.205.55.20.13"
      }],
      "masterIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62013"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "uniqueId"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:1.2.840.113556.1.8000.2554.53432.348.12973.17740.34205.4355.50220.62013"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/IHE.MHD.MHDIdentifierType",
            "code" : "entryUUID"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:7d5bb8ac-68ee-4926-85e7-b8aac8e1f09e"
      }],
      "status" : "current",
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "url" : "http://example.com/nowhere2.txt"
        }
      }]
    }
  }]
}

```
