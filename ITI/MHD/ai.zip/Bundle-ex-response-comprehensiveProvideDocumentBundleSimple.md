# Response to Provide Document Bundle with one document with sourcePatientInfo - Mobile access to Health Documents (MHD) v4.2.5-comment

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Response to Provide Document Bundle with one document with sourcePatientInfo**

## Example Bundle: Response to Provide Document Bundle with one document with sourcePatientInfo



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ex-response-comprehensiveProvideDocumentBundleSimple",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.ProvideDocumentBundleResponse"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST"
    }]
  },
  "type" : "transaction-response",
  "link" : [{
    "relation" : "self",
    "url" : "http://example.com/fhir"
  }],
  "entry" : [{
    "response" : {
      "status" : "201 Created",
      "location" : "List/1",
      "lastModified" : "2020-10-02T11:56:15.094+00:00"
    }
  },
  {
    "response" : {
      "status" : "201 Created",
      "location" : "DocumentReference/1",
      "lastModified" : "2020-10-02T11:56:15.095+00:00"
    }
  },
  {
    "response" : {
      "status" : "201 Created",
      "location" : "Binary/1",
      "lastModified" : "2020-10-02T11:56:15.096+00:00"
    }
  }]
}

```
