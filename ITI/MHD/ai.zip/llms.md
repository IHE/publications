# ihe.iti.mhd#4.2.4: Mobile access to Health Documents (MHD)

## Pages

* [MHD Home](index.md)
* [1:33.1 Actors and Transactions](1331_actors_and_transactions.md)
* [1:33.2 Actor Options](1332_actor_options.md)
* [1:33.3 Required Grouping](1333_required_grouping.md)
* [1:33.4 Overview](1334_overview.md)
* [1:33.5 Security Considerations](1335_security_considerations.md)
* [1:33.6 Cross Profile Considerations](1336_cross_profile_considerations.md)
* [3:.1 Error Codes](31_xds.md)
* [3:4.5 FHIR Maps](32_fhir_maps.md)
* [Artifacts Summary](artifacts.md)
* [Issues](a_issues.md)
* [Download and Analysis](download.md)
* [2:3.105 Simplified Publish [ITI-105]](ITI-105.md)
* [2:3.106 Generate Metadata [ITI-106]](ITI-106.md)
* [2:3.65 Provide Document Bundle [ITI-65]](ITI-65.md)
* [2:3.66 Find Document Lists [ITI-66]](ITI-66.md)
* [2:3.67 Find Document References [ITI-67]](ITI-67.md)
* [2:3.68 Retrieve Document [ITI-68]](ITI-68.md)
* [Test Plan](testplan.md)

## Resources

### CodeSystems

* [IHE MHD Identifier Types](CodeSystem-IHE.MHD.MHDIdentifierType.md)
* [MHD List Types](CodeSystem-MHDlistTypes.md)

### ValueSets

* [MHD DocumentReference status codes](ValueSet-DocumentReferenceStats.md)
* [IHE MHD Identifier Types ValueSet](ValueSet-IHE.MHD.MHDIdentifierTypeVS.md)
* [MHD List Types ValueSet](ValueSet-MHDlistTypesVS.md)
* [MHD Folder List Types ValueSet](ValueSet-MHDprovideFolderActions.md)
* [MHD Patient Types ValueSet](ValueSet-MHDprovidePatientActions.md)

### Complex-type Profiles

* [entryUUID Identifier](StructureDefinition-IHE.MHD.EntryUUID.Identifier.md)
* [uniqueId Identifier for SubmissionSet](StructureDefinition-IHE.MHD.SubmissionSetUniqueIdIdentifier.md)
* [uniqueId Identifier](StructureDefinition-IHE.MHD.UniqueIdIdentifier.md)

### Resource Profiles

* [MHD DocumentReference Comprehensive](StructureDefinition-IHE.MHD.Comprehensive.DocumentReference.md)
* [MHD Folder Comprehensive](StructureDefinition-IHE.MHD.Comprehensive.Folder.md)
* [MHD Comprehensive Provide Document Bundle](StructureDefinition-IHE.MHD.Comprehensive.ProvideBundle.md)
* [MHD SubmissionSet Comprehensive](StructureDefinition-IHE.MHD.Comprehensive.SubmissionSet.md)
* [Audit Event for Find Document Lists Transaction by the Document Consumer](StructureDefinition-IHE.MHD.FindDocumentLists.Audit.Consumer.md)
* [Audit Event for Find Document Lists Transaction at Document Responder](StructureDefinition-IHE.MHD.FindDocumentLists.Audit.Responder.md)
* [MHD Find Document Lists Response Message](StructureDefinition-IHE.MHD.FindDocumentListsResponseMessage.md)
* [Audit Event for Find Document References Transaction at Document Consumer](StructureDefinition-IHE.MHD.FindDocumentReferences.Audit.Consumer.md)
* [Audit Event for Find Document References Transaction at Document Responder](StructureDefinition-IHE.MHD.FindDocumentReferences.Audit.Responder.md)
* [MHD Find Document References Comprehensive Response message](StructureDefinition-IHE.MHD.FindDocumentReferencesComprehensiveResponseMessage.md)
* [MHD Find Document References Response message](StructureDefinition-IHE.MHD.FindDocumentReferencesResponseMessage.md)
* [Audit Event for Generate Metadata ITI-106 Transaction at Recipient](StructureDefinition-IHE.MHD.GenerateMetadata.Audit.Recipient.md)
* [Audit Event for Generate Metadata ITI-106 Transaction at Source](StructureDefinition-IHE.MHD.GenerateMetadata.Audit.Source.md)
* [IHE MHD GenerateMetadata Parameters In](StructureDefinition-IHE.MHD.GenerateMetadata.Parameters.In.md)
* [MHD common List with designationType](StructureDefinition-IHE.MHD.List.md)
* [MHD DocumentReference Minimal](StructureDefinition-IHE.MHD.Minimal.DocumentReference.md)
* [MHD Folder Minimal](StructureDefinition-IHE.MHD.Minimal.Folder.md)
* [MHD Minimal Provide Document Bundle](StructureDefinition-IHE.MHD.Minimal.ProvideBundle.md)
* [MHD SubmissionSet Minimal](StructureDefinition-IHE.MHD.Minimal.SubmissionSet.md)
* [MHD DocumentReference Patch Parameters](StructureDefinition-IHE.MHD.Patch.Parameters.md)
* [Audit Event for Provide Bundle Transaction at Recipient](StructureDefinition-IHE.MHD.ProvideBundle.Audit.Recipient.md)
* [Audit Event for Provide Bundle Transaction at Source](StructureDefinition-IHE.MHD.ProvideBundle.Audit.Source.md)
* [MHD Provide Document Bundle Response](StructureDefinition-IHE.MHD.ProvideDocumentBundleResponse.md)
* [Audit Event for Retrieve Document Transaction at Document Consumer](StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.md)
* [Audit Event for Retrieve Document Transaction at the Document Responder](StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Responder.md)
* [Audit Event for Simplified Publish ITI-105 Transaction at Recipient](StructureDefinition-IHE.MHD.SimplifiedPublish.Audit.Recipient.md)
* [Audit Event for Simplified Publish ITI-105 Transaction at Source](StructureDefinition-IHE.MHD.SimplifiedPublish.Audit.Source.md)
* [MHD DocumentReference for Simplified Publish](StructureDefinition-IHE.MHD.SimplifiedPublish.DocumentReference.md)
* [MHD DocumentReference Comprehensive UnContained References Option](StructureDefinition-IHE.MHD.UnContained.Comprehensive.DocumentReference.md)
* [MHD UnContained Comprehensive Provide Document Bundle](StructureDefinition-IHE.MHD.UnContained.Comprehensive.ProvideBundle.md)
* [MHD SubmissionSet Comprehensive UnContained](StructureDefinition-IHE.MHD.UnContained.Comprehensive.SubmissionSet.md)

### Extensions

* [The homeCommunityId where the artifact resides](StructureDefinition-ihe-HomeCommunityId.md)
* [Author organization of the SubmissionSet](StructureDefinition-ihe-authorOrg.md)
* [Clinical code of the List](StructureDefinition-ihe-designationType.md)
* [Intended recipient of the SubmissionSet](StructureDefinition-ihe-intendedRecipient.md)
* [Publisher organization identity of the SubmissionSet](StructureDefinition-ihe-sourceId.md)

### CapabilityStatements

* [Document Consumer (client) - Target Communities Option](CapabilityStatement-IHE.MHD.DocumentConsumer.Target.md)
* [Document Consumer (client)](CapabilityStatement-IHE.MHD.DocumentConsumer.md)
* [Document Recipient implementing Comprehensive Metadata Option](CapabilityStatement-IHE.MHD.DocumentRecipient.Comprehensive.md)
* [Document Recipient implementing ITI-65 FHIR Documents Publish Option](CapabilityStatement-IHE.MHD.DocumentRecipient.Fdoc.md)
* [Document Recipient implementing Generate Metadata Option](CapabilityStatement-IHE.MHD.DocumentRecipient.Generate.md)
* [Document Recipient implementing Simplified Publish Option](CapabilityStatement-IHE.MHD.DocumentRecipient.Simplified.md)
* [Document Recipient implementing UnContained References Option](CapabilityStatement-IHE.MHD.DocumentRecipient.UnContained.md)
* [Document Recipient](CapabilityStatement-IHE.MHD.DocumentRecipient.md)
* [Document Responder (server) - Target Communities Option](CapabilityStatement-IHE.MHD.DocumentResponder.Target.md)
* [Document Responder (server)](CapabilityStatement-IHE.MHD.DocumentResponder.md)
* [Document Source (publisher) implementing Comprehensive Metadata Option](CapabilityStatement-IHE.MHD.DocumentSource.Comprehensive.md)
* [Document Source (publisher) implementing ITI-65 FHIR Documents Publish Option](CapabilityStatement-IHE.MHD.DocumentSource.Fdoc.md)
* [Document Source (publisher) implementing the Generate Metadata Option](CapabilityStatement-IHE.MHD.DocumentSource.Generate.md)
* [Document Source (publisher) implementing the Simplified Publish Option](CapabilityStatement-IHE.MHD.DocumentSource.Simplified.md)
* [Document Source (publisher) implementing UnContained References Option](CapabilityStatement-IHE.MHD.DocumentSource.UnContained.md)
* [Document Source (publisher)](CapabilityStatement-IHE.MHD.DocumentSource.md)

### ConceptMaps

* [AssociationType vs RelatesTo](ConceptMap-AssociationTypeVsRelatesTo.md)
* [FHIR status vs ebRIM Status Type Code](ConceptMap-FhirStatusVsStatusCode.md)

### ImplementationGuides

* [Mobile access to Health Documents (MHD)](index.md)

### OperationDefinitions

* [Generate a DocumentReference from a document](OperationDefinition-generate-metadata.md)

### SearchParameters

* [Creation](SearchParameter-DocumentReference-Creation.md)
* [TargetCommunityIdList](SearchParameter-IHE-TargetCommunityIdList.md)
* [DesignationType](SearchParameter-List-DesignationType.md)
* [SourceId](SearchParameter-List-SourceId.md)

### Examples

* [ex-auditFindDocumentLists-consumer (AuditEvent)](AuditEvent-ex-auditFindDocumentLists-consumer.md)
* [ex-auditFindDocumentLists-responder (AuditEvent)](AuditEvent-ex-auditFindDocumentLists-responder.md)
* [ex-auditFindDocumentReferences-consumer (AuditEvent)](AuditEvent-ex-auditFindDocumentReferences-consumer.md)
* [ex-auditFindDocumentReferences-post-responder (AuditEvent)](AuditEvent-ex-auditFindDocumentReferences-post-responder.md)
* [ex-auditFindDocumentReferences-responder (AuditEvent)](AuditEvent-ex-auditFindDocumentReferences-responder.md)
* [ex-auditGenerateMetadata-recipient (AuditEvent)](AuditEvent-ex-auditGenerateMetadata-recipient.md)
* [ex-auditGenerateMetadata-source (AuditEvent)](AuditEvent-ex-auditGenerateMetadata-source.md)
* [ex-auditProvideBundle-recipient (AuditEvent)](AuditEvent-ex-auditProvideBundle-recipient.md)
* [ex-auditProvideBundle-source (AuditEvent)](AuditEvent-ex-auditProvideBundle-source.md)
* [ex-auditRetrieveDocument-consumer (AuditEvent)](AuditEvent-ex-auditRetrieveDocument-consumer.md)
* [ex-auditRetrieveDocument-responder (AuditEvent)](AuditEvent-ex-auditRetrieveDocument-responder.md)
* [ex-auditSimplifiedPublish-recipient (AuditEvent)](AuditEvent-ex-auditSimplifiedPublish-recipient.md)
* [ex-auditSimplifiedPublish-source (AuditEvent)](AuditEvent-ex-auditSimplifiedPublish-source.md)
* [ex-b-binary (Binary)](Binary-ex-b-binary.md)
* [ex-binary (Binary)](Binary-ex-binary.md)
* [FindDocumentReferences (Bundle)](Bundle-FindDocumentReferences.md)
* [ex-ProvideDocumentBundle-addToFolder (Bundle)](Bundle-ex-ProvideDocumentBundle-addToFolder.md)
* [ex-comprehensiveProvideDocumentBundleComplete (Bundle)](Bundle-ex-comprehensiveProvideDocumentBundleComplete.md)
* [ex-comprehensiveProvideDocumentBundleDocument (Bundle)](Bundle-ex-comprehensiveProvideDocumentBundleDocument.md)
* [ex-comprehensiveProvideDocumentBundleMultiple (Bundle)](Bundle-ex-comprehensiveProvideDocumentBundleMultiple.md)
* [ex-comprehensiveProvideDocumentBundleReplace (Bundle)](Bundle-ex-comprehensiveProvideDocumentBundleReplace.md)
* [ex-comprehensiveProvideDocumentBundleSimple (Bundle)](Bundle-ex-comprehensiveProvideDocumentBundleSimple.md)
* [ex-dummyBundleDocAndBinary (Bundle)](Bundle-ex-dummyBundleDocAndBinary.md)
* [ex-fhir-document-bundle (Bundle)](Bundle-ex-fhir-document-bundle.md)
* [ex-findDocumentListsResponse (Bundle)](Bundle-ex-findDocumentListsResponse.md)
* [ex-findDocumentReferencesResponse (Bundle)](Bundle-ex-findDocumentReferencesResponse.md)
* [ex-minimalProvideDocumentBundleSimple (Bundle)](Bundle-ex-minimalProvideDocumentBundleSimple.md)
* [ex-minimalProvideDocumentBundleSimpleContained (Bundle)](Bundle-ex-minimalProvideDocumentBundleSimpleContained.md)
* [ex-response-comprehensiveProvideDocumentBundleComplete (Bundle)](Bundle-ex-response-comprehensiveProvideDocumentBundleComplete.md)
* [ex-response-comprehensiveProvideDocumentBundleMultiple (Bundle)](Bundle-ex-response-comprehensiveProvideDocumentBundleMultiple.md)
* [ex-response-comprehensiveProvideDocumentBundleSimple (Bundle)](Bundle-ex-response-comprehensiveProvideDocumentBundleSimple.md)
* [ex-response-minimalProvideDocumentBundleSimple (Bundle)](Bundle-ex-response-minimalProvideDocumentBundleSimple.md)
* [ex-response-minimalProvideDocumentBundleSimpleContained (Bundle)](Bundle-ex-response-minimalProvideDocumentBundleSimpleContained.md)
* [ex-response-unContainedComprehensiveProvideDocumentBundleCompt (Bundle)](Bundle-ex-response-unContainedComprehensiveProvideDocumentBundleCompt.md)
* [ex-unContainedComprehensiveProvideDocumentBundleComplete (Bundle)](Bundle-ex-unContainedComprehensiveProvideDocumentBundleComplete.md)
* [ex-device (Device)](Device-ex-device.md)
* [ex-DocumentReferenceComprehensive (DocumentReference)](DocumentReference-ex-DocumentReferenceComprehensive.md)
* [ex-DocumentReferenceComprehensiveDelayedAssembly (DocumentReference)](DocumentReference-ex-DocumentReferenceComprehensiveDelayedAssembly.md)
* [ex-DocumentReferenceComprehensiveOnDemand (DocumentReference)](DocumentReference-ex-DocumentReferenceComprehensiveOnDemand.md)
* [ex-DocumentReferenceComprehensiveWithBinary (DocumentReference)](DocumentReference-ex-DocumentReferenceComprehensiveWithBinary.md)
* [ex-DocumentReferenceMinimal (DocumentReference)](DocumentReference-ex-DocumentReferenceMinimal.md)
* [ex-DocumentReferenceMinimalEncounter (DocumentReference)](DocumentReference-ex-DocumentReferenceMinimalEncounter.md)
* [ex-DocumentReferenceSimplifiedPublish (DocumentReference)](DocumentReference-ex-DocumentReferenceSimplifiedPublish.md)
* [ex-DocumentReferenceUnContained (DocumentReference)](DocumentReference-ex-DocumentReferenceUnContained.md)
* [ex-DocumentReferenceUnContainedFully (DocumentReference)](DocumentReference-ex-DocumentReferenceUnContainedFully.md)
* [ex-documentreference (DocumentReference)](DocumentReference-ex-documentreference.md)
* [ex-documentreference2 (DocumentReference)](DocumentReference-ex-documentreference2.md)
* [ex-encounter (Encounter)](Encounter-ex-encounter.md)
* [Example SubmissionSet for comprehensive metadata with an intendedRecipient (List)](List-ex-compEmailPackage.md)
* [Example Folder with comprehensive metadata (List)](List-ex-compFolder.md)
* [Example SubmissionSet for comprehensive metadata (List)](List-ex-compSubmissionSetFull.md)
* [Example SubmissionSet for comprehensive metadata (List)](List-ex-compSubmissionSetFullUnContained.md)
* [Example SubmissionSet for comprehensive metadata (List)](List-ex-compSubmissionSetList.md)
* [ex-list (List)](List-ex-list.md)
* [ex-minimalFolder (List)](List-ex-minimalFolder.md)
* [ex-minimalSubmissionSet (List)](List-ex-minimalSubmissionSet.md)
* [nowhere (Organization)](Organization-ex-organization.md)
* [ex-input-binary (Parameters)](Parameters-ex-input-binary.md)
* [ex-input-doc-bundle (Parameters)](Parameters-ex-input-doc-bundle.md)
* [ex-patchParameters (Parameters)](Parameters-ex-patchParameters.md)
* [ex-patient (Patient)](Patient-ex-patient.md)
* [ex-practitioner (Practitioner)](Practitioner-ex-practitioner.md)
