# Audit Event for Retrieve Document Transaction at Document Consumer - Mobile access to Health Documents (MHD) v4.2.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Audit Event for Retrieve Document Transaction at Document Consumer**

## Resource Profile: Audit Event for Retrieve Document Transaction at Document Consumer 

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Consumer | *Version*:4.2.4 |
| Active as of 2026-06-15 | *Computable Name*:AuditRetrieveDocumentConsumer |

 
Defines constraints on the Document Consumer AuditEvent Resource to record when a Retrieve Document Transaction happens, as recorded by the Document Consumer. 
* Build off of the IHE BasicAudit PatientRead event
* add the ITI-68 as a subtype
* client is Document Consumer
* server is Document Responder
* entity slices for data, and patient are required
* entity slice for transaction is available
 

**Usages:**

* Examples for this Profile: [AuditEvent/ex-auditRetrieveDocument-consumer](AuditEvent-ex-auditRetrieveDocument-consumer.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ihe.iti.mhd|current/StructureDefinition/StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.csv), [Excel](StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.xlsx), [Schematron](StructureDefinition-IHE.MHD.RetrieveDocument.Audit.Consumer.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "IHE.MHD.RetrieveDocument.Audit.Consumer",
  "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Consumer",
  "version" : "4.2.4",
  "name" : "AuditRetrieveDocumentConsumer",
  "title" : "Audit Event for Retrieve Document Transaction at Document Consumer",
  "status" : "active",
  "date" : "2026-06-15T14:55:16-05:00",
  "publisher" : "IHE IT Infrastructure Technical Committee",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ihe.net/ihe_domains/it_infrastructure/"
    }]
  },
  {
    "telecom" : [{
      "system" : "email",
      "value" : "iti@ihe.net"
    }]
  },
  {
    "name" : "IHE IT Infrastructure Technical Committee",
    "telecom" : [{
      "system" : "email",
      "value" : "iti@ihe.net"
    }]
  }],
  "description" : "Defines constraints on the Document Consumer AuditEvent Resource to record when a Retrieve Document Transaction happens, as recorded by the Document Consumer.\n- Build off of the IHE BasicAudit PatientRead event\n- add the ITI-68 as a subtype\n- client is Document Consumer\n- server is Document Responder\n- entity slices for data, and patient are required\n- entity slice for transaction is available",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "dicom",
    "uri" : "http://nema.org/dicom",
    "name" : "DICOM Tag Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "w3c.prov",
    "uri" : "http://www.w3.org/ns/prov",
    "name" : "W3C PROV"
  },
  {
    "identity" : "fhirprovenance",
    "uri" : "http://hl7.org/fhir/provenance",
    "name" : "FHIR Provenance Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "AuditEvent",
  "baseDefinition" : "https://profiles.ihe.net/ITI/BALP/StructureDefinition/IHE.BasicAudit.PatientRead",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "AuditEvent",
      "path" : "AuditEvent"
    },
    {
      "id" : "AuditEvent.modifierExtension",
      "path" : "AuditEvent.modifierExtension",
      "max" : "0"
    },
    {
      "id" : "AuditEvent.subtype",
      "path" : "AuditEvent.subtype",
      "min" : 2
    },
    {
      "id" : "AuditEvent.subtype:iti68",
      "path" : "AuditEvent.subtype",
      "sliceName" : "iti68",
      "min" : 1,
      "max" : "1",
      "patternCoding" : {
        "system" : "urn:ihe:event-type-code",
        "code" : "ITI-68",
        "display" : "Retrieve Document"
      }
    },
    {
      "id" : "AuditEvent.agent:client",
      "path" : "AuditEvent.agent",
      "sliceName" : "client",
      "short" : "Document Consumer",
      "constraint" : [{
        "key" : "val-audit-source",
        "severity" : "error",
        "human" : "The Audit Source is this agent too.",
        "expression" : "$this.who = %resource.source.observer",
        "source" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.RetrieveDocument.Audit.Consumer"
      }]
    },
    {
      "id" : "AuditEvent.agent:server",
      "path" : "AuditEvent.agent",
      "sliceName" : "server",
      "short" : "Document Responder"
    },
    {
      "id" : "AuditEvent.entity:data",
      "path" : "AuditEvent.entity",
      "sliceName" : "data",
      "short" : "the data"
    },
    {
      "id" : "AuditEvent.entity:data.role",
      "path" : "AuditEvent.entity.role",
      "patternCoding" : {
        "system" : "http://terminology.hl7.org/CodeSystem/object-role",
        "code" : "3",
        "display" : "Report"
      }
    },
    {
      "id" : "AuditEvent.entity:patient",
      "path" : "AuditEvent.entity",
      "sliceName" : "patient",
      "short" : "Patient"
    }]
  }
}

```
