# PMIR example Patient for merge - Patient Master Identity Registry (PMIR) v1.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PMIR example Patient for merge**

## Example Patient: PMIR example Patient for merge

Example PMIR Patient for mergin



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "ex-patient-merged",
  "active" : true
}

```
