# Device Example for PMIR - Patient Master Identity Registry (PMIR) v1.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Device Example for PMIR**

## Example Device: Device Example for PMIR



## Resource Content

```json
{
  "resourceType" : "Device",
  "id" : "ex-device"
}

```
