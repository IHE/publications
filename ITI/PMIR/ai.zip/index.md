# 1:49 Patient Master Identity Registry (PMIR) Profile - Patient Master Identity Registry (PMIR) v1.6.0

* [**Table of Contents**](toc.md)
* **1:49 Patient Master Identity Registry (PMIR) Profile**

## 1:49 Patient Master Identity Registry (PMIR) Profile

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/ITI/PMIR/ImplementationGuide/ihe.iti.pmir | *Version*:1.6.0 |
| Active as of 2025-11-04 | *Computable Name*:IHE_ITI_PMIR |

The Patient Master Identity Registry (PMIR) Profile supports the creating, updating and deprecating of patient master identity information about a subject of care, as well as subscribing to changes to the patient master identity, using the HL7 FHIR standard resources and RESTful transactions. In PMIR, “patient identity” information includes all information found in the FHIR Patient Resource such as identifier, name, phone, gender, birth date, address, marital status, photo, others to contact, preference for language, general practitioner, and links to other instances of identities. The “patient master identity” is the dominant patient identity managed centrally among many participating organizations (a.k.a., “Golden Patient Identity”).

Beyond the basic create, retrieve, update, and delete transaction set, this profile addresses important patient safety issues related to cases where there are two or more patient master identities that have been established for the same person, thus it is not clear which identity is the “true” one. There is also a risk that health data (possibly conflicting) may be associated with each identity – and these disparate data, together, may need to be reconciled before a fully and accurate “health picture” can be developed for this person. These situations represent patient safety risks. This profile addresses how these multiple patient master identities can be merged into a single patient master identity, and how this merge flows down to data custodians so that they take appropriate actions. It is outside the scope of this profile to define how references to the deprecated patient master identity from other data should be handled.

This profile is intended for FHIR-only configurations without other underlying standards for patient master identity management. The FHIR message pattern was chosen because it fits well into the subscription notification model.

| |
| :--- |
| [Significant Changes, Open, and Closed Issues](issues.md) |

### Organization of This Guide

This guide is organized into four main sections:

1. Volume 1: Profiles
1. [PMIR Introduction](volume-1.md)
1. [PMIR Actors, Transactions, and Content Modules](volume-1.md#1491-pmir-actors-transactions-and-content-modules)
1. [PMIR Actor Options](volume-1.md#1492-pmir-actor-options)
1. [PMIR Required Actor Groupings](volume-1.md#1493-pmir-required-actor-groupings)
1. [PMIR Overview](volume-1.md#1494-pmir-overview)
1. [PMIR Security Considerations](volume-1.md#1495-pmir-security-considerations)
1. [PMIR Cross Profile Considerations](volume-1.md#1496-pmir-cross-profile-considerations)

1. Volume 2: Transaction Detail
1. [Mobile Patient Identity Feed [ITI-93]](ITI-93.md)
1. [Subscribe to Patient Updates [ITI-94]](ITI-94.md)

1. [Test Plan](testplan.md)
1. [Changes to other Profiles](other.md)

Click on any of the links above, navigate the contents using the [table of contents](toc.md), or if you are looking for a specific artifact, check out the [artifacts](artifacts.md).

### Conformance Expectations

IHE uses the normative words: Shall, Should, and May according to [standards conventions](https://profiles.ihe.net/GeneralIntro/ch-E.html).

#### Must Support

The use of `mustSupport` in StructureDefinition profiles equivalent to the IHE use of **R2** as defined in [Appendix Z](https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#z.10-profiling-conventions-for-constraints-on-fhir).

mustSupport of true - only has a meaning on items that are minimal cardinality of zero (0), and applies only to the source actor populating the data. The source actor shall populate the elements marked with MustSupport if the concept is supported by the actor, a value exists, and security and consent rules permit. The consuming actors should handle these elements being populated or being absent/empty. Note that sometimes mustSupport will appear on elements with a minimal cardinality greater than zero (0), this is due to inheritance from a less constrained profile.

### Download

You can also download:

* [this entire guide](full-ig.zip),
* the definition resources in [json](definitions.json.zip), [xml](definitions.xml.zip), [ttl](definitions.ttl.zip), or [csv](csvs.zip) format, or
* the example resources in [json](examples.json.zip), [xml](examples.xml.zip) or [ttl](examples.ttl.zip) format.

The source code for this Implementation Guide can be found on [IHE GitHub](https://github.com/IHE/ITI.PMIR).

#### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ihe.iti.pmir.r4)](package.r4.tgz) and [R4B (ihe.iti.pmir.r4b)](package.r4b.tgz) are available.

#### Dependency Table






#### Globals Table

*There are no Global profiles defined*

#### IP Statements

This publication includes IP covered under the following statements.

* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [DICOM Controlled Terminology Definitions](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html): [AuditEvent/ex-auditPmirFeed-consumer](AuditEvent-ex-auditPmirFeed-consumer.md), [AuditEvent/ex-auditPmirFeed-supplier](AuditEvent-ex-auditPmirFeed-supplier.md)...Show 13 more,[AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md),[AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md),[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md),[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md),[AuditPmirFeed](StructureDefinition-IHE.PMIR.Feed.Audit.md),[AuditPmirSubscriptionCreate](StructureDefinition-IHE.PMIR.Audit.Subscription.Create.md),[AuditPmirSubscriptionDelete](StructureDefinition-IHE.PMIR.Audit.Subscription.Delete.md),[AuditPmirSubscriptionRead](StructureDefinition-IHE.PMIR.Audit.Subscription.Read.md)and[AuditPmirSubscriptionUpdate](StructureDefinition-IHE.PMIR.Audit.Subscription.Update.md)
* [Audit Event ID](http://terminology.hl7.org/6.5.0/CodeSystem-audit-event-type.html): [AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md), [AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md)...Show 10 more,[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md),[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md),[AuditPmirSubscriptionCreate](StructureDefinition-IHE.PMIR.Audit.Subscription.Create.md),[AuditPmirSubscriptionDelete](StructureDefinition-IHE.PMIR.Audit.Subscription.Delete.md),[AuditPmirSubscriptionRead](StructureDefinition-IHE.PMIR.Audit.Subscription.Read.md)and[AuditPmirSubscriptionUpdate](StructureDefinition-IHE.PMIR.Audit.Subscription.Update.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Audit event entity type](http://terminology.hl7.org/6.5.0/CodeSystem-audit-entity-type.html): [AuditEvent/ex-auditPmirFeed-consumer](AuditEvent-ex-auditPmirFeed-consumer.md), [AuditEvent/ex-auditPmirFeed-supplier](AuditEvent-ex-auditPmirFeed-supplier.md)...Show 13 more,[AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md),[AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md),[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md),[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md),[AuditPmirFeed](StructureDefinition-IHE.PMIR.Feed.Audit.md),[AuditPmirSubscriptionCreate](StructureDefinition-IHE.PMIR.Audit.Subscription.Create.md),[AuditPmirSubscriptionDelete](StructureDefinition-IHE.PMIR.Audit.Subscription.Delete.md),[AuditPmirSubscriptionRead](StructureDefinition-IHE.PMIR.Audit.Subscription.Read.md)and[AuditPmirSubscriptionUpdate](StructureDefinition-IHE.PMIR.Audit.Subscription.Update.md)
* [AuditEventEntityRole](http://terminology.hl7.org/6.5.0/CodeSystem-object-role.html): [AuditEvent/ex-auditPmirFeed-consumer](AuditEvent-ex-auditPmirFeed-consumer.md), [AuditEvent/ex-auditPmirFeed-supplier](AuditEvent-ex-auditPmirFeed-supplier.md)...Show 13 more,[AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md),[AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md),[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md),[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md),[AuditPmirFeed](StructureDefinition-IHE.PMIR.Feed.Audit.md),[AuditPmirSubscriptionCreate](StructureDefinition-IHE.PMIR.Audit.Subscription.Create.md),[AuditPmirSubscriptionDelete](StructureDefinition-IHE.PMIR.Audit.Subscription.Delete.md),[AuditPmirSubscriptionRead](StructureDefinition-IHE.PMIR.Audit.Subscription.Read.md)and[AuditPmirSubscriptionUpdate](StructureDefinition-IHE.PMIR.Audit.Subscription.Update.md)
* [Provenance participant type](http://terminology.hl7.org/6.5.0/CodeSystem-provenance-participant-type.html): [AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md), [AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md) and [AuditPmirSubscriptionDelete](StructureDefinition-IHE.PMIR.Audit.Subscription.Delete.md)
* [Audit Event Source Type](http://terminology.hl7.org/6.5.0/CodeSystem-security-source-type.html): [AuditEvent/ex-auditPmirFeed-consumer](AuditEvent-ex-auditPmirFeed-consumer.md), [AuditEvent/ex-auditPmirFeed-supplier](AuditEvent-ex-auditPmirFeed-supplier.md)...Show 8 more,[AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md),[AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md),[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md)and[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md)
* [contactRole2](http://terminology.hl7.org/6.5.0/CodeSystem-v2-0131.html): [PMIRRelatedPerson](StructureDefinition-IHE.PMIR.RelatedPerson.md)
* [ParticipationType](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ParticipationType.html): [AuditEvent/ex-auditPmirSubscription-registry-create](AuditEvent-ex-auditPmirSubscription-registry-create.md), [AuditEvent/ex-auditPmirSubscription-registry-delete](AuditEvent-ex-auditPmirSubscription-registry-delete.md)...Show 7 more,[AuditEvent/ex-auditPmirSubscription-registry-read](AuditEvent-ex-auditPmirSubscription-registry-read.md),[AuditEvent/ex-auditPmirSubscription-registry-update](AuditEvent-ex-auditPmirSubscription-registry-update.md),[AuditEvent/ex-auditPmirSubscription-subscriber-create](AuditEvent-ex-auditPmirSubscription-subscriber-create.md),[AuditEvent/ex-auditPmirSubscription-subscriber-delete](AuditEvent-ex-auditPmirSubscription-subscriber-delete.md),[AuditEvent/ex-auditPmirSubscription-subscriber-read](AuditEvent-ex-auditPmirSubscription-subscriber-read.md),[AuditEvent/ex-auditPmirSubscription-subscriber-update](AuditEvent-ex-auditPmirSubscription-subscriber-update.md)and[AuditPmirSubscriptionRead](StructureDefinition-IHE.PMIR.Audit.Subscription.Read.md)
* [RoleCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-RoleCode.html): [PMIRRelatedPerson](StructureDefinition-IHE.PMIR.RelatedPerson.md), [RelatedPerson/bf7c8e34-1be8-4b67-aad7-d62d8da48065](RelatedPerson-bf7c8e34-1be8-4b67-aad7-d62d8da48065.md) and [RelatedPerson/ex-related-mom](RelatedPerson-ex-related-mom.md)


