# Example document that says: Hello World - Basic Audit Log Patterns (BALP) v1.1.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example document that says: Hello World**

## Example Binary: Example document that says: Hello World

```

Hello World
```



## Resource Binary Content

text/plain:

```
[B@5e5616f2
```
