No required groupings. 

The [Security Considerations](security_considerations.html) page describes some optional groupings that may be of interest for security considerations.  

[Cross-Profile Considerations](grouping.html) describes some optional groupings in other related profiles.