# Resource TestPlan-VHLSharer



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "TestPlan-VHLSharer",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.url",
    "valueUri" : "https://profiles.ihe.net/ITI/VHL/TestPlan/TestPlan-VHLSharer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.version",
    "valueString" : "1.0.0-comment"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.name",
    "valueString" : "TestPlan_VHLSharer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.title",
    "valueString" : "Test Plan – VHL Sharer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.status",
    "valueCode" : "active"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.date",
    "valueDateTime" : "2026-06-14T15:36:12-05:00"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.publisher",
    "valueString" : "IHE IT Infrastructure Technical Committee"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.ihe.net/ihe_domains/it_infrastructure/"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "iti@ihe.net"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "name" : "IHE IT Infrastructure Technical Committee",
      "telecom" : [{
        "system" : "email",
        "value" : "iti@ihe.net"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.description",
    "valueMarkdown" : "Unit test plan for the **VHL Sharer** actor of the IHE ITI Verifiable Health Links (VHL) profile.\n\nScope: validates all behaviour expected of a VHL Sharer across its four transactions:\nsubmitting its own PKI material (ITI-YY1 initiator), retrieving the trust list to obtain peer\nkeys (ITI-YY2 initiator), generating VHLs on demand (ITI-YY3 responder), and serving document\nmanifests to authorised VHL Receivers (ITI-YY5 responder). Each test suite corresponds to one\ntransaction and exercises three atomic feature files."
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.jurisdiction",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
        "code" : "001"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.scope",
    "valueReference" : {
      "reference" : "ActorDefinition/VHLSharer"
    }
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 1
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 Message Semantics** – Shared message format file (same as Trust Anchor suite 1).\nVerifies the DID Document structure the VHL Sharer must construct."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 VHL Sharer Initiator Expected Actions** – Verifies key pair generation, submission\npathways (direct HTTP POST, indirect publication, offline), provenance metadata, response\nhandling (201/400/401/403/422), and secure private key retention.\nSource: sections 2:3.YY1.4.1.2 (Message Semantics) and 2:3.YY1.4.1.3 (Initiator Expected Actions)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-initiator.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 Security Considerations** – Shared security file (same as Trust Anchor suite 1)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 2
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 Message Semantics** – Shared message format file.\nVerifies the request/response format for the trust list retrieval."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 VHL Sharer Initiator Expected Actions** – Verifies that the VHL Sharer correctly\nconstructs retrieval requests, sends them over TLS, validates and caches returned DID Documents,\nmaps verification methods, tracks expiry, handles revocation notifications, and processes\nerror responses (401/403/404).\nSource: sections 2:3.YY2.4.1 (Request Message) and 2:3.YY2.4.2.3 (Initiator Expected Actions)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-initiator.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 Security Considerations** – Shared security file."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 3
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY3 Message Semantics** – Verifies the $generate-vhl request parameter definitions\n(sourceIdentifier, exp, flag, label, passcode) and the response format\n(HTTP 200, FHIR Parameters, Binary qrcode, HC1: prefix)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY3-generate-vhl-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY3 VHL Sharer Responder Expected Actions** – Verifies the complete VHL generation\npipeline: passcode hashing (bcrypt/Argon2/PBKDF2), folder ID (256-bit entropy) and 32-byte\nencryption key generation, VHL payload construction (url/key/flag/v), mandatory manifest URL\nparameters, HCERT/CWT encoding (COSE signing → ZLIB → Base45 → HC1: prefix), QR code\ngeneration (ISO/IEC 18004:2015 Alphanumeric mode Q), and error OperationOutcome responses.\nSource: sections 2:3.YY3.4.1.3 (Responder Expected Actions) and 2:3.YY3.4.2 (Response Message)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY3-generate-vhl-responder.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY3 Security Considerations** – Verifies HTTPS enforcement, passcode security\n(no plaintext storage, no embedding in QR code), key entropy requirements, and PHI exclusion."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY3-generate-vhl-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 4
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY5 Message Semantics** – Verifies request format (HTTP POST /List/_search,\nContent-Type, Accept, FHIR search parameters, SHL parameters, HTTP Message Signature\nheaders) and response format (searchset Bundle structure, search.mode, error codes)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY5-retrieve-manifest-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY5 VHL Sharer Responder Expected Actions** – Verifies HTTP Message Signature\nverification (keyid lookup, RFC 9421 signature base, Content-Digest), OAuth FAST Option\ntoken validation, VHL authorisation (folder ID, expiry, revocation, passcode hash comparison),\nFHIR search execution (_include support), Bundle construction, error codes (400/401/403/404/422/429/500),\nrate limiting, and audit logging.\nSource: sections 2:3.YY5.4.1.5 (Responder Expected Actions), 2:3.YY5.4.2 (Response Message),\nand 2:3.YY5.5 (Security Considerations)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY5-retrieve-manifest-responder.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY5 Security Considerations** – Verifies TLS requirements, replay prevention (signature\ntimestamp freshness, OAuth jti uniqueness), passcode timing-attack protection, trust list\nenforcement, and audit logging (no plaintext passcode in logs)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY5-retrieve-manifest-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/fhir-types",
      "code" : "TestPlan"
    }]
  }
}

```
