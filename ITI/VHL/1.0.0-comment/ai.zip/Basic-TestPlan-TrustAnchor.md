# Resource TestPlan-TrustAnchor



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "TestPlan-TrustAnchor",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.url",
    "valueUri" : "https://profiles.ihe.net/ITI/VHL/TestPlan/TestPlan-TrustAnchor"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.version",
    "valueString" : "1.0.0-comment"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.name",
    "valueString" : "TestPlan_TrustAnchor"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.title",
    "valueString" : "Test Plan – Trust Anchor"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.status",
    "valueCode" : "active"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.date",
    "valueDateTime" : "2026-06-14T15:36:12-05:00"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.publisher",
    "valueString" : "IHE IT Infrastructure Technical Committee"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.ihe.net/ihe_domains/it_infrastructure/"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "iti@ihe.net"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.contact",
    "valueContactDetail" : {
      "name" : "IHE IT Infrastructure Technical Committee",
      "telecom" : [{
        "system" : "email",
        "value" : "iti@ihe.net"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.description",
    "valueMarkdown" : "Unit test plan for the **Trust Anchor** actor of the IHE ITI Verifiable Health Links (VHL) profile.\n\nScope: validates all behaviour expected of a Trust Anchor as described in ITI-YY1 (responder)\nand ITI-YY2 (responder). Each test suite (testCase) corresponds to one transaction and exercises\nthree atomic feature files: message semantics (shared), responder expected actions, and security\nconsiderations."
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.jurisdiction",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
        "code" : "001"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.scope",
    "valueReference" : {
      "reference" : "ActorDefinition/TrustAnchor"
    }
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 1
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 Message Semantics** – Verifies the DID Document message format that the Trust Anchor\nmust validate: mandatory @context / id / verificationMethod fields, verification method structure,\npublic key format (JWK/RFC 7517), private key exclusion, accepted cryptographic suites, key\nstrength (P-256+), and HTTP POST / Content-Type requirements.\nSource: section 2:3.YY1.4.1.2 (Message Semantics)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 Trust Anchor Expected Actions** – Verifies structural and cryptographic validation,\nidentity authentication and authorisation, cataloguing, rejection criteria, revocation and\nupdate support, and correct HTTP response codes (201 / 400 / 401 / 403 / 422).\nSource: sections 2:3.YY1.4.1.3 (Responder) and 2:3.YY1.4.2 (Response Message)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-responder.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY1 Security Considerations** – Verifies §2:3.YY1.5 requirements: DID Document integrity\n(signed submissions), key material security (private key exclusion, minimum strength), identity\nverification (TLS, authentication mechanisms), DID Document validation (approved algorithms,\nusage arrays), and revocation distribution controls."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY1-submit-pki-material-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.sequence",
      "valueInteger" : 2
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 Message Semantics** – Verifies the request message options (single-DID GET,\nbulk GET, mCSD query, URL encoding, optional query parameters) and response message\nformats (single DID Document, collection, mCSD searchset Bundle, returned DID Document\ncontent requirements).\nSource: section 2:3.YY2.4 (Request and Response Messages)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-message.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 Trust Anchor Expected Actions** – Verifies active-document-only filtering (no\nrevoked/expired DID Documents), authentication and authorisation enforcement (401/403),\n404 handling for unknown DIDs, and optional response signing.\nSource: sections 2:3.YY2.4.2 (Response Message) and 2:3.YY2.5 (Security Considerations)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-responder.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.narrative",
        "valueMarkdown" : "**ITI-YY2 Security Considerations** – Verifies TLS enforcement, response integrity\nverification, access control restrictions, and revocation propagation requirements."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.language",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:13",
              "code" : "text/x-gherkin"
            }],
            "text" : "Gherkin"
          }
        },
        {
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script.sourceString",
          "valueString" : "ITI-YY2-retrieve-trust-list-security.feature"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun.script"
      }],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase.testRun"
    }],
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-TestPlan.testCase"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/fhir-types",
      "code" : "TestPlan"
    }]
  }
}

```
