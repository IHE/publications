# Verifiable Health Links (VHL) Home - Verifiable Health Links v1.0.0-comment

* [**Table of Contents**](toc.md)
* **Verifiable Health Links (VHL) Home**

## Verifiable Health Links (VHL) Home

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/ITI/VHL/ImplementationGuide/ihe.iti.vhl | *Version*:1.0.0-comment |
| Active as of 2026-06-14 | *Computable Name*:IHE_ITI_VHL |

The Verifiable Health Links (VHL) profile defines protocols and patterns that allow the sharing of health documents in a auditable and verfiable manner within and across jurisdictional boundaries. The VHL profile describes mechanisms, the VHLs, that an individual, the VHL Holder, uses to provide authorize access to their health records from an issuer, the [VHL Sharer](ActorDefinition-VHLSharer.md), to a third party, the [VHL Receiver](ActorDefinition-VHLReceiver.md). The means by which the VHL is held by the VHL Holder or shared by the VHL Holder to the [VHL Receiver](ActorDefinition-VHLReceiver.md) are beyond the scope of this profile.

| |
| :--- |
| [Significant Changes, Open and Closed Issues](issues.md) |

### Organization of This Guide

This guide is organized into the following sections:

1. Volume 1:
1. [Introduction](volume-1.md)
1. [Actors, Transactions, and Content](volume-1.md#actors-and-transactions)
1. [Actor Options](volume-1.md#actor-options)
1. [Actor Required Groupings](volume-1.md#required-groupings)
1. [Overview](volume-1.md#overview)
1. [Security Considerations](volume-1.md#security-considerations)
1. [Cross Profile Considerations](volume-1.md#other-grouping)

1. Volume 2: Transaction Detail
1. [Submit PKI Material with DID [ITI-YY1]](ITI-YY1.md)
1. [Retrieve Trust List with DID [ITI-YY2]](ITI-YY2.md)
1. [Generate VHL [ITI-YY3]](ITI-YY3.md)
1. [Provide VHL [ITI-YY4]](ITI-YY4.md)
1. [Retrieve Manifest [ITI-YY5]](ITI-YY5.md)

1. Other
1. [Test Plan](testplan.md)
1. [Changes to Other IHE Specifications](other.md)
1. [Download and Analysis](download.md)
1. [Appendix A: Comparison of VHL and SHL](vhl_vs_shl.md)

See also the [Table of Contents](toc.md) and the index of [Artifacts](artifacts.md) defined as part of this implementation guide.

### Conformance Expectations

IHE uses the normative words: "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" according to [standards conventions](https://profiles.ihe.net/GeneralIntro/ch-E.html).

#### Must Support

The use of `mustSupport` in StructureDefinition profiles equivalent to the IHE use of **R2** as defined in [Appendix Z](https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#z.10-profiling-conventions-for-constraints-on-fhir).

mustSupport of true - only has a meaning on items that are minimal cardinality of zero (0), and applies only to the source actor populating the data. The source actor shall populate the elements marked with MustSupport, if the concept is supported by the actor, a value exists, and security and consent rules permit. The consuming actors should handle these elements being populated or being absent/empty. Note that sometimes mustSupport will appear on elements with a minimal cardinality greater than zero (0), this is due to inheritance from a less constrained profile.

