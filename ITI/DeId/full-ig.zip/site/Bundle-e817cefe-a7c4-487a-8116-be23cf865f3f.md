# ex-Bundle-DeathCert-pandemicIPS-VRDR-stage-1 - De-Identification Handbook v2.0.0-comment

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ex-Bundle-DeathCert-pandemicIPS-VRDR-stage-1**

## Example Bundle: ex-Bundle-DeathCert-pandemicIPS-VRDR-stage-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "e817cefe-a7c4-487a-8116-be23cf865f3f",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-death-certificate-document"]
  },
  "identifier" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/CertificateNumber",
      "valueString" : "001621"
    },
    {
      "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/AuxiliaryStateIdentifier1",
      "valueString" : "000000000021"
    },
    {
      "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/AuxiliaryStateIdentifier2",
      "valueString" : "200000000021"
    }],
    "system" : "http://nchs.cdc.gov/vrdr_id",
    "value" : "2024001621"
  },
  "type" : "document",
  "timestamp" : "2024-07-01T14:48:35.401641-04:00",
  "entry" : [{
    "id" : "ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1",
    "fullUrl" : "http://example.org/Composition/ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-death-certificate|3.0.0"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Composition-DeathCert-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Composition-DeathCert-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-death-certificate.html\">Death Certificate</a> version: 3.0.0</p></div><p><b>Filing Format</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-filing-format-cs electronic}\">Electronic</span></p><p><b>Replacement Status of a Death Record (deprecated)</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-replace-status-cs original}\">original record</span></p><p><b>State Specific Field</b>: State Specific Content</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 64297-5}\">Death certificate</span></p><p><b>date</b>: 2024-07-01 00:00:00+0000</p><p><b>author</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></p><p><b>title</b>: Death Certificate</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Legal</td><td>2024-07-21 16:39:40-0500</td><td><a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></td></tr></table><h3>Events</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 307930005}\">Death certificate (record artifact)</span></td><td><a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Procedure/ex-DeathCertification-pandemicIPS-VRDR-stage-1\">Procedure Death certification</a></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/FilingFormat",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-filing-format-cs",
            "code" : "electronic"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/ReplaceStatus",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-replace-status-cs",
            "code" : "original"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/StateSpecificField",
        "valueString" : "State Specific Content"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "64297-5",
          "display" : "Death certificate"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "date" : "2024-07-01T00:00:00Z",
      "author" : [{
        "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
      }],
      "title" : "Death Certificate",
      "attester" : [{
        "mode" : "legal",
        "time" : "2024-07-21T16:39:40-05:00",
        "party" : {
          "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
        }
      }],
      "event" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "307930005",
            "display" : "Death certificate (record artifact)"
          }]
        }],
        "detail" : [{
          "reference" : "http://example.org/Procedure/ex-DeathCertification-pandemicIPS-VRDR-stage-1"
        }]
      }],
      "section" : [{
        "title" : "Decedent Demographics",
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-document-section-cs",
            "code" : "DecedentDemographics"
          }]
        },
        "entry" : [{
          "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/RelatedPerson/ex-DecedentFather-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/RelatedPerson/ex-DecedentMother-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/RelatedPerson/ex-DecedentSpouse-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-DecedentAge-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1"
        }]
      },
      {
        "title" : "Death Investigation",
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-document-section-cs",
            "code" : "DeathInvestigation"
          }]
        },
        "entry" : [{
          "reference" : "http://example.org/Observation/ex-DecedentPregStat-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-DeathDate-pandemicIPS-VRDR-stage-1"
        }]
      },
      {
        "title" : "Death Certification",
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-document-section-cs",
            "code" : "DeathCertification"
          }]
        },
        "entry" : [{
          "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Procedure/ex-DeathCertification-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-MannerOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1"
        }]
      },
      {
        "title" : "Decedent Disposition",
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-document-section-cs",
            "code" : "DecedentDisposition"
          }]
        },
        "entry" : [{
          "reference" : "http://example.org/Location/ex-DispLocation-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Organization/ex-FuneralHome-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Practitioner/ex-Mortician-pandemicIPS-VRDR-stage-1"
        }]
      },
      {
        "title" : "Coded Content",
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-document-section-cs",
            "code" : "CodedContent"
          }]
        },
        "entry" : [{
          "reference" : "http://example.org/Observation/ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Observation/ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1"
        },
        {
          "reference" : "http://example.org/Parameters/ex-CodingStatusValues-pandemicIPS-VRDR-stage-1"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "ex-Decedent-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent",
        "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/Patient-vr",
        "http://hl7.org/fhir/StructureDefinition/Patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_ex-Decedent-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient ex-Decedent-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Decedent-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Decedent-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent.html\">Decedent</a>, <a href=\"http://hl7.org/fhir/us/vr-common-library/STU2/StructureDefinition-Patient-vr.html\">Patient - Vital Records</a>, <a href=\"http://hl7.org/fhir/R4/patient.html\">Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-MaritalStatus S}\">Never Married</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 07 850 9900(Mobile)</li><li>Grenzstraße Oberhausen 46045 GM (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: Unknown\">Unknown:</td><td colspan=\"3\"><ul><li>Joe Smith</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>General Practitioner: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner-pandemicIPS-VRDR-stage-1\">Yaser, Joseph</a></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Sex on visual inspection at the time of death by the funeral home\"><a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-NVSS-SexAtDeath.html\">NVSS SexAtDeath</a></td><td colspan=\"3\"><span title=\"Codes:{http://hl7.org/fhir/administrative-gender female}\">Female</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Spouse is Alive.\"><a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-SpouseAlive.html\">Spouse Is Alive</a></td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The registered place of birth of the patient. A sytem may use the address.text if they don't store the birthPlace address in discrete elements.\"><a href=\"http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-patient-birthPlace.html\">Patient Birth Place</a></td><td colspan=\"3\">Roanoke VA US </td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/SpouseAlive",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
            "code" : "Y"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/NVSS-SexAtDeath",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/administrative-gender",
            "code" : "female",
            "display" : "Female"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-birthPlace",
        "valueAddress" : {
          "city" : "Roanoke",
          "state" : "VA",
          "country" : "US"
        }
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "SB",
            "display" : "Social Beneficiary Identifier"
          }]
        },
        "system" : "http://hl7.org/fhir/sid/us-ssn",
        "value" : "123456789"
      }],
      "name" : [{
        "use" : "anonymous",
        "text" : "PseudoFamily",
        "family" : "PseudoFamily",
        "given" : ["PseudoGiven"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "07 850 9900",
        "use" : "mobile"
      }],
      "gender" : "female",
      "birthDate" : "1996-05-01",
      "address" : [{
        "use" : "home",
        "line" : ["Grenzstraße"],
        "city" : "Oberhausen",
        "postalCode" : "46045",
        "country" : "GM"
      }],
      "maritalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
          "code" : "S",
          "display" : "Never Married"
        }]
      },
      "contact" : [{
        "relationship" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
            "code" : "U"
          }],
          "text" : "Friend of family"
        }],
        "name" : {
          "text" : "Joe Smith"
        }
      }],
      "generalPractitioner" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner-pandemicIPS-VRDR-stage-1",
        "display" : "Yaser, Joseph"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Practitioner/ex-Practitioner-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "ex-Practitioner-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/ips/StructureDefinition/Practitioner-uv-ips"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_ex-Practitioner-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner ex-Practitioner-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Practitioner-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Practitioner-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/ips/STU2/StructureDefinition-Practitioner-uv-ips.html\">Practitioner (IPS)</a></p></div><p><b>name</b>: Joseph Yaser</p></div>"
      },
      "name" : [{
        "text" : "Joseph Yaser",
        "family" : "Joseph",
        "given" : ["Yaser"]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/RelatedPerson/ex-DecedentFather-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "RelatedPerson",
      "id" : "ex-DecedentFather-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-father"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_ex-DecedentFather-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson ex-DecedentFather-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentFather-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentFather-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-father.html\">Decedent Father</a></p></div><p><b>active</b>: true</p><p><b>patient</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode FTH}\">father</span></p><p><b>name</b>: Pseudo Dad(Anonymous)</p></div>"
      },
      "active" : true,
      "patient" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "relationship" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "FTH"
        }]
      }],
      "name" : [{
        "use" : "anonymous",
        "text" : "Pseudo Dad",
        "family" : "PseudoFamilyDad",
        "given" : ["PseudoGivenDad"],
        "_suffix" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
            "valueCode" : "masked"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/RelatedPerson/ex-DecedentMother-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "RelatedPerson",
      "id" : "ex-DecedentMother-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-mother"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_ex-DecedentMother-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson ex-DecedentMother-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentMother-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentMother-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-mother.html\">Decedent Mother</a></p></div><p><b>active</b>: true</p><p><b>patient</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode MTH}\">mother</span></p><p><b>name</b>: Pseudo Mom(Anonymous)</p></div>"
      },
      "active" : true,
      "patient" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "relationship" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "MTH"
        }]
      }],
      "name" : [{
        "use" : "anonymous",
        "text" : "Pseudo Mom",
        "family" : "PseudoFamilyMom",
        "given" : ["PseudoGivenMom"]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/RelatedPerson/ex-DecedentSpouse-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "RelatedPerson",
      "id" : "ex-DecedentSpouse-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-spouse"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_ex-DecedentSpouse-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson ex-DecedentSpouse-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentSpouse-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentSpouse-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-spouse.html\">Decedent Spouse</a></p></div><p><b>active</b>: true</p><p><b>patient</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode SPS}\">spouse</span></p><p><b>name</b>: Pseudo Spouse(Anonymous)</p></div>"
      },
      "active" : true,
      "patient" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "relationship" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "SPS"
        }]
      }],
      "name" : [{
        "use" : "anonymous",
        "text" : "Pseudo Spouse",
        "family" : "PseudoFamilySpouse",
        "given" : ["PseudoGivenSpouse"],
        "_suffix" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
            "valueCode" : "masked"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-DecedentAge-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-DecedentAge-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-age"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-DecedentAge-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-DecedentAge-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentAge-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentAge-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-age.html\">Decedent Age</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 39016-1}\">Age at death</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: 29 years<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "39016-1",
          "display" : "Age at death"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueQuantity" : {
        "value" : 29,
        "unit" : "years",
        "system" : "http://unitsofmeasure.org",
        "code" : "a"
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-usual-work"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentUsualWork-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentUsualWork-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-usual-work.html\">Decedent Usual Work</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21843-8}\">History of Usual occupation</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{https://profiles.ihe.net/PCC/ODH/CodeSystem/ISCO08 5321}\">Health Care Assistants</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 21844-6}\">History of Usual industry</span></td><td><span title=\"Codes:{https://profiles.ihe.net/PCC/ODH/CodeSystem/ISICRev4 871}\">Residential nursing care facilities</span></td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "21843-8",
          "display" : "History of Usual occupation"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/PCC/ODH/CodeSystem/ISCO08",
          "code" : "5321",
          "display" : "Health Care Assistants"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "21844-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://profiles.ihe.net/PCC/ODH/CodeSystem/ISICRev4",
            "code" : "871",
            "display" : "Residential nursing care facilities"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-DecedentPregStat-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-DecedentPregStat-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-pregnancy-status"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-DecedentPregStat-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-DecedentPregStat-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentPregStat-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentPregStat-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-pregnancy-status.html\">Decedent Pregnancy</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69442-2}\">Timing of recent pregnancy in relation to death</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/CodeSystem-death-pregnancy-status 2}\">Pregnant at time of death</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69442-2",
          "display" : "Timing of recent pregnancy in relation to death"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/CodeSystem-death-pregnancy-status",
          "code" : "2",
          "display" : "Pregnant at time of death"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-DeathDate-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-DeathDate-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-death-date"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-DeathDate-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-DeathDate-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DeathDate-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DeathDate-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-death-date.html\">Death Date</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81956-5}\">Date and time of death [TimeStamp]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <code>Partial Date Time Vital Records: </code></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80616-6}\">Date and time pronounced dead [US Standard Certificate of Death]</span></p><p><b>value</b>: 2024-06-30 16:39:40-0500</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 58332-8}\">Location of death</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-NullFlavor OTH}\">Other</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "81956-5",
          "display" : "Date and time of death [TimeStamp]"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "_valueDateTime" : {
        "extension" : [{
          "extension" : [{
            "url" : "day",
            "valueUnsignedInt" : 30
          },
          {
            "url" : "year",
            "valueUnsignedInt" : 2024
          },
          {
            "url" : "month",
            "valueUnsignedInt" : 6
          },
          {
            "url" : "time",
            "valueTime" : "12:13:14"
          }],
          "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/Extension-partial-date-time-vr"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "80616-6",
            "display" : "Date and time pronounced dead [US Standard Certificate of Death]"
          }]
        },
        "valueDateTime" : "2024-06-30T16:39:40-05:00"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "58332-8",
            "display" : "Location of death"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
            "code" : "OTH",
            "display" : "Other"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "ex-Practitioner2-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-practitioner"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_ex-Practitioner2-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner ex-Practitioner2-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Practitioner2-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Practitioner2-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/core/STU5.0.1/StructureDefinition-us-core-practitioner.html\">US Core Practitioner Profile</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/5.0.0/NamingSystem-npi.html\" title=\"National Provider Identifier\">NPI</a>/9941339101</p><p><b>name</b>: Jane Purple (Official)</p><p><b>address</b>: 44 South Street Rockville MD 20854 US </p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "9941339101"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Purple",
        "given" : ["Jane"]
      }],
      "address" : [{
        "line" : ["44 South Street"],
        "city" : "Rockville",
        "state" : "MD",
        "postalCode" : "20854",
        "country" : "US"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-MannerOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-MannerOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-manner-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-MannerOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-MannerOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-MannerOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-MannerOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-manner-of-death.html\">Manner of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69449-7}\">Manner of death</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 38605008}\">Natural death</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69449-7",
          "display" : "Manner of death"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "38605008",
          "display" : "Natural death"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "ex-Certifier-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-certifier"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_ex-Certifier-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner ex-Certifier-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Certifier-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Certifier-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-certifier.html\">Death Certifier</a></p></div><p><b>Practitioner Role</b>: Certifier</p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/5.0.0/NamingSystem-npi.html\" title=\"National Provider Identifier\">NPI</a>/9941339100</p><p><b>name</b>: Jim Black (Official)</p><p><b>address</b>: 44 South Street Bird in Hand PA 17505 US </p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/practitioner-role",
        "valueCode" : "Certifier"
      }],
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "9941339100"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Black",
        "given" : ["Jim"]
      }],
      "address" : [{
        "line" : ["44 South Street"],
        "city" : "Bird in Hand",
        "state" : "PA",
        "postalCode" : "17505",
        "country" : "US"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Procedure/ex-DeathCertification-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "ex-DeathCertification-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-death-certification"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_ex-DeathCertification-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure ex-DeathCertification-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DeathCertification-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DeathCertification-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-death-certification.html\">Death Certification Procedure</a></p></div><p><b>identifier</b>: 180</p><p><b>status</b>: Completed</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 308646001}\">Death certification</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>performed</b>: 2024-01-21 16:39:40-0500</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Function</b></td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-NullFlavor OTH}\">Nurse Practitioner</span></td><td><a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></td></tr></table></div>"
      },
      "identifier" : [{
        "value" : "180"
      }],
      "status" : "completed",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "308646001",
          "display" : "Death certification"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "performedDateTime" : "2024-01-21T16:39:40-05:00",
      "performer" : [{
        "function" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
            "code" : "OTH",
            "display" : "Other"
          }],
          "text" : "Nurse Practitioner"
        },
        "actor" : {
          "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-cause-of-death-part1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-CauseOfDeathPart1-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-cause-of-death-part1.html\">Cause Of Death Part 1</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69453-9}\">Cause of death [US Standard Certificate of Death]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></p><p><b>value</b>: <span title=\"Codes:\">Covid-19</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs lineNumber}\">line number</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69440-6}\">Disease onset to death interval</span></p><p><b>value</b>: 4 hours</p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69453-9",
          "display" : "Cause of death [US Standard Certificate of Death]"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "text" : "Covid-19"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs",
            "code" : "lineNumber"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "69440-6",
            "display" : "Disease onset to death interval"
          }]
        },
        "valueString" : "4 hours"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-cause-of-death-part1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-CauseOfDeathPart1-ex2-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-cause-of-death-part1.html\">Cause Of Death Part 1</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69453-9}\">Cause of death [US Standard Certificate of Death]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></p><p><b>value</b>: <span title=\"Codes:\">Eclampsia</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs lineNumber}\">line number</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69440-6}\">Disease onset to death interval</span></p><p><b>value</b>: 3 months</p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69453-9",
          "display" : "Cause of death [US Standard Certificate of Death]"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "text" : "Eclampsia"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs",
            "code" : "lineNumber"
          }]
        },
        "valueInteger" : 2
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "69440-6",
            "display" : "Disease onset to death interval"
          }]
        },
        "valueString" : "3 months"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-cause-of-death-part2"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-CauseOfDeathPart2-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-cause-of-death-part2.html\">Cause of Death Part 2</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69441-4}\">Other significant causes or conditions of death</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1\">Practitioner Jim Black (official)</a></p><p><b>value</b>: <span title=\"Codes:\">hypertensive heart disease</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69441-4",
          "display" : "Other significant causes or conditions of death"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Certifier-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "text" : "hypertensive heart disease"
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Location/ex-DispLocation-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Location",
      "id" : "ex-DispLocation-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-disposition-location"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_ex-DispLocation-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location ex-DispLocation-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DispLocation-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DispLocation-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-disposition-location.html\">Disposition Location</a></p></div><p><b>name</b>: Rosewood Cemetary</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-location-type-cs disposition}\">Disposition Location</span></p><p><b>address</b>: 303 Rosewood Ave Danville VA 24541 US </p><p><b>physicalType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/location-physical-type si}\">Site</span></p></div>"
      },
      "name" : "Rosewood Cemetary",
      "type" : [{
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-location-type-cs",
          "code" : "disposition"
        }]
      }],
      "address" : {
        "line" : ["303 Rosewood Ave"],
        "city" : "Danville",
        "state" : "VA",
        "postalCode" : "24541",
        "country" : "US"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
          "code" : "si",
          "display" : "Site"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-record-axis-cause-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-RecordAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-record-axis-cause-of-death.html\">Record Axis Cause Of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80357-7}\">Cause of death record axis code [Automated]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 U07.1}\">COVID-19, virus identified</span></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs position}\">position</span></td><td>1</td></tr></table></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80357-7",
          "display" : "Cause of death record axis code [Automated]"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "U07.1",
          "display" : "COVID-19, virus identified"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs",
            "code" : "position"
          }]
        },
        "valueInteger" : 1
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-entity-axis-cause-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-EntityAxisCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-entity-axis-cause-of-death.html\">Entity Axis Cause Of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80356-9}\">Cause of death entity axis code [Automated]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 U07.1}\">COVID-19, virus identified</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs lineNumber}\">line number</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs position}\">position</span></p><p><b>value</b>: 1</p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80356-9",
          "display" : "Cause of death entity axis code [Automated]"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "U07.1",
          "display" : "COVID-19, virus identified"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs",
            "code" : "lineNumber"
          }]
        },
        "valueInteger" : 1
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-component-cs",
            "code" : "position"
          }]
        },
        "valueInteger" : 1
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Practitioner/ex-Mortician-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "ex-Mortician-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-mortician"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_ex-Mortician-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner ex-Mortician-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-Mortician-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-Mortician-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-mortician.html\">Mortician</a></p></div><p><b>Practitioner Role</b>: Mortician</p><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/5.0.0/NamingSystem-npi.html\" title=\"National Provider Identifier\">NPI</a>/212222AB</p><p><b>name</b>: Ronald Q Smith(Official)</p></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/vrdr/StructureDefinition/practitioner-role",
        "valueCode" : "Mortician"
      }],
      "identifier" : [{
        "system" : "http://hl7.org/fhir/sid/us-npi",
        "value" : "212222AB"
      }],
      "name" : [{
        "use" : "official",
        "text" : "Ronald Q Smith",
        "family" : "Smith",
        "given" : ["Q"]
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-activity-at-time-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-ActivityAtTimeOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-activity-at-time-of-death.html\">Activity at Time of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80626-5}\">Activity at time of death [CDC]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-activity-at-time-of-death-cs 1}\">While engaged in leisure activities.</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80626-5"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-activity-at-time-of-death-cs",
          "code" : "1",
          "display" : "While engaged in leisure activities."
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vr-common-library/StructureDefinition/coded-race-and-ethnicity-vr"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-CodedRaceAndEthnicity-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vr-common-library/STU2/StructureDefinition-coded-race-and-ethnicity-vr.html\">Observation - Coded Race and Ethnicity Vital Records</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-local-observation-codes-vr codedraceandethnicity}\">Coded Race and Ethnicity</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component FirstEditedCode}\">First Edited Race Code</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr 101}\">White</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component SecondEditedCode}\">Second Edited Race Code</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr 122}\">Israeli</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component FirstAmericanIndianCode}\">First Edited American Indian Race Code</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr A31}\">Arikara</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component RaceRecode40}\">Race Recode 40</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-recode-40-vr 20}\">AIAN and Asian</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component HispanicCode}\">Hispanic Code</span></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-hispanic-origin-vr 233}\">Chilean</span></p></blockquote></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-local-observation-codes-vr",
          "code" : "codedraceandethnicity",
          "display" : "Coded Race and Ethnicity"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component",
            "code" : "FirstEditedCode"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr",
            "code" : "101",
            "display" : "White"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component",
            "code" : "SecondEditedCode"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr",
            "code" : "122",
            "display" : "Israeli"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component",
            "code" : "FirstAmericanIndianCode"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-code-vr",
            "code" : "A31",
            "display" : "Arikara"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component",
            "code" : "RaceRecode40"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-race-recode-40-vr",
            "code" : "20",
            "display" : "AIAN and Asian"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/codesystem-vr-component",
            "code" : "HispanicCode"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vr-common-library/CodeSystem/CodeSystem-hispanic-origin-vr",
            "code" : "233",
            "display" : "Chilean"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-manual-underlying-cause-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-ManualUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-manual-underlying-cause-of-death.html\">Manual Underlying Cause Of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80359-3}\">Cause of death.underlying [Manual]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 J96.0}\">Acute respiratory failure</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80359-3"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "J96.0",
          "display" : "Acute respiratory failure"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-automated-underlying-cause-of-death"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-AutomatedUnderlyingCauseOfDeath-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-automated-underlying-cause-of-death.html\">Automated Underlying Cause Of Death</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80358-5}\">Cause of death.underlying [Automated]</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/icd-10 J96.0}\">Acute respiratory failure</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80358-5"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/sid/icd-10",
          "code" : "J96.0",
          "display" : "Acute respiratory failure"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Organization/ex-FuneralHome-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "ex-FuneralHome-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-funeral-home"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_ex-FuneralHome-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization ex-FuneralHome-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-FuneralHome-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-FuneralHome-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-funeral-home.html\">Funeral Home</a></p></div><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-organization-type-cs funeralhome}\">Funeral Home</span></p><p><b>name</b>: Lancaster Funeral Home and Crematory</p><p><b>address</b>: 211 High Street Lancaster PA 17573 US </p></div>"
      },
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-organization-type-cs",
          "code" : "funeralhome"
        }]
      }],
      "name" : "Lancaster Funeral Home and Crematory",
      "address" : [{
        "line" : ["211 High Street"],
        "city" : "Lancaster",
        "state" : "PA",
        "postalCode" : "17573",
        "country" : "US"
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-decedent-disposition-method"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-DecedentDispositionMethod-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-decedent-disposition-method.html\">Decedent Disposition Method</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80905-3}\">Body disposition method</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Mortician-pandemicIPS-VRDR-stage-1\">Practitioner Ronald Q Smith(official)</a></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-NullFlavor OTH}\">Other</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80905-3"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Mortician-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
          "code" : "OTH",
          "display" : "Other"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Observation/ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-place-of-injury"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1</b></p><a name=\"ex-PlaceOfInjury-pandemicIPS-VRDR-stage-1\"> </a><a name=\"hcex-PlaceOfInjury-pandemicIPS-VRDR-stage-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/vrdr/STU3/StructureDefinition-vrdr-place-of-injury.html\">Place Of Injury</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11376-1}\">Injury location</span></p><p><b>subject</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1\">PseudoFamily(anonymous) Female, DoB: 1996-05-01 ( Social Beneficiary Identifier: SSN#123456789)</a></p><p><b>effective</b>: 2024-06-30 16:39:40-0500</p><p><b>performer</b>: <a href=\"Bundle-e817cefe-a7c4-487a-8116-be23cf865f3f.html#http-//example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1\">Practitioner Jane Purple (official)</a></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA14084-0}\">Home</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11376-1"
        }]
      },
      "subject" : {
        "reference" : "http://example.org/Patient/ex-Decedent-pandemicIPS-VRDR-stage-1"
      },
      "effectiveDateTime" : "2024-06-30T16:39:40-05:00",
      "performer" : [{
        "reference" : "http://example.org/Practitioner/ex-Practitioner2-pandemicIPS-VRDR-stage-1"
      }],
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA14084-0",
          "display" : "Home"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://example.org/Parameters/ex-CodingStatusValues-pandemicIPS-VRDR-stage-1",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "ex-CodingStatusValues-pandemicIPS-VRDR-stage-1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/us/vrdr/StructureDefinition/vrdr-coding-status-values"]
      },
      "parameter" : [{
        "name" : "shipmentNumber",
        "valueString" : "A2B2"
      },
      {
        "name" : "receiptDate",
        "valueDate" : "2021-12-12"
      },
      {
        "name" : "coderStatus",
        "valueInteger" : 5
      },
      {
        "name" : "intentionalReject",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-intentional-reject-cs",
            "code" : "1",
            "display" : "Reject1"
          }]
        }
      },
      {
        "name" : "acmeSystemReject",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-system-reject-cs",
            "code" : "0",
            "display" : "Not Rejected"
          }]
        }
      },
      {
        "name" : "transaxConversion",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/vrdr-transax-conversion-cs",
            "code" : "3",
            "display" : "Conversion using non-ambivalent table entries"
          }]
        }
      }]
    }
  }]
}

```
