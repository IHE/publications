# ihe.formatcode.fhir#1.5.1-current: IHE FormatCode Vocabulary

## Pages

* [FormatCode Home Page](index.md)
* [Artifacts Summary](artifacts.md)
* [Background](background.md)

## Resources

### CodeSystems

* [IHE Format Code set for use with Document Sharing](CodeSystem-formatcode.md)

### ValueSets

* [IHE ValueSet of Format Codes for use with Document Sharing](ValueSet-formatcode.md)

### Bundles

* [history-IHE-formatcode.codesystem](Bundle-history-IHE-formatcode.codesystem.md)
* [history-IHE-formatcode.valueset](Bundle-history-IHE-formatcode.valueset.md)

### ImplementationGuides

* [IHE FormatCode Vocabulary](index.md)
