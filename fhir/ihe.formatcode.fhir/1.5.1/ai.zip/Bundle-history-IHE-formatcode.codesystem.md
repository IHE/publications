#  - IHE FormatCode Vocabulary v1.5.1-current

## : 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "history-IHE-formatcode.codesystem",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20250428.1",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20250428",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20250428\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20250428</b></p><a name=\"formatcode-provenance-20250428\"> </a><a name=\"hcformatcode-provenance-20250428\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2025-04-28</td></tr><tr><td>Recorded</td><td>2025-04-28 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>Fix PaLM code values</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2025-04-28"
      },
      "recorded" : "2025-04-28T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Fix PaLM code values, from using a `.` to `:`."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "Fix PaLM code values"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20240327.1",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20240327",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20240327\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20240327</b></p><a name=\"formatcode-provenance-20240327\"> </a><a name=\"hcformatcode-provenance-20240327\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2024-03-27</td></tr><tr><td>Recorded</td><td>2024-03-27 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Mary Jungers</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE Eye Care domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2024-03-27"
      },
      "recorded" : "2024-03-27T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Added three missing Eye Care codes. GitHub Issue #25."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Mary Jungers"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE Eye Care domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20240205.1",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20240205",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20240205\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20240205</b></p><a name=\"formatcode-provenance-20240205\"> </a><a name=\"hcformatcode-provenance-20240205\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2024-02-05</td></tr><tr><td>Recorded</td><td>2024-02-05 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE ITI Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2024-02-05"
      },
      "recorded" : "2024-02-05T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Change the non-deprecated to status of active."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE ITI Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20220814.1",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20220814",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20220814\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20220814</b></p><a name=\"formatcode-provenance-20220814\"> </a><a name=\"hcformatcode-provenance-20220814\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2022-08-15</td></tr><tr><td>Recorded</td><td>2022-08-15 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE ITI Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2022-08-15"
      },
      "recorded" : "2022-08-15T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Change the include HL7 managed FormatCode vocabulary to formal one found on terminology.hl7.org."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE ITI Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.202100419.3",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-202100419-3",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-202100419-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-202100419-3</b></p><a name=\"formatcode-provenance-202100419-3\"> </a><a name=\"hcformatcode-provenance-202100419-3\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2022-02-16</td></tr><tr><td>Recorded</td><td>2022-02-16 23:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE RAD Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2022-02-16"
      },
      "recorded" : "2022-02-16T23:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Change the Display for code urn:ihe:rad:CDA:ImagingReportStructuredHeadings:2013. It is currently “RAD XDS-I”, which is too generic. If you followed the pattern used in DENT (DENT TEXT, DENT PDF, DENT CDA), then you would change the code to “RAD CDA” (because RAD TEXT and RAD PDF exist)."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE RAD Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.202100419.2",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-202100419-2",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-202100419-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-202100419-2</b></p><a name=\"formatcode-provenance-202100419-2\"> </a><a name=\"hcformatcode-provenance-202100419-2\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2021-04-19</td></tr><tr><td>Recorded</td><td>2021-04-19 15:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Oliver Egger</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE PCC Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2021-04-19"
      },
      "recorded" : "2021-04-19T15:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Change urn:ihe:pcc:irc:2008 to urn:ihe:pcc:ic:2008 (see https://www.ihe.net/uploadedFiles/Documents/PCC/IHE_PCC_TF_Vol2.pdf)"
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Oliver Egger"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE PCC Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.202100419",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-202100419",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-202100419\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-202100419</b></p><a name=\"formatcode-provenance-202100419\"> </a><a name=\"hcformatcode-provenance-202100419\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2021-04-19</td></tr><tr><td>Recorded</td><td>2021-04-19 15:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Oliver Egger</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE Pharmacy Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2021-04-19"
      },
      "recorded" : "2021-04-19T15:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Add IHE PHARM MTP and CMA code"
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Oliver Egger"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE Pharmacy Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20210309",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20210309",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20210309\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20210309</b></p><a name=\"formatcode-provenance-20210309\"> </a><a name=\"hcformatcode-provenance-20210309\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2021-03-09</td></tr><tr><td>Recorded</td><td>2021-03-09 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Vassil Peytchev</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE PCC Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2021-03-09"
      },
      "recorded" : "2021-03-09T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Add PCC 360X format codes."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Vassil Peytchev"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE PCC Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20200724",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20200724",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20200724\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20200724</b></p><a name=\"formatcode-provenance-20200724\"> </a><a name=\"hcformatcode-provenance-20200724\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2020-07-24</td></tr><tr><td>Recorded</td><td>2020-07-24 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE PaLM Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2020-07-24"
      },
      "recorded" : "2020-07-24T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Remove PAT domain, as PALM is right. Remove 2010 FormatCodes not used in favor of urn:ihe:palm:apsr:2016."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE PaLM Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20200723",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20200723",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20200723\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20200723</b></p><a name=\"formatcode-provenance-20200723\"> </a><a name=\"hcformatcode-provenance-20200723\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2020-07-23</td></tr><tr><td>Recorded</td><td>2020-07-23 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE QRPH Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2020-07-23"
      },
      "recorded" : "2020-07-23T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "QRPH deprecated urn:ihe:qrph:crpc:2012."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE QRPH Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20200703",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20200703",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20200703\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20200703</b></p><a name=\"formatcode-provenance-20200703\"> </a><a name=\"hcformatcode-provenance-20200703\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2020-07-03</td></tr><tr><td>Recorded</td><td>2020-07-03 13:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE IT-Infrastructure Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2020-07-03"
      },
      "recorded" : "2020-07-03T13:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "align all display on the profile acronym, with name of profile in definition."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE IT-Infrastructure Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20200701",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20200701",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20200701\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20200701</b></p><a name=\"formatcode-provenance-20200701\"> </a><a name=\"hcformatcode-provenance-20200701\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2020-07-01</td></tr><tr><td>Recorded</td><td>2020-07-01 23:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>John Moehrke</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE IT-Infrastructure Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2020-07-01"
      },
      "recorded" : "2020-07-01T23:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "Regular maintenance for 2020, and inclusion of QRPH codes. Added Ontology to structure according to IHE domains."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "John Moehrke"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE IT-Infrastructure Domain"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:oid:1.3.6.1.4.1.19376.1.2.3.1.20260225",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "formatcode-provenance-20260225",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_formatcode-provenance-20260225\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance formatcode-provenance-20260225</b></p><a name=\"formatcode-provenance-20260225\"> </a><a name=\"hcformatcode-provenance-20260225\"> </a><p>Provenance for <a href=\"CodeSystem-formatcode.html\">IHE Format Code set for use with Document Sharing</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>?? --&gt; 2026-02-25</td></tr><tr><td>Recorded</td><td>2026-02-25 23:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation CREATE}\">create</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Wim Corbijn</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type custodian}\">Custodian</span></td><td>IHE RAD-Radiology Domain</td></tr></table></div>"
      },
      "target" : [{
        "reference" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "type" : "CodeSystem"
      }],
      "occurredPeriod" : {
        "end" : "2026-02-25"
      },
      "recorded" : "2026-02-25T23:00:00.0000Z",
      "reason" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "METAMGT"
        }],
        "text" : "MADO format code (CP#35)."
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "CREATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Wim Corbijn"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "custodian"
          }]
        },
        "who" : {
          "display" : "IHE RAD-Radiology Domain"
        }
      }]
    }
  }]
}

```
