# mado-bundle--2047166866 - Manifest-based Access to DICOM Objects (MADO) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mado-bundle--2047166866**

## Bundle: mado-bundle--2047166866



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mado-bundle--2047166866",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoFhirBundle#0.1.0"]
  },
  "identifier" : {
    "system" : "http://example.org/fhir/document-ids",
    "value" : "mado-bundle--2047166866"
  },
  "type" : "document",
  "timestamp" : "2026-06-19T17:00:57.644+02:00",
  "entry" : [{
    "fullUrl" : "urn:Composition/mado-comp-1814516963",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "mado-comp-1814516963",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_mado-comp-1814516963\"> </a><h1>Head CT on CT of Head</h1><table><tbody><tr><td><b>Study Instance UID</b></td><td>1.2.250.1.59.40211.22756022.2.1.101</td></tr><tr><td><b>Subject</b></td><td><span>John DOE<span> </span></span></td></tr><tr><td><b>Author</b></td><td><span>IHEeu imaging converter<span> </span></span></td></tr><tr><td><b>Author</b></td><td><span>Example Hospital<span> </span></span></td></tr><tr><td><b>Created</b></td><td>Fri Jun 19 17:00:57 CEST 2026</td></tr><tr><td><b>Type</b></td><td>Diagnostic imaging Study</td></tr><tr><td><b>Category</b></td><td>Medical-Imaging</td></tr><tr><td><b>Study Start</b></td><td>Mon Aug 22 08:31:17 CEST 2022</td></tr><tr><td><b>Modalities</b></td><td>CT</td></tr><tr><td><b>Anatomical region</b></td><td>Structure of head and/or neck</td></tr><tr><td><b>Accession number</b></td><td>http://example.org/fhir/ris-ids | 1731954284869428 </td></tr><tr><td><b>Procedure</b></td><td>Head CT</td></tr><tr><td><b>Number of series</b></td><td>2</td></tr></tbody></table></div>"
      },
      "identifier" : {
        "system" : "http://example.org/fhir/document-ids",
        "value" : "mado-bundle--2047166866"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18748-4",
          "display" : "Diagnostic imaging Study"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/eu-health-data-api/CodeSystem/eehrxf-document-priority-category-cs",
          "code" : "Medical-Imaging",
          "display" : "Medical-Imaging"
        }]
      }],
      "subject" : {
        "reference" : "urn:Patient/pat-mrn--1097192655",
        "type" : "Patient",
        "display" : "John DOE"
      },
      "date" : "2026-06-19T17:00:57+02:00",
      "author" : [{
        "reference" : "urn:Device/creator-device",
        "type" : "Device",
        "display" : "IHEeu imaging converter"
      },
      {
        "reference" : "urn:Organization/creator-organization",
        "type" : "Organization",
        "display" : "Example Hospital"
      }],
      "title" : "Head CT on CT of Head",
      "event" : [{
        "detail" : [{
          "reference" : "urn:ImagingStudy/1.2.250.1.59.40211.22756022.2.1.101",
          "type" : "ImagingStudy",
          "display" : "Study A"
        }]
      }],
      "section" : [{
        "title" : "Series 1",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><td><b>Series Id</b></td><td>1.2.250.1.59.40211.22756022.2.2.101.201</td></tr><tr><td><b>Modality</b></td><td>CT</td></tr><tr><td><b>Bodysite</b></td><td>Head</td></tr><tr><td><b>Started</b></td><td>Mon Aug 22 16:47:58 CEST 2022</td></tr><tr><td><b>Description</b></td><td>Series A1</td></tr><tr><td><b>Number of Instances</b></td><td>50</td></tr><tr><td><b>Endpoint</b></td><td>WADO endpoint: http://example.com/wado</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "urn:Endpoint/wado-url-endpoint--271104327",
          "type" : "Endpoint",
          "display" : "WADO endpoint"
        }]
      },
      {
        "title" : "Series 2",
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table><tbody><tr><td><b>Series Id</b></td><td>1.2.250.1.59.40211.22756022.2.2.101.202</td></tr><tr><td><b>Modality</b></td><td>CT</td></tr><tr><td><b>Bodysite</b></td><td>Head</td></tr><tr><td><b>Started</b></td><td>Mon Aug 22 16:47:58 CEST 2022</td></tr><tr><td><b>Description</b></td><td>Series A2</td></tr><tr><td><b>Number of Instances</b></td><td>36</td></tr><tr><td><b>Endpoint</b></td><td>WADO endpoint: http://example.com/wado</td></tr></tbody></table></div>"
        },
        "entry" : [{
          "reference" : "urn:Endpoint/wado-url-endpoint--271104327",
          "type" : "Endpoint",
          "display" : "WADO endpoint"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:ImagingStudy/1.2.250.1.59.40211.22756022.2.1.101",
    "resource" : {
      "resourceType" : "ImagingStudy",
      "id" : "1.2.250.1.59.40211.22756022.2.1.101",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImagingStudy_1.2.250.1.59.40211.22756022.2.1.101\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>ImagingStudy/1.2.250.1.59.40211.22756022.2.1.101</td></tr><tr><td><b>extension</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>url</b></td><td>https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoAnatomicalRegionExtension</td></tr><tr><td><b>value[x]</b></td><td>Structure of head and/or neck</td></tr></tbody></table></div></td></tr><tr><td><b>identifier</b></td><td><span><b>Study Instance UID: </b>urn:oid:1.2.250.1.59.40211.22756022.2.1.101 [urn:dicom:uid]</span></td></tr><tr><td><b>status</b></td><td>available</td></tr><tr><td><b>modality</b></td><td>CT (http://dicom.nema.org/resources/ontology/DCM)</td></tr><tr><td><b>subject</b></td><td><span>John DOE<span> </span></span></td></tr><tr><td><b>started</b></td><td>2022-08-22T08:31:17+02:00</td></tr><tr><td><b>basedOn</b></td><td><span>Requested Procedure: 1731954284869428<span> </span></span></td></tr><tr><td><b>numberOfSeries</b></td><td>2</td></tr><tr><td><b>numberOfInstances</b></td><td>86</td></tr><tr><td><b>procedureCode</b></td><td>Head CT</td></tr><tr><td><b>description</b></td><td>Study A</td></tr><tr><td><b>series</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.2.101.201</td></tr><tr><td><b>number</b></td><td>1</td></tr><tr><td><b>modality</b></td><td>CT (http://dicom.nema.org/resources/ontology/DCM)</td></tr><tr><td><b>description</b></td><td>Series A1</td></tr><tr><td><b>numberOfInstances</b></td><td>50</td></tr><tr><td><b>endpoint</b></td><td><span>WADO endpoint<span> </span></span></td></tr><tr><td><b>bodySite</b></td><td>Head</td></tr><tr><td><b>started</b></td><td>2022-08-22T16:47:58+02:00</td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.37</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>7</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.36</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>6</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.39</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>9</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.38</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>8</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.33</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>3</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.32</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>2</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.35</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>5</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.34</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>4</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.320</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>20</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.321</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>21</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.322</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>22</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.31</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>1</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.323</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>23</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.324</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>24</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.325</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>25</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.326</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>26</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.327</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>27</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.317</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>17</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.318</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>18</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.319</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>19</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.350</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>50</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.310</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>10</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.311</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>11</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.312</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>12</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.313</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>13</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.314</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>14</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.315</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>15</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.316</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>16</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.340</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>40</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.341</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>41</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.342</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>42</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.343</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>43</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.344</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>44</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.345</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>45</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.346</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>46</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.347</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>47</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.348</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>48</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.349</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>49</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.339</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>39</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.330</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>30</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.331</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>31</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.332</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>32</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.333</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>33</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.334</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>34</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.335</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>35</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.336</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>36</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.337</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>37</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.338</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>38</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.328</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>28</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.201.329</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>29</td></tr></tbody></table></div></td></tr></tbody></table></div></td></tr><tr><td><b>series</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.2.101.202</td></tr><tr><td><b>number</b></td><td>2</td></tr><tr><td><b>modality</b></td><td>CT (http://dicom.nema.org/resources/ontology/DCM)</td></tr><tr><td><b>description</b></td><td>Series A2</td></tr><tr><td><b>numberOfInstances</b></td><td>36</td></tr><tr><td><b>endpoint</b></td><td><span>WADO endpoint<span> </span></span></td></tr><tr><td><b>bodySite</b></td><td>Head</td></tr><tr><td><b>started</b></td><td>2022-08-22T16:47:58+02:00</td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.325</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>25</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.326</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>26</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.323</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>23</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.324</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>24</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.321</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>21</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.322</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>22</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.320</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>20</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.318</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>18</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.319</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>19</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.316</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>16</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.317</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>17</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.38</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>8</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.336</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>36</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.314</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>14</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.37</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>7</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.315</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>15</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.334</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>34</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.312</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>12</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.39</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>9</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.335</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>35</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.313</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>13</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.310</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>10</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.332</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>32</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.34</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>4</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.333</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>33</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.33</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>3</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.311</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>11</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.36</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>6</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.330</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>30</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.35</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>5</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.331</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>31</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.32</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>2</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.31</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>1</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.329</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>29</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.327</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>27</td></tr></tbody></table></div></td></tr><tr><td><b>instance</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>uid</b></td><td>1.2.250.1.59.40211.22756022.2.3.101.202.328</td></tr><tr><td><b>sopClass</b></td><td>urn:oid:1.2.840.10008.5.1.4.1.1.2 (http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs)</td></tr><tr><td><b>number</b></td><td>28</td></tr></tbody></table></div></td></tr></tbody></table></div></td></tr></tbody></table></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoAnatomicalRegionExtension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "774007",
            "display" : "Structure of head and/or neck"
          }]
        }
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://dicom.nema.org/resources/ontology/DCM",
            "code" : "110180",
            "display" : "Study Instance UID"
          }]
        },
        "system" : "urn:dicom:uid",
        "value" : "urn:oid:1.2.250.1.59.40211.22756022.2.1.101"
      }],
      "status" : "available",
      "modality" : [{
        "system" : "http://dicom.nema.org/resources/ontology/DCM",
        "code" : "CT"
      }],
      "subject" : {
        "reference" : "urn:Patient/pat-mrn--1097192655",
        "type" : "Patient",
        "display" : "John DOE"
      },
      "started" : "2022-08-22T08:31:17+02:00",
      "basedOn" : [{
        "reference" : "urn:ServiceRequest/reqproc--497309711",
        "type" : "ServiceRequest",
        "identifier" : {
          "type" : {
            "coding" : [{
              "system" : "http://dicom.nema.org/resources/ontology/DCM",
              "code" : "121022",
              "display" : "Accession Number"
            },
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "ACSN",
              "display" : "Accession Id"
            }]
          },
          "system" : "http://example.org/fhir/ris-ids",
          "value" : "1731954284869428"
        },
        "display" : "Requested Procedure: 1731954284869428"
      }],
      "numberOfSeries" : 2,
      "numberOfInstances" : 86,
      "procedureCode" : [{
        "text" : "Head CT"
      }],
      "description" : "Study A",
      "series" : [{
        "uid" : "1.2.250.1.59.40211.22756022.2.2.101.201",
        "number" : 1,
        "modality" : {
          "system" : "http://dicom.nema.org/resources/ontology/DCM",
          "code" : "CT"
        },
        "description" : "Series A1",
        "numberOfInstances" : 50,
        "endpoint" : [{
          "reference" : "urn:Endpoint/wado-url-endpoint--271104327",
          "type" : "Endpoint",
          "display" : "WADO endpoint"
        }],
        "bodySite" : {
          "system" : "http://snomed.info/sct",
          "code" : "69536005",
          "display" : "Head"
        },
        "started" : "2022-08-22T16:47:58+02:00",
        "instance" : [{
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.37",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 7
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.36",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 6
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.39",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 9
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.38",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 8
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.33",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 3
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.32",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 2
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.35",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 5
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.34",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 4
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.320",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 20
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.321",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 21
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.322",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 22
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.31",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 1
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.323",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 23
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.324",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 24
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.325",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 25
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.326",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 26
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.327",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 27
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.317",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 17
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.318",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 18
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.319",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 19
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.350",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 50
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.310",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 10
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.311",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 11
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.312",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 12
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.313",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 13
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.314",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 14
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.315",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 15
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.316",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 16
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.340",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 40
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.341",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 41
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.342",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 42
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.343",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 43
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.344",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 44
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.345",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 45
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.346",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 46
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.347",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 47
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.348",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 48
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.349",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 49
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.339",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 39
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.330",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 30
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.331",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 31
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.332",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 32
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.333",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 33
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.334",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 34
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.335",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 35
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.336",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 36
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.337",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 37
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.338",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 38
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.328",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 28
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.201.329",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 29
        }]
      },
      {
        "uid" : "1.2.250.1.59.40211.22756022.2.2.101.202",
        "number" : 2,
        "modality" : {
          "system" : "http://dicom.nema.org/resources/ontology/DCM",
          "code" : "CT"
        },
        "description" : "Series A2",
        "numberOfInstances" : 36,
        "endpoint" : [{
          "reference" : "urn:Endpoint/wado-url-endpoint--271104327",
          "type" : "Endpoint",
          "display" : "WADO endpoint"
        }],
        "bodySite" : {
          "system" : "http://snomed.info/sct",
          "code" : "69536005",
          "display" : "Head"
        },
        "started" : "2022-08-22T16:47:58+02:00",
        "instance" : [{
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.325",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 25
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.326",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 26
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.323",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 23
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.324",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 24
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.321",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 21
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.322",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 22
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.320",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 20
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.318",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 18
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.319",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 19
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.316",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 16
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.317",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 17
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.38",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 8
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.336",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 36
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.314",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 14
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.37",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 7
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.315",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 15
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.334",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 34
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.312",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 12
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.39",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 9
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.335",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 35
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.313",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 13
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.310",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 10
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.332",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 32
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.34",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 4
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.333",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 33
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.33",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 3
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.311",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 11
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.36",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 6
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.330",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 30
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.35",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 5
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.331",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 31
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.32",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 2
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.31",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 1
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.329",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 29
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.327",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 27
        },
        {
          "uid" : "1.2.250.1.59.40211.22756022.2.3.101.202.328",
          "sopClass" : {
            "system" : "http://dicom.nema.org/resources/CodeSystem/DICOM_UIDs",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.2"
          },
          "number" : 28
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:Organization/creator-organization",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "creator-organization",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_creator-organization\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>Organization/creator-organization</td></tr><tr><td><b>identifier</b></td><td><span>akdjiefef [http://example.org/fhir/organization-ids]</span></td></tr><tr><td><b>name</b></td><td>Example Hospital</td></tr></tbody></table></div>"
      },
      "identifier" : [{
        "system" : "http://example.org/fhir/organization-ids",
        "value" : "akdjiefef"
      }],
      "name" : "Example Hospital"
    }
  },
  {
    "fullUrl" : "urn:Patient/pat-mrn--1097192655",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "pat-mrn--1097192655",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_pat-mrn--1097192655\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>Patient/pat-mrn--1097192655</td></tr><tr><td><b>identifier</b></td><td><span><b>Usual: </b><b>Medical Record number: </b>UV59569735 [http://example.org/fhir/mrn-ids]</span></td></tr><tr><td><b>name</b></td><td>John DOE</td></tr><tr><td><b>gender</b></td><td>male</td></tr><tr><td><b>birthDate</b></td><td>1977-05-30</td></tr></tbody></table></div>"
      },
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR",
            "display" : "Medical Record number"
          }]
        },
        "system" : "http://example.org/fhir/mrn-ids",
        "value" : "UV59569735"
      }],
      "name" : [{
        "text" : "John DOE",
        "family" : "DOE",
        "given" : ["John"]
      }],
      "gender" : "male",
      "birthDate" : "1977-05-30"
    }
  },
  {
    "fullUrl" : "urn:Endpoint/wado-url-endpoint--271104327",
    "resource" : {
      "resourceType" : "Endpoint",
      "id" : "wado-url-endpoint--271104327",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Endpoint_wado-url-endpoint--271104327\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>Endpoint/wado-url-endpoint--271104327</td></tr><tr><td><b>extension</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>url</b></td><td>https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoRetrieveLocationUIDExtension</td></tr><tr><td><b>value[x]</b></td><td>ACME</td></tr></tbody></table></div></td></tr><tr><td><b>status</b></td><td>active</td></tr><tr><td><b>connectionType</b></td><td>dicom-wado-rs (http://terminology.hl7.org/CodeSystem/endpoint-connection-type)</td></tr><tr><td><b>name</b></td><td>WADO endpoint</td></tr><tr><td><b>payloadType</b></td><td>DICOM WADO-RS</td></tr><tr><td><b>payloadMimeType</b></td><td>application/dicom</td></tr><tr><td><b>payloadMimeType</b></td><td>application/octet-stream</td></tr><tr><td><b>payloadMimeType</b></td><td>application/dicom+xml</td></tr><tr><td><b>payloadMimeType</b></td><td>application/dicom+json</td></tr><tr><td><b>payloadMimeType</b></td><td>image/jpg</td></tr><tr><td><b>payloadMimeType</b></td><td>image/gif</td></tr><tr><td><b>payloadMimeType</b></td><td>image/jp2</td></tr><tr><td><b>payloadMimeType</b></td><td>image/jph</td></tr><tr><td><b>payloadMimeType</b></td><td>image/jxl</td></tr><tr><td><b>payloadMimeType</b></td><td>video/mpeg</td></tr><tr><td><b>payloadMimeType</b></td><td>video/mp4</td></tr><tr><td><b>payloadMimeType</b></td><td>video/H265</td></tr><tr><td><b>payloadMimeType</b></td><td>text/html</td></tr><tr><td><b>payloadMimeType</b></td><td>text/rtf</td></tr><tr><td><b>payloadMimeType</b></td><td>application/pdf</td></tr><tr><td><b>address</b></td><td>http://example.com/wado</td></tr></tbody></table></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoRetrieveLocationUIDExtension",
        "valueString" : "ACME"
      }],
      "status" : "active",
      "connectionType" : {
        "system" : "http://terminology.hl7.org/CodeSystem/endpoint-connection-type",
        "code" : "dicom-wado-rs"
      },
      "name" : "WADO endpoint",
      "payloadType" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/endpoint-payload-type",
          "code" : "none",
          "display" : "None"
        }],
        "text" : "DICOM WADO-RS"
      }],
      "payloadMimeType" : ["application/dicom",
      "application/octet-stream",
      "application/dicom+xml",
      "application/dicom+json",
      "image/jpg",
      "image/gif",
      "image/jp2",
      "image/jph",
      "image/jxl",
      "video/mpeg",
      "video/mp4",
      "video/H265",
      "text/html",
      "text/rtf",
      "application/pdf"],
      "address" : "http://example.com/wado"
    }
  },
  {
    "fullUrl" : "urn:Device/creator-device",
    "resource" : {
      "resourceType" : "Device",
      "id" : "creator-device",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_creator-device\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>Device/creator-device</td></tr><tr><td><b>manufacturer</b></td><td>Philips IP&amp;S</td></tr><tr><td><b>manufactureDate</b></td><td>2026-03-17T00:00:00+01:00</td></tr><tr><td><b>deviceName</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>name</b></td><td>IHEeu imaging converter</td></tr><tr><td><b>type</b></td><td>user-friendly-name</td></tr></tbody></table></div></td></tr><tr><td><b>type</b></td><td>MADO Creator</td></tr><tr><td><b>owner</b></td><td><span>Example Hospital<span> </span></span></td></tr></tbody></table></div>"
      },
      "manufacturer" : "Philips IP&S",
      "manufactureDate" : "2026-03-17T00:00:00+01:00",
      "deviceName" : [{
        "name" : "IHEeu imaging converter",
        "type" : "user-friendly-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/RAD/MADO/CodeSystem/MadoDeviceType",
          "code" : "mado-creator",
          "display" : "MADO Creator"
        }]
      },
      "owner" : {
        "reference" : "urn:Organization/creator-organization",
        "type" : "Organization",
        "display" : "Example Hospital"
      }
    }
  },
  {
    "fullUrl" : "urn:ServiceRequest/reqproc--497309711",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "reqproc--497309711",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_reqproc--497309711\"> </a><table class=\".border-bottom\"><tbody><tr><td><b>id</b></td><td>ServiceRequest/reqproc--497309711</td></tr><tr><td><b>meta</b></td><td><div><table class=\".border-bottom\"><tbody><tr><td><b>tag</b></td><td>Requested Procedure</td></tr></tbody></table></div></td></tr><tr><td><b>identifier</b></td><td><span><b>Accession Number: </b>1731954284869428 [http://example.org/fhir/ris-ids]</span></td></tr><tr><td><b>status</b></td><td>completed</td></tr><tr><td><b>intent</b></td><td>order</td></tr><tr><td><b>category</b></td><td>Imaging</td></tr><tr><td><b>subject</b></td><td><span>John DOE<span> </span></span></td></tr></tbody></table></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://dicom.nema.org/resources/ontology/DCM",
            "code" : "121022",
            "display" : "Accession Number"
          },
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "ACSN",
            "display" : "Accession Id"
          }]
        },
        "system" : "http://example.org/fhir/ris-ids",
        "value" : "1731954284869428"
      }],
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "363679005",
          "display" : "Imaging"
        }]
      }],
      "subject" : {
        "reference" : "urn:Patient/pat-mrn--1097192655",
        "type" : "Patient",
        "display" : "John DOE"
      }
    }
  }]
}

```
