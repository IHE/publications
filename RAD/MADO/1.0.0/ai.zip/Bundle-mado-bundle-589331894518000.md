# Bundle: MADO FHIR document - Manifest-based Access to DICOM Objects (MADO) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle: MADO FHIR document**

## Example Bundle: Bundle: MADO FHIR document



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mado-bundle-589331894518000",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoFhirBundle"]
  },
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:4fe96b54-204d-4f98-ae8d-491869a8ba01"
  },
  "type" : "document",
  "timestamp" : "2026-02-24T11:48:21.136+01:00",
  "entry" : [{
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/Composition/MadoCompositionExample",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "MadoCompositionExample",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoComposition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_MadoCompositionExample\"> </a><h1>Head CT</h1><table><tbody><tr><td><b>Study Instance UID</b></td><td>1.2.392.200140.2.1.1.1.2.799008771.2076.1519721309.448</td></tr><tr><td><b>Subject</b></td><td><span>ExamplePatient</span></td></tr><tr><td><b>Author</b></td><td><span>MADO creator</span></td></tr><tr><td><b>Author</b></td><td><span>ACME</span></td></tr><tr><td><b>Created</b></td><td>2026-05-29</td></tr><tr><td><b>Type</b></td><td>Diagnostic imaging Study</td></tr><tr><td><b>Category</b></td><td>Medical-Imaging</td></tr><tr><td><b>Study Start</b></td><td>2018-02-27T09:48:29+01:00</td></tr><tr><td><b>Modalities</b></td><td>SM</td></tr><tr><td><b>Anatomical region</b></td><td>Upper trunk Thoracic segment of trunk</td></tr><tr><td><b>Accession number</b></td><td>http://hospital.org/acc | 2017092101</td></tr><tr><td><b>Number of series</b></td><td>1</td></tr></tbody></table></div>"
      },
      "identifier" : {
        "system" : "urn:dicom:uid",
        "value" : "1.2.392.200140.2.1.1.1.2.799008771.2076.1519721309.448"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18748-4",
          "display" : "Diagnostic Imaging Study"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18748-4",
          "display" : "Diagnostic imaging study"
        }]
      }],
      "subject" : {
        "reference" : "Patient/ExamplePatient"
      },
      "date" : "2025-05-08T00:00:00Z",
      "author" : [{
        "reference" : "Device/MadoCreatorDeviceExample"
      },
      {
        "reference" : "Organization/MadoCreatorOrganizationExample"
      }],
      "title" : "CT of the head without contrast",
      "event" : [{
        "detail" : [{
          "reference" : "ImagingStudy/ExampleImagingStudy"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/ImagingStudy/ExampleImagingStudy",
    "resource" : {
      "resourceType" : "ImagingStudy",
      "id" : "ExampleImagingStudy",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoImagingStudy"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImagingStudy_ExampleImagingStudy\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImagingStudy ExampleImagingStudy</b></p><a name=\"ExampleImagingStudy\"> </a><a name=\"hcExampleImagingStudy\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MadoImagingStudy.html\">MADO Imaging Study</a></p></div><p><b>Extension: Anatomical Region</b>: <span title=\"Codes:{http://snomed.info/sct 67734004}\">Thoracic segment of trunk</span></p><p><b>identifier</b>: Study Instance UID/1.2.392.200140.2.1.1.1.2.799008771.2076.1519721309.448</p><p><b>status</b>: Available</p><p><b>modality</b>: <a href=\"http://hl7.org/fhir/R4/codesystem-dicom-dcim.html#dicom-dcim-SM\">DICOM: SM</a> (Slide Microscopy)</p><p><b>subject</b>: <a href=\"Patient-ExamplePatient.html\">Pietje Puk  Male, DoB Unknown ( Medical Record number: PID_666 (use: official, ))</a></p><p><b>started</b>: 2018-02-27 09:48:29+0100</p><p><b>basedOn</b>: Identifier: Accession Id/2017092101</p><p><b>numberOfSeries</b>: 1</p><p><b>numberOfInstances</b>: 46</p><p><b>procedureCode</b>: <span title=\"Codes:\">CT of the head without contrast</span></p><blockquote><p><b>series</b></p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.3.799008771.2076.1519721309.449</p><p><b>modality</b>: <a href=\"http://hl7.org/fhir/R4/codesystem-dicom-dcim.html#dicom-dcim-SM\">DICOM: SM</a> (Slide Microscopy)</p><p><b>numberOfInstances</b>: 46</p><p><b>endpoint</b>: <a href=\"Bundle-mado-bundle-589331894518000.html#Endpoint_MadoWadoEndpointExample\">WADO endpoint</a></p><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721320.457</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 4</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721444.539</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 45</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721330.463</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 7</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.497</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 24</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721396.505</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 28</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721420.525</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 38</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721396.507</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 29</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.499</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 25</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721321.459</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 5</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721369.487</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 19</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721429.527</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 39</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721418.519</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 35</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721309.453</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 2</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721345.477</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 14</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721345.475</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 13</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721394.503</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 27</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 1</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721309.450</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 1</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721406.511</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 31</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721397.509</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 30</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721344.473</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 12</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 1</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721444.542</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 46</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721321.461</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 6</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721333.469</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 10</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721318.455</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 3</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721333.467</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 9</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.517</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 34</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721441.535</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 43</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.513</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 32</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.515</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 33</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721432.533</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 42</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721419.521</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 36</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721332.465</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 8</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721431.529</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 40</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721371.489</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 20</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.501</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 26</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721342.471</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 11</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721372.493</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 22</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721431.531</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 41</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721372.491</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 21</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.481</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 16</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721381.495</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 23</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.483</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 17</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 196</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721355.479</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 15</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 16</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721420.523</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 37</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 49</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721443.537</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 44</p></blockquote><blockquote><p><b>instance</b></p><p><b>Extension: Number of Frames</b>: 784</p><p><b>uid</b>: 1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.485</p><p><b>sopClass</b>: unknown: urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6 (urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6)</p><p><b>number</b>: 18</p></blockquote></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoAnatomicalRegionExtension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "67734004"
          }]
        }
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://dicom.nema.org/resources/ontology/DCM",
            "code" : "110180",
            "display" : "Study Instance UID"
          }]
        },
        "system" : "urn:dicom:uid",
        "value" : "1.2.392.200140.2.1.1.1.2.799008771.2076.1519721309.448"
      }],
      "status" : "available",
      "modality" : [{
        "system" : "http://dicom.nema.org/resources/ontology/DCM",
        "code" : "SM"
      }],
      "subject" : {
        "reference" : "Patient/ExamplePatient",
        "type" : "Patient"
      },
      "started" : "2018-02-27T09:48:29+01:00",
      "basedOn" : [{
        "type" : "ServiceRequest",
        "identifier" : {
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "ACSN",
              "display" : "Accession Id"
            },
            {
              "system" : "http://dicom.nema.org/resources/ontology/DCM",
              "code" : "121022",
              "display" : "Accession Number"
            }]
          },
          "system" : "http://hospital.org/acc",
          "value" : "2017092101"
        }
      }],
      "numberOfSeries" : 1,
      "numberOfInstances" : 46,
      "procedureCode" : [{
        "text" : "CT of the head without contrast"
      }],
      "series" : [{
        "uid" : "1.2.392.200140.2.1.1.1.3.799008771.2076.1519721309.449",
        "modality" : {
          "system" : "http://dicom.nema.org/resources/ontology/DCM",
          "code" : "SM"
        },
        "numberOfInstances" : 46,
        "endpoint" : [{
          "reference" : "Endpoint/MadoWadoEndpointExample",
          "type" : "Endpoint",
          "display" : "WADO endpoint"
        }],
        "instance" : [{
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721320.457",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 4
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721444.539",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 45
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721330.463",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 7
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.497",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 24
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721396.505",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 28
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721420.525",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 38
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721396.507",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 29
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.499",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 25
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721321.459",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 5
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721369.487",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 19
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721429.527",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 39
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721418.519",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 35
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721309.453",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 2
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721345.477",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 14
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721345.475",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 13
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721394.503",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 27
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 1
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721309.450",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 1
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721406.511",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 31
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721397.509",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 30
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721344.473",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 12
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 1
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721444.542",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 46
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721321.461",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 6
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721333.469",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 10
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721318.455",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 3
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721333.467",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 9
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.517",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 34
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721441.535",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 43
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.513",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 32
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721408.515",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 33
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721432.533",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 42
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721419.521",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 36
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721332.465",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 8
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721431.529",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 40
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721371.489",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 20
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721384.501",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 26
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721342.471",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 11
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721372.493",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 22
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721431.531",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 41
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721372.491",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 21
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.481",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 16
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721381.495",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 23
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.483",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 17
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 196
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721355.479",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 15
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 16
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721420.523",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 37
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 49
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721443.537",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 44
        },
        {
          "extension" : [{
            "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoNumberOfFrames",
            "valueInteger" : 784
          }],
          "uid" : "1.2.392.200140.2.1.1.1.4.799008771.2076.1519721357.485",
          "sopClass" : {
            "system" : "urn:ietf:rfc:3986",
            "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.77.1.6"
          },
          "number" : 18
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/Endpoint/MadoWadoEndpointExample",
    "resource" : {
      "resourceType" : "Endpoint",
      "id" : "MadoWadoEndpointExample",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoWadoEndpoint"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Endpoint_MadoWadoEndpointExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Endpoint MadoWadoEndpointExample</b></p><a name=\"MadoWadoEndpointExample\"> </a><a name=\"hcMadoWadoEndpointExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MadoWadoEndpoint.html\">Endpoint: MADO WADO endpoint</a></p></div><p><b>Extension: Retrieve Location UID</b>: oid:213.323245.462.63.56</p><p><b>status</b>: Active</p><p><b>connectionType</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-endpoint-connection-type.html#endpoint-connection-type-dicom-wado-rs\">Endpoint Connection Type: dicom-wado-rs</a> (DICOM WADO-RS)</p><p><b>name</b>: WADO endpoint</p><p><b>payloadType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/endpoint-payload-type none}\">DICOM WADO-RS</span></p><p><b>address</b>: <a href=\"http://example.org:8041/dcm4chee-arc/aets/DCM4CHEE/rs\">http://example.org:8041/dcm4chee-arc/aets/DCM4CHEE/rs</a></p></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoRetrieveLocationUIDExtension",
        "valueString" : "oid:213.323245.462.63.56"
      }],
      "status" : "active",
      "connectionType" : {
        "system" : "http://terminology.hl7.org/CodeSystem/endpoint-connection-type",
        "code" : "dicom-wado-rs",
        "display" : "DICOM WADO-RS"
      },
      "name" : "WADO endpoint",
      "payloadType" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/endpoint-payload-type",
          "code" : "none"
        }],
        "text" : "DICOM WADO-RS"
      }],
      "address" : "http://example.org:8041/dcm4chee-arc/aets/DCM4CHEE/rs"
    }
  },
  {
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/Patient/ExamplePatient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "ExamplePatient",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_ExamplePatient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient ExamplePatient</b></p><a name=\"ExamplePatient\"> </a><a name=\"hcExamplePatient\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Pietje Puk  Male, DoB Unknown ( Medical Record number: PID_666 (use: official, ))</p><hr/></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR",
            "display" : "Medical Record number"
          }]
        },
        "system" : "http://example.org/hospital/mrn",
        "value" : "PID_666"
      }],
      "name" : [{
        "family" : "Puk",
        "given" : ["Pietje"]
      }],
      "gender" : "male"
    }
  },
  {
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/Device/MadoCreatorDeviceExample",
    "resource" : {
      "resourceType" : "Device",
      "id" : "MadoCreatorDeviceExample",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoCreator"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_MadoCreatorDeviceExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device MadoCreatorDeviceExample</b></p><a name=\"MadoCreatorDeviceExample\"> </a><a name=\"hcMadoCreatorDeviceExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MadoCreator.html\">MADO Creator</a></p></div><p><b>manufacturer</b>: ACME Company</p><p><b>type</b>: <span title=\"Codes:{https://profiles.ihe.net/RAD/MADO/CodeSystem/MadoDeviceType mado-creator}\">MADO Creator</span></p></div>"
      },
      "manufacturer" : "ACME Company",
      "type" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/RAD/MADO/CodeSystem/MadoDeviceType",
          "code" : "mado-creator",
          "display" : "MADO Creator"
        }]
      }
    }
  },
  {
    "fullUrl" : "https://profiles.ihe.net/RAD/MADO/Organization/MadoCreatorOrganizationExample",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "MadoCreatorOrganizationExample",
      "meta" : {
        "profile" : ["https://profiles.ihe.net/RAD/MADO/StructureDefinition/MadoCreatorOrganization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_MadoCreatorOrganizationExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization MadoCreatorOrganizationExample</b></p><a name=\"MadoCreatorOrganizationExample\"> </a><a name=\"hcMadoCreatorOrganizationExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MadoCreatorOrganization.html\">MADO Creator Organization</a></p></div><p><b>identifier</b>: <code>http:/example.org/asask/aa</code>/32478378429</p><p><b>name</b>: ACME</p></div>"
      },
      "identifier" : [{
        "system" : "http:/example.org/asask/aa",
        "value" : "32478378429"
      }],
      "name" : "ACME"
    }
  }]
}

```
