### Changes

- 2 May 2025: Draft release for comment
  * Defines the actors
  * Defines profiles
  * Defines an initial set of Transactions - additional transactions are expected in the future


### Known issues
  - No guidance for a "prescription Bundle" - this is epxpected to be added soon, based on HL7 recent guidance.
  - No test plan - it will be added in a future edition


