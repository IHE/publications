
### Required grouping

### Workflow management

#### Prescriptive workflow

Systems that implement the IHE MPD profiles need to determine workflow types
While IHE Profiles do not force such ..., they support managing that in a consistent way:

* Category can be used 


TO DO: Define and describe the use of a data element to indicate which workflow is being executed so that systems can determine which steps are next.
TO DO: explain that one could use PlanDefinitions to describe a workflow and determine what would be the sequence of steps. 