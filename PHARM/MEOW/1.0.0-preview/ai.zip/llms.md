# ihe.pharm.meow#1.0.0-preview: IHE Pharmacy Medication Overview

## Pages

* [MeOw Home](index.md)
* [Actors and Transactions](actors-transactions.md)
* [Actor Options](actor_options.md)
* [Actor Required Grouping](actor_required_grouping.md)
* [Aggregation and Medication Reconcilliation](aggregation_and_medication_reconcilliation.md)
* [Artifacts Summary](artifacts.md)
* [Cross Profile Considerations](cross_profile_considerations.md)
* [Data Models](data_models.md)
* [Issues](issues.md)
* [Medication Concepts](medication_concepts.md)
* [Medication Treatment Lifecycle](medication_treatment_lifecycle.md)
* [Get Medication Overview [PHARM-x]](PHARM-x.md)
* [Submit Medication Overview [PHARM-y]](PHARM-y.md)
* [Security Considerations](security_considerations.md)
* [Use Case 1 - Consulting the Overview](usecase-1.md)
* [Use Case overview](usecases.md)
* [Volume 1 Overview](volume1.md)
* [Volume 2: Transactions](volume2.md)

## Resources

### Logicals

* [Dosaging (model)](StructureDefinition-DosagingInformation.md)
* [Medication Overview (model)](StructureDefinition-MedicationOverviewLM.md)
* [Medication Treatment (model)](StructureDefinition-MedicationTreatmentLM.md)
* [Medication Treatment Line (model)](StructureDefinition-MedicationTreatmentLineLM.md)
* [Medicinal product (model)](StructureDefinition-MedicinalProductLM.md)
* [Patient (model)](StructureDefinition-PatientLM.md)
* [Practitioner (model)](StructureDefinition-PractitionerLM.md)

### Resource Profiles

* [Medicinal product](StructureDefinition-IHEMedication.md)
* [Medication Overview Bundle](StructureDefinition-MedicationOverview.md)
* [Medication Overview Composition](StructureDefinition-MedicationOverviewComposition.md)
* [Medication Treatment](StructureDefinition-MedicationTreatment.md)
* [Medication Treatment Line](StructureDefinition-MedicationTreatmentLine.md)

### Extensions

* [Medication - Classification](StructureDefinition-ihe-ext-medication-classification.md)
* [Medication - Device](StructureDefinition-ihe-ext-medication-device.md)
* [Medication - Product Name](StructureDefinition-ihe-ext-medication-productname.md)
* [Medication - Size of Item](StructureDefinition-ihe-ext-medication-sizeofitem.md)
* [MedicationStatement - Substitution](StructureDefinition-ihe-ext-medicationstatement-substitution.md)
* [MedicationStatement - Verification Information](StructureDefinition-ihe-ext-medicationstatement-verificationinformation.md)

### CapabilityStatements

* [Medication Overview Consumer](CapabilityStatement-MedicationOverviewConsumer.md)
* [Medication Overview Responder](CapabilityStatement-MedicationOverviewResponder.md)

### ImplementationGuides

* [IHE Pharmacy Medication Overview](index.md)

### Examples

* [01A-Cefuroxime1500GenericExplicit (Medication)](Medication-01A-Cefuroxime1500GenericExplicit.md)
* [01B-Cefuroxime1500GenericConcept (Medication)](Medication-01B-Cefuroxime1500GenericConcept.md)
* [01C-Cefuroxime1500Branded (Medication)](Medication-01C-Cefuroxime1500Branded.md)
* [02A-ClotrimazoleCanifugCremolum (Medication)](Medication-02A-ClotrimazoleCanifugCremolum.md)
* [02A1-CanifugCremolumCreamItem (Medication)](Medication-02A1-CanifugCremolumCreamItem.md)
* [02A2-CanifugCremolumPessaryItem (Medication)](Medication-02A2-CanifugCremolumPessaryItem.md)
* [03B-VitaminBComplexBranded (Medication)](Medication-03B-VitaminBComplexBranded.md)
